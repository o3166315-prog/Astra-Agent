# Astra Agent 1.7.0

**Astra Agent** is an open-source, local-first AI development agent. It combines a permission-controlled tool runner with multi-agent workflows, project snapshots, model selection and a local web interface.

> Kairo is the project's historical identity. Astra Agent is the current distribution name.

## Highlights in 1.7.0

- **Astra Model Discovery:** fetch model IDs dynamically from provider model-list endpoints instead of relying on hard-coded model names.
- **Native providers:** OpenAI, Anthropic, Google Gemini, Meta Model API and Ollama.
- **OpenAI-compatible providers:** OpenRouter, Groq, Together AI, Fireworks AI, DeepSeek, Mistral, xAI, Perplexity, DeepInfra, SiliconFlow, Alibaba Cloud DashScope and Nebius AI Studio.
- **Custom compatible endpoints:** Baseten deployments and Cloudflare gateways can be configured with their own API base URL when they expose the OpenAI-compatible `/models` and `/chat/completions` routes.
- **Provider-specific access:** a model is listed only when the configured provider endpoint returns it. A public catalogue entry does not guarantee that a particular API key can use the model.
- **Honest capability metadata:** model IDs are discovered dynamically. Vision, audio, tool calling, reasoning and pricing are not guessed from model names; unknown capabilities remain unknown until verified.
- Retains Astra Swarm, Council, Communication Graph, Time Machine, Model Intelligence, Command Center, Self-Healing, Auto Testing, Voice browser APIs and Mission Recovery from the 1.6.1 codebase.
- Includes security hardening for project paths, symlinks/hard links, arithmetic evaluation, JSON parsing, settings persistence and recovery quarantine.

## Requirements

- Node.js 18 or newer.
- Windows, macOS or Linux for the local web application. Some native folder-picker behavior is Windows-specific.
- No mandatory npm dependencies for the basic local server.

## Quick start

```bash
npm test
npm start
```

Open `http://localhost:3000` on the same computer. By default, the server binds to `127.0.0.1`.

## Configure providers

Open **Settings → Providers** in the app.

1. Select a provider and enter its API key, if required.
2. For a custom-compatible provider, enter its API base URL.
3. Save the settings and refresh the model selector.
4. Astra requests the provider's model list and displays the returned model IDs.

Ollama runs locally. Start it with `ollama serve`, download a model separately, then refresh the Ollama model list.

### Provider compatibility notes

- OpenAI-compatible means Astra uses `/models` and `/chat/completions`. It does **not** guarantee support for every parameter, image format, tool-call format or streaming behavior.
- Baseten and Cloudflare are custom-endpoint entries: configure a deployment/gateway URL that actually implements the expected compatible routes.
- Model discovery does not validate billing, account entitlement, geographic availability or model-specific quotas.
- Capability metadata is conservative. An unknown capability is not treated as supported.
- API calls may incur charges according to the provider's current pricing. Astra does not promise free usage.

## Security model

- The local server is bound to loopback by default and uses Host/Origin checks plus an API token.
- API keys are stored in the local data directory and must never be committed.
- Project-root validation rejects unsafe roots and path traversal through symbolic/hard links.
- Destructive, system-level and other privileged operations remain subject to the permission engine.
- Configured MCP servers run as local processes with the current operating-system user's privileges. The MCP client does not provide a dedicated OS sandbox; configure only trusted servers.
- Time Machine is local, not a remote backup service. Recovery quarantines extra files rather than silently deleting them.

Before publishing, inspect the Git history and staged files for secrets. `.gitignore` does not remove a secret that was already committed.

## Tests

```bash
npm test
npm run test:providers
npm run test:security
npm run test:integration
```

Provider discovery tests use mocked HTTP responses. They do not prove that real accounts, API keys, billing or provider availability have been tested.

## Project status

The following are present in the current codebase: Swarm, Council, Communication Graph, Time Machine, Model Intelligence, Command Center, Self-Healing diagnostics, Auto Testing, browser-based Voice, and Mission Recovery/Export.

Persistent cloud execution, multi-account authentication, a remote mobile dashboard, an isolated plugin marketplace and a full image-generation engine are **not** represented as completed features in this release.

## Open source

Distributed under the MIT License. See `LICENSE`, `CONTRIBUTING.md`, `SECURITY.md` and `CODE_OF_CONDUCT.md`. Third-party components and provider services remain subject to their own terms and licenses.
