// Client MCP (stdio, JSON-RPC 2.0, un message par ligne). Outils exposés sous "mcp:<serveur>:<outil>".
const {spawn}=require('child_process');
class McpServer{
 constructor(cfg){this.cfg=cfg;this.tools=[];this.status='stopped';this.error=null;this.id=0;this.pending={};this.buf=''}
 rpc(method,params,notify){return new Promise((ok,ko)=>{const m={jsonrpc:'2.0',method,params};if(!notify){m.id=++this.id;this.pending[m.id]={ok,ko};setTimeout(()=>{if(this.pending[m.id]){delete this.pending[m.id];ko(new Error('MCP timeout : '+method))}},20000)}
  this.p.stdin.write(JSON.stringify(m)+'\n');if(notify)ok()})}
 async start(){if(this.status==='running')return;this.status='starting';this.error=null;
  try{this.p=spawn(this.cfg.command,this.cfg.args||[],{shell:process.platform==='win32',env:{...process.env,...(this.cfg.env||{})}});
   this.p.on('error',e=>{this.status='error';this.error=e.message});
   this.p.on('close',()=>{if(this.status!=='error')this.status='stopped'});
   this.p.stderr.on('data',()=>{});
   this.p.stdout.on('data',d=>{this.buf+=d;let i;while((i=this.buf.indexOf('\n'))>=0){const l=this.buf.slice(0,i);this.buf=this.buf.slice(i+1);try{const m=JSON.parse(l),w=this.pending[m.id];if(w){delete this.pending[m.id];m.error?w.ko(new Error(m.error.message)):w.ok(m.result)}}catch{}}});
   await this.rpc('initialize',{protocolVersion:'2024-11-05',capabilities:{},clientInfo:{name:'kairo',version:'0.1'}});
   await this.rpc('notifications/initialized',{},true);
   this.tools=(await this.rpc('tools/list',{})).tools||[];this.status='running'}
  catch(e){this.status='error';this.error=e.message;try{this.p&&this.p.kill()}catch{}}}
 stop(){try{this.p&&this.p.kill()}catch{};if(this.status!=='error')this.status='stopped';this.tools=[]}
 async call(name,args){if(this.status!=='running')throw new Error('Serveur MCP arrêté : '+this.cfg.name);
  const r=await this.rpc('tools/call',{name,arguments:args||{}});const t=(r.content||[]).map(c=>c.text||JSON.stringify(c)).join('\n');if(r.isError)throw new Error(t);return t}
 info(){return{...this.cfg,status:this.status,error:this.error,tools:this.tools.map(t=>({name:t.name,description:t.description}))}}
}
module.exports={McpServer};
