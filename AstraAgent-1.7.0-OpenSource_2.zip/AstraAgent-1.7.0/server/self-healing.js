// Astra Self-Healing — diagnostic statique et préparation de corrections avec validation humaine.
// Ce module ne modifie jamais les fichiers du projet.
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');
const { walk, safe } = require('./tools');

function scanProject(root) {
  const issues = [], checked = { javascript: 0, json: 0 };
  let files = [];
  try { files = walk(root, root).filter(x => !x.endsWith('/')); }
  catch (e) { issues.push({ severity: 'error', file: '.', kind: 'path', message: e.message }); }
  for (const rel of files) {
    const ext = path.extname(rel).toLowerCase();
    let full;
    try { full = safe(root, rel); } catch (e) { issues.push({ severity: 'error', file: rel, kind: 'path', message: e.message }); continue; }
    if (ext === '.json' && checked.json < 40) {
      checked.json++;
      try { JSON.parse(fs.readFileSync(full, 'utf8')); }
      catch (e) { issues.push({ severity: 'error', file: rel, kind: 'json', message: e.message }); }
    } else if (['.js', '.cjs', '.mjs'].includes(ext) && checked.javascript < 40) {
      checked.javascript++;
      try { execFileSync(process.execPath, ['--check', full], { cwd: root, encoding: 'utf8', timeout: 8000, windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] }); }
      catch (e) {
        const detail = String(e.stderr || e.stdout || e.message || 'Syntaxe invalide').trim().slice(0, 700);
        issues.push({ severity: 'error', file: rel, kind: 'javascript', message: detail });
      }
    }
  }
  let packageInfo = null;
  try {
    const packagePath = safe(root, 'package.json');
    if (fs.existsSync(packagePath)) {
      const p = JSON.parse(fs.readFileSync(packagePath, 'utf8'));
      packageInfo = { name: p.name || '', scripts: p.scripts || {}, type: p.type || 'commonjs' };
    }
  } catch (e) { issues.push({ severity: 'error', file: 'package.json', kind: 'package', message: e.message }); }
  return { at: new Date().toISOString(), filesScanned: files.length, checked, packageInfo, issues,
    status: issues.some(x => x.severity === 'error') ? 'issues' : 'ok' };
}

function buildPrompt({ projectName, scan, errors }) {
  const recent = (errors || []).slice(0, 12).map(e => ({ at: e.lastAt || e.at, origin: e.origin, message: e.message, context: e.context, hint: e.solution }));
  return `Tu es Astra Self-Healing. Effectue un diagnostic en lecture seule d'un projet logiciel.\n` +
    `Projet : ${projectName || 'Projet Astra'}\n\n` +
    `RÈGLES : n'affirme pas avoir exécuté des tests que tu n'as pas lancés ; ne propose pas de supprimer des données ; distingue faits observés, hypothèses et recommandations. ` +
    `Donne les fichiers concernés, les causes probables et une correction minimale. Ne modifie aucun fichier.\n\n` +
    `SCAN LOCAL :\n${JSON.stringify(scan, null, 2).slice(0, 10000)}\n\n` +
    `ERREURS RÉCENTES :\n${JSON.stringify(recent, null, 2).slice(0, 9000)}\n\n` +
    `Réponds en français avec : 1) faits observés 2) causes probables 3) corrections proposées 4) tests à lancer.`;
}

module.exports = { scanProject, buildPrompt };
