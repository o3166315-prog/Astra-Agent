// Outils supplémentaires (V5.1). Fabrique : reçoit les aides de tools.js pour éviter les dépendances circulaires.
// Les permissions de chacun sont définies dans perms.js (classifyTool).
const fs=require('fs'),path=require('path'),os=require('os'),crypto=require('crypto'),{spawnSync}=require('child_process'),perms=require('./perms'),pathGuard=require('./path-guard');

const globRe=g=>{let r='';for(let i=0;i<g.length;i++){const c=g[i];if(c==='*'){if(g[i+1]==='*'){r+='.*';i++;if(g[i+1]==='/')i++}else r+='[^/]*'}else if(c==='?')r+='[^/]';else r+=/[.+^${}()|[\]\\]/.test(c)?'\\'+c:c}return new RegExp('^'+r+'$','i')};
const MATH=new Set('sqrt cbrt sin cos tan asin acos atan atan2 log log2 log10 exp abs floor ceil round trunc sign pow min max hypot PI E'.split(' '));
const MATH_FUNCTIONS={sqrt:Math.sqrt,cbrt:Math.cbrt,sin:Math.sin,cos:Math.cos,tan:Math.tan,asin:Math.asin,acos:Math.acos,atan:Math.atan,atan2:Math.atan2,log:Math.log,log2:Math.log2,log10:Math.log10,exp:Math.exp,abs:Math.abs,floor:Math.floor,ceil:Math.ceil,round:Math.round,trunc:Math.trunc,sign:Math.sign,pow:Math.pow,min:Math.min,max:Math.max,hypot:Math.hypot};
function calc(expr){
 const source=String(expr||'').trim();if(!source)throw new Error('expression vide');if(source.length>300)throw new Error('expression trop longue');
 const tokens=[];let at=0;
 while(at<source.length){
  if(/\s/.test(source[at])){at++;continue;}
  const rest=source.slice(at),number=/^(?:(?:\d+(?:\.\d*)?)|(?:\.\d+))(?:e[+-]?\d+)?/i.exec(rest),ident=/^[A-Za-z_]\w*/.exec(rest);
  if(number){const n=Number(number[0]);if(!Number.isFinite(n))throw new Error('nombre invalide');tokens.push({type:'number',value:n});at+=number[0].length;continue;}
  if(ident){tokens.push({type:'ident',value:ident[0]});at+=ident[0].length;continue;}
  const ch=source[at];if('()+-*/%^,'.includes(ch)){tokens.push({type:ch,value:ch});at++;continue;}
  throw new Error('caractère non autorisé dans l’expression : '+ch);
 }
 tokens.push({type:'eof'});let pos=0;
 const peek=()=>tokens[pos],take=type=>{if(peek().type!==type)throw new Error('expression invalide : symbole attendu « '+type+' »');return tokens[pos++];};
 const primary=()=>{
  if(peek().type==='number')return take('number').value;
  if(peek().type==='('){take('(');const value=additive();take(')');return value;}
  if(peek().type==='ident'){
   const name=take('ident').value;
   if(!MATH.has(name))throw new Error('identifiant non autorisé : '+name);
   if(peek().type==='('){
    const fn=MATH_FUNCTIONS[name];if(!fn)throw new Error('constante non appelable : '+name);
    take('(');const args=[];if(peek().type!==')'){args.push(additive());while(peek().type===','){take(',');args.push(additive());}}
    take(')');const arity={sqrt:1,cbrt:1,sin:1,cos:1,tan:1,asin:1,acos:1,atan:1,atan2:2,log:1,log2:1,log10:1,exp:1,abs:1,floor:1,ceil:1,round:1,trunc:1,sign:1,pow:2,min:[1,Infinity],max:[1,Infinity],hypot:[1,Infinity]}[name];
    if(typeof arity==='number'&&args.length!==arity||Array.isArray(arity)&&(args.length<arity[0]||args.length>arity[1]))throw new Error('nombre d’arguments invalide pour '+name);
    return fn(...args);
   }
   if(name!=='PI'&&name!=='E')throw new Error('la fonction '+name+' doit être appelée avec des parenthèses');
   return Math[name];
  }
  throw new Error('expression invalide près de « '+(peek().value??peek().type)+' »');
 };
 const power=()=>{let left=primary();if(peek().type==='^'){take('^');const right=unary();left=Math.pow(left,right);}return left;};
 const unary=()=>{if(peek().type==='+'){take('+');return unary();}if(peek().type==='-'){take('-');return -unary();}return power();};
 const multiplicative=()=>{let v=unary();while(['*','/','%'].includes(peek().type)){const op=take(peek().type).type,r=unary();v=op==='*'?v*r:op==='/'?v/r:v%r;}return v;};
 const additive=()=>{let v=multiplicative();while(peek().type==='+'||peek().type==='-'){const op=take(peek().type).type,r=multiplicative();v=op==='+'?v+r:v-r;}return v;};
 const value=additive();if(peek().type!=='eof')throw new Error('symbole inattendu : '+(peek().value??peek().type));
 if(typeof value!=='number'||!Number.isFinite(value))throw new Error('résultat non numérique : '+value);return value;
}
const query=(obj,q)=>{let cur=obj;const parts=String(q||'').replace(/\[(\d+)\]/g,'.$1').split('.').filter(Boolean);for(const k of parts){if(cur===null||typeof cur!=='object'||!(k in cur))throw new Error('clé introuvable : '+k);cur=cur[k]}return cur};
const detectTest=root=>{const file=f=>{try{return pathGuard.resolveProjectPath(root,f)}catch{return null}},has=f=>{const p=file(f);return !!p&&fs.existsSync(p)};
 if(has('package.json')){try{const p=file('package.json');const s=JSON.parse(fs.readFileSync(p,'utf8')).scripts||{};if(s.test&&!/no test specified/i.test(s.test))return 'npm test'}catch{}}
 if(has('pytest.ini')||has('pyproject.toml')||has('tests')&&fs.readdirSync(file('tests')).some(f=>/\.py$/.test(f)))return 'python -m pytest -q';
 if(has('Cargo.toml'))return 'cargo test';if(has('go.mod'))return 'go test ./...';
 if(has('CMakeLists.txt')&&has('build'))return 'ctest --test-dir build';return null};

module.exports=h=>{const {walk,briefDiff,backup,hidden,textFile}=h;
 const writeGuard=(rel,c)=>{if(!rel)throw new Error('chemin manquant');const p=perms.norm(rel,c.root),inside=perms.inside(p,c.root);if(inside&&hidden(path.relative(c.root,p)))throw new Error('Écriture dans une zone interne refusée : '+rel);return{p,inside}};
 const save=async(c,rel,p,inside,before,existed,after)=>{const changeId=inside?await backup(c,p,before,after,existed):null;fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,after);c.created?.add(p);return{diff:briefDiff(rel,before,after),changeId,path:rel}};
 const readText=(a,c)=>{const p=perms.norm(a,c.root);if(!fs.existsSync(p)||fs.statSync(p).isDirectory())throw new Error('Fichier inexistant : '+a);return{p,text:fs.readFileSync(p,'utf8')}};
 const todoFile=c=>pathGuard.resolveProjectPath(c.root,'.kairo/todo.json');
 const todoRead=c=>{try{return JSON.parse(fs.readFileSync(todoFile(c),'utf8'))}catch{return[]}};
 const todoWrite=(c,l)=>{fs.mkdirSync(path.dirname(todoFile(c)),{recursive:true});fs.writeFileSync(todoFile(c),JSON.stringify(l,null,2))};
 return{
  edit_file:{desc:'Remplace un passage exact dans un fichier (plus sûr que réécrire tout le fichier). args:{path, old, new, all?:true}. Erreur si « old » est introuvable ou ambigu.',run:async(a,c)=>{
   const rel=String(a.path||''),{p,inside}=writeGuard(rel,c),{text}=readText(rel,c),old=String(a.old??''),neu=String(a.new??'');
   if(!old)throw new Error('« old » vide : indique le passage à remplacer');const n=text.split(old).length-1;
   if(!n)throw new Error('Passage introuvable dans '+rel+' (copie-le exactement, espaces compris)');
   if(n>1&&!a.all)throw new Error(n+' occurrences dans '+rel+' : précise davantage « old » ou ajoute all:true');
   const after=a.all?text.split(old).join(neu):text.replace(old,()=>neu),r=await save(c,rel,p,inside,text,true,after);
   return{text:'Modifié '+rel+' ('+(a.all?n:1)+' remplacement'+((a.all?n:1)>1?'s':'')+')',...r}}},
  append_file:{desc:'Ajoute du texte à la fin d’un fichier (le crée si besoin). args:{path, content}',run:async(a,c)=>{
   const rel=String(a.path||''),{p,inside}=writeGuard(rel,c),existed=fs.existsSync(p);if(existed&&fs.statSync(p).isDirectory())throw new Error('Ce chemin est un dossier : '+rel);
   const before=existed?fs.readFileSync(p,'utf8'):'',add=String(a.content??''),after=before+(before&&!before.endsWith('\n')&&!add.startsWith('\n')?'\n':'')+add,r=await save(c,rel,p,inside,before,existed,after);
   return{text:'Ajouté à '+rel+' (+'+add.length+' car.)',...r}}},
  read_lines:{desc:'Lit une plage de lignes numérotées d’un fichier. args:{path, start?:1, end?:200}',run:async(a,c)=>{
   const{text}=readText(a.path,c),L=text.split('\n'),s=Math.max(1,+a.start||1),e=Math.min(L.length,Math.max(s,+a.end||s+199));
   return `${a.path} — lignes ${s}-${e} sur ${L.length}\n`+L.slice(s-1,e).map((l,i)=>String(s+i).padStart(5)+'│ '+l).join('\n').slice(0,20000)}},
  find_files:{desc:'Cherche des fichiers par nom (glob : *.js, src/**/*.py, test_*). args:{pattern, path?}',run:async(a,c)=>{
   const pat=String(a.pattern||'').trim();if(!pat)return 'Motif vide';const d=perms.norm(a.path||'.',c.root);if(!fs.existsSync(d)||!fs.statSync(d).isDirectory())throw new Error('Dossier inexistant : '+(a.path||'.'));
   const re=globRe(pat.includes('/')?pat:'**/'+pat),out=walk(d,d).filter(x=>!x.endsWith('/')&&re.test(x.replace(/\\/g,'/')));return out.slice(0,200).join('\n')||'Aucun fichier'}},
  file_info:{desc:'Taille, dates, nombre de lignes et empreinte SHA-256 d’un fichier ou dossier. args:{path}',run:async(a,c)=>{
   const p=perms.norm(a.path,c.root);if(!fs.existsSync(p))throw new Error('Inexistant : '+a.path);const s=fs.statSync(p),o=[`chemin : ${a.path}`,`type : ${s.isDirectory()?'dossier':'fichier'}`,`taille : ${s.size} octets`,`modifié : ${s.mtime.toISOString()}`];
   if(s.isFile()){const b=fs.readFileSync(p);o.push('sha256 : '+crypto.createHash('sha256').update(b).digest('hex'));if(textFile(p))o.push('lignes : '+b.toString('utf8').split('\n').length)}else o.push('éléments : '+fs.readdirSync(p).length);return o.join('\n')}},
  move_file:{desc:'Déplace ou renomme un fichier/dossier. args:{from, to}',run:async(a,c)=>{
   const f=perms.norm(a.from,c.root),t=perms.norm(a.to,c.root);if(!fs.existsSync(f))throw new Error('Inexistant : '+a.from);if(fs.existsSync(t))throw new Error('Destination déjà existante : '+a.to);
   for(const x of[f,t])if(perms.inside(x,c.root)&&hidden(path.relative(c.root,x)))throw new Error('Zone interne refusée');
   if(f===c.root||path.parse(f).root===f)throw new Error('Déplacement refusé : dossier racine');fs.mkdirSync(path.dirname(t),{recursive:true});fs.renameSync(f,t);if(c.created?.has(f)){c.created.delete(f);c.created.add(t)}return `Déplacé ${a.from} → ${a.to}`}},
  copy_file:{desc:'Copie un fichier ou dossier. args:{from, to}',run:async(a,c)=>{
   const f=perms.norm(a.from,c.root),t=perms.norm(a.to,c.root);if(!fs.existsSync(f))throw new Error('Inexistant : '+a.from);if(fs.existsSync(t))throw new Error('Destination déjà existante : '+a.to);
   if(perms.inside(t,c.root)&&hidden(path.relative(c.root,t)))throw new Error('Zone interne refusée');fs.mkdirSync(path.dirname(t),{recursive:true});fs.cpSync(f,t,{recursive:true});c.created?.add(t);return `Copié ${a.from} → ${a.to}`}},
  make_dir:{desc:'Crée un dossier (et ses parents). args:{path}',run:async(a,c)=>{const{p}=writeGuard(String(a.path||''),c);fs.mkdirSync(p,{recursive:true});return 'Dossier prêt : '+a.path}},
  diff_files:{desc:'Compare deux fichiers texte et montre les différences. args:{a, b}',run:async(a,c)=>{
   const x=readText(a.a,c).text,y=readText(a.b,c).text,d=briefDiff(a.a+' ↔ '+a.b,x,y);return d?d.lines.join('\n'):'Fichiers identiques'}},
  replace_in_files:{desc:'Rechercher/remplacer dans plusieurs fichiers texte du projet. SANS apply:true, simple aperçu. args:{query, replacement, glob?:"*.js", path?, apply?:true}',run:async(a,c)=>{
   const q=String(a.query??'');if(!q)throw new Error('« query » vide');const rep=String(a.replacement??''),d=perms.norm(a.path||'.',c.root);if(!perms.inside(d,c.root))throw new Error('Dossier hors du projet refusé');
   if(!fs.existsSync(d)||!fs.statSync(d).isDirectory())throw new Error('Dossier inexistant : '+(a.path||'.'));
   const re=a.glob?globRe(String(a.glob).includes('/')?a.glob:'**/'+a.glob):null,res=[];let total=0;
   for(const f of walk(d,d).filter(x=>!x.endsWith('/')&&textFile(x)&&(!re||re.test(x.replace(/\\/g,'/'))))){const p=path.join(d,f);let t;try{t=fs.readFileSync(p,'utf8')}catch{continue}const n=t.split(q).length-1;if(!n)continue;total+=n;res.push(`${path.relative(c.root,p)} : ${n}`);
    if(a.apply)await save(c,path.relative(c.root,p),p,true,t,true,t.split(q).join(rep))}
   if(!res.length)return 'Aucune occurrence';return(a.apply?`Remplacé ${total} occurrence(s) dans ${res.length} fichier(s) (sauvegardes dans .kairo/backups) :\n`:`Aperçu : ${total} occurrence(s) dans ${res.length} fichier(s). Relance avec apply:true pour appliquer.\n`)+res.slice(0,100).join('\n')}},
  check_syntax:{desc:'Vérifie la syntaxe d’un fichier .js/.mjs/.json/.py sans l’exécuter. args:{path}',run:async(a,c)=>{
   const{p,text}=readText(a.path,c),ext=path.extname(p).toLowerCase();
   if(ext==='.json'){try{JSON.parse(text);return 'JSON valide'}catch(e){throw new Error('JSON invalide : '+e.message)}}
   const cmd=['.js','.mjs','.cjs'].includes(ext)?[process.execPath,['--check',p]]:ext==='.py'?['python3',['-m','py_compile',p]]:null;if(!cmd)return 'Type non pris en charge (js, mjs, cjs, json, py)';
   let r=spawnSync(cmd[0],cmd[1],{encoding:'utf8',timeout:15000,windowsHide:true,cwd:c.root});if(r.error&&ext==='.py')r=spawnSync('python',cmd[1],{encoding:'utf8',timeout:15000,windowsHide:true,cwd:c.root});
   if(r.error)throw new Error('Vérificateur indisponible : '+r.error.message);if(r.status!==0)throw new Error('Erreur de syntaxe :\n'+String(r.stderr||r.stdout).slice(0,1500));return 'Syntaxe valide ('+ext+')'}},
  json_query:{desc:'Lit une valeur dans un fichier JSON par chemin (ex: scripts.test ou items[0].name). args:{path, query?}',run:async(a,c)=>{
   const{text}=readText(a.path,c);let j;try{j=JSON.parse(text)}catch(e){throw new Error('JSON invalide : '+e.message)}const v=a.query?query(j,a.query):j;
   if(v&&typeof v==='object'&&!a.query&&!Array.isArray(v))return 'clés : '+Object.keys(v).join(', ');return JSON.stringify(v,null,2).slice(0,6000)}},
  calculate:{desc:'Calcule une expression mathématique (+ - * / % ^, sqrt, sin, log, min, max, PI…). args:{expression}',run:async a=>String(calc(a.expression))},
  get_time:{desc:'Date et heure actuelles, éventuellement dans un fuseau (ex: Asia/Tokyo). args:{tz?}',run:async a=>{const d=new Date();try{const o=a.tz?{timeZone:String(a.tz)}:{};return `${new Intl.DateTimeFormat('fr-FR',{...o,dateStyle:'full',timeStyle:'long'}).format(d)}\nISO : ${d.toISOString()}`}catch{throw new Error('Fuseau inconnu : '+a.tz)}}},
  system_info:{desc:'Système, processeur, mémoire, version de Node et dossier du projet. args:{}',run:async(a,c)=>{const m=x=>(x/1073741824).toFixed(1)+' Go';return[`OS : ${os.type()} ${os.release()} (${os.arch()})`,`CPU : ${os.cpus()[0]?.model||'?'} × ${os.cpus().length}`,`RAM : ${m(os.freemem())} libres / ${m(os.totalmem())}`,`Node : ${process.version}`,`Projet : ${c.root}`].join('\n')}},
  project_summary:{desc:'Résumé rapide du projet : technologies, scripts, points d’entrée, répartition des fichiers. args:{}',run:async(a,c)=>{
   const r=c.root,file=f=>pathGuard.resolveProjectPath(r,f),has=f=>fs.existsSync(file(f)),o=[],files=walk(r,r).filter(x=>!x.endsWith('/')),ext={};files.forEach(f=>{const e=path.extname(f).toLowerCase()||'(aucune)';ext[e]=(ext[e]||0)+1});
   if(has('package.json')){try{const j=JSON.parse(fs.readFileSync(file('package.json'),'utf8'));o.push('Node : '+(j.name||'sans nom')+(j.main?' · main='+j.main:''));if(j.scripts)o.push('scripts : '+Object.keys(j.scripts).join(', '));const dep=Object.keys({...j.dependencies,...j.devDependencies});if(dep.length)o.push('dépendances : '+dep.slice(0,15).join(', '))}catch{o.push('package.json illisible')}}
   for(const[f,l]of[['requirements.txt','Python (requirements.txt)'],['pyproject.toml','Python (pyproject)'],['Cargo.toml','Rust (Cargo)'],['go.mod','Go'],['CMakeLists.txt','C/C++ (CMake)'],['project.godot','Godot'],['index.html','Web (index.html)']])if(has(f))o.push(l);
   o.push('git : '+(has('.git')?'oui':'non'),'fichiers : '+files.length,'types : '+Object.entries(ext).sort((x,y)=>y[1]-x[1]).slice(0,8).map(([k,v])=>k+' '+v).join(', '));
   const t=detectTest(r);if(t)o.push('tests : '+t);const rd=['README.md','readme.md','README.txt'].find(has);if(rd)o.push('README : '+fs.readFileSync(file(rd),'utf8').split('\n').filter(Boolean).slice(0,3).join(' | ').slice(0,300));return o.join('\n')}},
  todo:{desc:'Liste de tâches persistante du projet. args:{action:"add"|"list"|"done"|"remove"|"clear", text? (add), id? (done/remove)}',run:async(a,c)=>{
   const l=todoRead(c),act=String(a.action||'list'),fmt=(x=l)=>x.length?x.map(t=>`${t.done?'[x]':'[ ]'} #${t.id} ${t.text}`).join('\n'):'(aucune tâche)';
   if(act==='list')return fmt();if(act==='clear'){todoWrite(c,[]);return 'Liste vidée'}
   if(act==='add'){const t=String(a.text||'').trim().slice(0,200);if(!t)throw new Error('texte manquant');l.push({id:(l.reduce((m,x)=>Math.max(m,x.id),0)+1),text:t,done:false});todoWrite(c,l);return fmt()}
   const t=l.find(x=>x.id===+a.id);if(!t)throw new Error('tâche introuvable : '+a.id);if(act==='done'){t.done=true;todoWrite(c,l);return fmt()}
   if(act==='remove'){const nl=l.filter(x=>x!==t);todoWrite(c,nl);return fmt(nl)}throw new Error('action inconnue : '+act)}},
  http_request:{desc:'Requête HTTP (GET/POST/PUT/DELETE) pour tester une API ou un serveur local. args:{url, method?, headers?:{}, body? (texte ou objet JSON), timeout?:secondes}',run:async a=>{
   let u;try{u=new URL(a.url)}catch{throw new Error('URL invalide : '+a.url)}if(!/^https?:$/.test(u.protocol))throw new Error('Seuls http et https sont autorisés');
   const m=String(a.method||'GET').toUpperCase();if(!['GET','POST','PUT','PATCH','DELETE','HEAD'].includes(m))throw new Error('méthode non autorisée : '+m);
   const h={...(a.headers||{})},isObj=a.body&&typeof a.body==='object',body=a.body===undefined||['GET','HEAD'].includes(m)?undefined:isObj?JSON.stringify(a.body):String(a.body);if(isObj&&!Object.keys(h).some(k=>k.toLowerCase()==='content-type'))h['content-type']='application/json';
   const r=await fetch(u,{method:m,headers:h,body,signal:AbortSignal.timeout(Math.min(60,Math.max(1,+a.timeout||15))*1000)}),t=await r.text();let out=t;try{out=JSON.stringify(JSON.parse(t),null,2)}catch{}
   return `HTTP ${r.status} ${r.statusText||''}\ncontent-type: ${r.headers.get('content-type')||'?'}\n\n`+out.slice(0,6000)}},
  run_tests:{desc:'Détecte et lance les tests du projet (npm test, pytest, cargo test, go test, ctest). args:{}',run:async(a,c)=>{const cmd=detectTest(c.root);if(!cmd)throw new Error('Aucun test détecté (ni script npm test, ni pytest, ni Cargo/Go/CMake). Utilise run_command avec la commande de test du projet.');
   return h.tools.run_command.run({command:cmd,timeout:300},c)}},
 }};
module.exports.detectTest=detectTest;module.exports.calc=calc;module.exports.globRe=globRe;
