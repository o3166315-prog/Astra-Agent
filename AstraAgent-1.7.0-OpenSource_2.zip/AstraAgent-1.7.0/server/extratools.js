// Outils supplémentaires (V5.2). Même principe que moretools.js : une fabrique qui reçoit les aides de tools.js.
// Chaque outil = { desc, run(args, ctx) }. Les permissions sont définies dans perms.js (classifyTool).
const fs = require('fs'), path = require('path'), crypto = require('crypto'), { spawnSync } = require('child_process'), perms = require('./perms');

const MAX_FILE = 1024 * 1024; // on ignore les fichiers texte > 1 Mo pour les recherches
const JOURS = ['dimanche', 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi'];

// Catalogue affiché dans l'onglet « Outils » de l'interface (catégorie + niveau de permission habituel).
const META = {
  read_file: ['Fichiers', 'SAFE'], write_file: ['Fichiers', 'SAFE'], delete_file: ['Fichiers', 'DANGER'], list_dir: ['Fichiers', 'SAFE'],
  edit_file: ['Fichiers', 'SAFE'], append_file: ['Fichiers', 'SAFE'], read_lines: ['Fichiers', 'SAFE'], find_files: ['Fichiers', 'SAFE'],
  file_info: ['Fichiers', 'SAFE'], move_file: ['Fichiers', 'SAFE'], copy_file: ['Fichiers', 'SAFE'], make_dir: ['Fichiers', 'SAFE'],
  diff_files: ['Fichiers', 'SAFE'], replace_in_files: ['Fichiers', 'SAFE'], format_json: ['Fichiers', 'SAFE'],
  search_files: ['Recherche', 'SAFE'], search_regex: ['Recherche', 'SAFE'], find_todos: ['Recherche', 'SAFE'], tree: ['Recherche', 'SAFE'],
  outline_code: ['Code', 'SAFE'], code_stats: ['Code', 'SAFE'], check_syntax: ['Code', 'SAFE'], run_tests: ['Code', 'variable'],
  project_summary: ['Code', 'SAFE'], json_query: ['Code', 'SAFE'], csv_info: ['Données', 'SAFE'], run_command: ['Code', 'variable'],
  git_status: ['Git', 'SAFE'], git_log: ['Git', 'SAFE'], git_diff: ['Git', 'SAFE'],
  calculate: ['Utilitaires', 'SAFE'], get_time: ['Utilitaires', 'SAFE'], date_calc: ['Utilitaires', 'SAFE'], system_info: ['Utilitaires', 'SAFE'],
  hash_text: ['Utilitaires', 'SAFE'], encode_decode: ['Utilitaires', 'SAFE'], uuid_generate: ['Utilitaires', 'SAFE'], regex_test: ['Utilitaires', 'SAFE'],
  todo: ['Utilitaires', 'SAFE'], remember: ['Utilitaires', 'SAFE'], detect_tools: ['Système', 'SAFE'],
  fetch_url: ['Réseau', 'CONFIRM'], http_request: ['Réseau', 'variable'],
  screenshot: ['Écran', 'variable'], gui_click: ['Écran', 'SAFE'], gui_type: ['Écran', 'SAFE'], gui_key: ['Écran', 'SAFE'], analyze_image: ['Images', 'SAFE'],
};

// Analyse CSV minimale (guillemets, délimiteur choisi). Suffisant pour un aperçu, pas pour un import complet.
const parseCsv = (text, delim) => {
  const rows = []; let row = [], cell = '', q = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) { if (c === '"') { if (text[i + 1] === '"') { cell += '"'; i++; } else q = false; } else cell += c; }
    else if (c === '"') q = true;
    else if (c === delim) { row.push(cell); cell = ''; }
    else if (c === '\n' || c === '\r') { if (c === '\r' && text[i + 1] === '\n') i++; row.push(cell); rows.push(row); row = []; cell = ''; }
    else cell += c;
  }
  if (cell || row.length) { row.push(cell); rows.push(row); }
  return rows.filter(r => r.length > 1 || (r.length === 1 && r[0] !== ''));
};

// Motifs d'extraction de définitions par type de fichier (outline_code).
const OUTLINE = {
  js: [/^\s*(?:export\s+)?(?:default\s+)?(?:async\s+)?function\*?\s+[\w$]+/, /^\s*(?:export\s+)?(?:default\s+)?class\s+[\w$]+/, /^\s*(?:export\s+)?(?:const|let|var)\s+[\w$]+\s*=\s*(?:async\s*)?(?:\([^)]*\)|[\w$]+)\s*=>/, /^\s{2,}(?:async\s+|static\s+)*[\w$]+\s*\([^)]*\)\s*\{\s*$/],
  py: [/^\s*(?:async\s+)?def\s+\w+/, /^\s*class\s+\w+/],
  gd: [/^\s*(?:static\s+)?func\s+\w+/, /^\s*class(?:_name)?\s+\w+/, /^\s*signal\s+\w+/],
  c: [/^[A-Za-z_][\w\s\*:<>,&~]*\s+[\*&]?[\w:~]+\s*\([^;]*\)\s*(?:const\s*)?\{?\s*$/, /^\s*(?:class|struct|enum|namespace)\s+\w+/],
  go: [/^func\s+/, /^type\s+\w+\s+(?:struct|interface)/],
  rs: [/^\s*(?:pub\s+)?(?:async\s+)?fn\s+\w+/, /^\s*(?:pub\s+)?(?:struct|enum|trait|impl)\s+/],
  java: [/^\s*(?:public|private|protected|static|final|abstract|\s)+[\w<>\[\],\s]+\s+\w+\s*\([^;]*\)\s*(?:throws [\w, ]+)?\{?\s*$/, /^\s*(?:public\s+)?(?:class|interface|enum|record)\s+\w+/],
  html: [/<(?:h[1-3]|section|script|style)\b[^>]*>/i],
  md: [/^#{1,4}\s+\S/],
};
const OUTLINE_ALIAS = { jsx: 'js', ts: 'js', tsx: 'js', mjs: 'js', cjs: 'js', vue: 'js', svelte: 'js', cpp: 'c', cc: 'c', h: 'c', hpp: 'c', cs: 'java', kt: 'java', php: 'java', htm: 'html', markdown: 'md' };

module.exports = h => {
  const { walk, briefDiff, backup, hidden, textFile } = h;

  const readText = (rel, c) => {
    const p = perms.norm(rel, c.root);
    if (!fs.existsSync(p) || fs.statSync(p).isDirectory()) throw new Error('Fichier inexistant : ' + rel);
    return { p, text: fs.readFileSync(p, 'utf8') };
  };
  const dirOf = (rel, c) => {
    const d = perms.norm(rel || '.', c.root);
    if (!fs.existsSync(d) || !fs.statSync(d).isDirectory()) throw new Error('Dossier inexistant : ' + (rel || '.'));
    return d;
  };
  // Liste les fichiers texte lisibles d'un dossier (filtre glob optionnel).
  const textFiles = (d, glob) => {
    const re = glob ? globToRe(glob) : null;
    return walk(d, d).filter(x => !x.endsWith('/') && textFile(x) && (!re || re.test(x.replace(/\\/g, '/')))).filter(x => {
      try { return fs.statSync(path.join(d, x)).size <= MAX_FILE; } catch { return false; }
    });
  };
  const globToRe = g => {
    g = String(g).includes('/') ? g : '**/' + g; let r = '';
    for (let i = 0; i < g.length; i++) {
      const c = g[i];
      if (c === '*') { if (g[i + 1] === '*') { r += '.*'; i++; if (g[i + 1] === '/') i++; } else r += '[^/]*'; }
      else if (c === '?') r += '[^/]';
      else r += /[.+^${}()|[\]\\]/.test(c) ? '\\' + c : c;
    }
    return new RegExp('^' + r + '$', 'i');
  };
  const makeRe = (pattern, flags, extra = '') => {
    const p = String(pattern ?? ''); if (!p) throw new Error('« pattern » vide');
    if (p.length > 200) throw new Error('motif trop long (200 caractères max)');
    const f = String(flags || '').replace(/[^imsu]/g, '');
    try { return new RegExp(p, f + extra); } catch (e) { throw new Error('Expression régulière invalide : ' + e.message); }
  };
  const git = (c, args) => {
    const r = spawnSync('git', ['--no-pager', '-c', 'core.quotepath=false', ...args], { cwd: c.root, encoding: 'utf8', timeout: 15000, windowsHide: true, maxBuffer: 4 * 1024 * 1024 });
    if (r.error) throw new Error('git indisponible : ' + r.error.message);
    if (r.status !== 0) { const m = String(r.stderr || r.stdout).trim(); throw new Error(/not a git repository/i.test(m) ? 'Ce projet n’est pas un dépôt git' : 'git : ' + m.slice(0, 500)); }
    return String(r.stdout);
  };
  const gitPath = (a, c) => {
    if (!a.path) return [];
    const p = perms.norm(a.path, c.root);
    if (!perms.inside(p, c.root)) throw new Error('Chemin hors du projet refusé');
    return ['--', path.relative(c.root, p) || '.'];
  };
  const dateArg = v => {
    if (v === undefined || v === null || v === '' || v === 'today' || v === 'aujourd’hui') return new Date();
    const d = new Date(String(v)); if (isNaN(d)) throw new Error('Date invalide : ' + v); return d;
  };
  const fmtDate = d => `${JOURS[d.getUTCDay()]} ${d.toISOString().slice(0, 10)}`;
  const writeGuard = (rel, c) => {
    if (!rel) throw new Error('chemin manquant');
    const p = perms.norm(rel, c.root), inside = perms.inside(p, c.root);
    if (inside && hidden(path.relative(c.root, p))) throw new Error('Écriture dans une zone interne refusée : ' + rel);
    return { p, inside };
  };
  const sizeStr = n => n < 1024 ? n + ' o' : n < 1048576 ? (n / 1024).toFixed(1) + ' Ko' : (n / 1048576).toFixed(1) + ' Mo';

  return {
    search_regex: {
      desc: 'Recherche par expression régulière dans les fichiers texte du projet, avec lignes de contexte. args:{pattern, flags?:"i", glob?:"*.js", path?, context?:0-5, max?:100}',
      run: async (a, c) => {
        const re = makeRe(a.pattern, a.flags), d = dirOf(a.path, c), ctxN = Math.min(5, Math.max(0, +a.context || 0)), max = Math.min(300, Math.max(1, +a.max || 100));
        const out = []; let hits = 0, nfiles = 0;
        for (const f of textFiles(d, a.glob)) {
          let L; try { L = fs.readFileSync(path.join(d, f), 'utf8').split('\n'); } catch { continue; }
          let fileHit = false;
          for (let i = 0; i < L.length && hits < max; i++) {
            if (!re.test(L[i])) continue;
            hits++; fileHit = true;
            const from = Math.max(0, i - ctxN), to = Math.min(L.length - 1, i + ctxN);
            for (let j = from; j <= to; j++) out.push(`${f}:${j + 1}${j === i ? ':' : '-'} ${L[j].slice(0, 240)}`);
            if (ctxN) out.push('--');
          }
          if (fileHit) nfiles++;
          if (hits >= max) break;
        }
        if (!hits) return 'Aucune correspondance';
        return `${hits} correspondance(s) dans ${nfiles} fichier(s)${hits >= max ? ' (limite atteinte)' : ''}\n` + out.join('\n').slice(0, 18000);
      },
    },
    tree: {
      desc: 'Arborescence du projet (ou d’un dossier) en arbre indenté, avec tailles optionnelles. args:{path?, depth?:1-8, sizes?:true}',
      run: async (a, c) => {
        const root = dirOf(a.path, c), maxDepth = Math.min(8, Math.max(1, +a.depth || 3)); let count = 0; const lines = [path.basename(root) + '/'];
        const rec = (dir, prefix, depth) => {
          let ents; try { ents = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
          ents = ents.filter(e => !['node_modules', '.git', '.kairo'].includes(e.name)).sort((x, y) => (y.isDirectory() - x.isDirectory()) || x.name.localeCompare(y.name));
          ents.forEach((e, i) => {
            if (count++ > 400) return;
            const last = i === ents.length - 1, size = a.sizes && e.isFile() ? '  (' + sizeStr(fs.statSync(path.join(dir, e.name)).size) + ')' : '';
            lines.push(prefix + (last ? '└── ' : '├── ') + e.name + (e.isDirectory() ? '/' : '') + size);
            if (e.isDirectory() && depth < maxDepth) rec(path.join(dir, e.name), prefix + (last ? '    ' : '│   '), depth + 1);
          });
        };
        rec(root, '', 1);
        if (count > 400) lines.push('… (affichage limité à 400 éléments)');
        return lines.join('\n');
      },
    },
    code_stats: {
      desc: 'Statistiques de code : fichiers, lignes (code / vides) par langage, plus gros fichiers. args:{path?}',
      run: async (a, c) => {
        const d = dirOf(a.path, c), by = {}, big = []; let files = 0, total = 0;
        for (const f of textFiles(d)) {
          let t; try { t = fs.readFileSync(path.join(d, f), 'utf8'); } catch { continue; }
          const L = t.split('\n'), blank = L.filter(l => !l.trim()).length, ext = path.extname(f).toLowerCase() || '(sans ext.)';
          const e = by[ext] || (by[ext] = { files: 0, code: 0, blank: 0 }); e.files++; e.code += L.length - blank; e.blank += blank;
          files++; total += L.length; big.push([f, L.length]);
        }
        if (!files) return 'Aucun fichier texte';
        const rows = Object.entries(by).sort((x, y) => y[1].code - x[1].code).slice(0, 12).map(([k, v]) => `${k.padEnd(12)} ${String(v.files).padStart(4)} fichiers  ${String(v.code).padStart(7)} lignes de code  ${String(v.blank).padStart(6)} vides`);
        return `${files} fichiers texte · ${total} lignes\n` + rows.join('\n') + '\nPlus gros : ' + big.sort((x, y) => y[1] - x[1]).slice(0, 5).map(([f, n]) => `${f} (${n})`).join(', ');
      },
    },
    find_todos: {
      desc: 'Liste les marqueurs TODO / FIXME / HACK / XXX présents dans le code. args:{path?, tags?:"TODO|FIXME|HACK|XXX"}',
      run: async (a, c) => {
        const d = dirOf(a.path, c), tags = String(a.tags || 'TODO|FIXME|HACK|XXX').replace(/[^\w|]/g, ''); if (!tags) throw new Error('tags invalides');
        const re = new RegExp('\\b(' + tags + ')\\b[:\\s(-]*(.*)', 'i'), out = [];
        for (const f of textFiles(d)) {
          if (/\.(md|txt|log)$/i.test(f) && /changelog|readme/i.test(f)) continue;
          let L; try { L = fs.readFileSync(path.join(d, f), 'utf8').split('\n'); } catch { continue; }
          L.forEach((l, i) => { const m = re.exec(l); if (m && out.length < 200) out.push(`${f}:${i + 1}  [${m[1].toUpperCase()}] ${m[2].trim().slice(0, 160)}`); });
        }
        return out.length ? out.length + ' marqueur(s)\n' + out.join('\n') : 'Aucun marqueur trouvé';
      },
    },
    outline_code: {
      desc: 'Plan d’un fichier de code : fonctions, classes, méthodes, titres (js, ts, py, gd, c/c++, go, rs, java, html, md) avec numéros de ligne. args:{path}',
      run: async (a, c) => {
        const { p, text } = readText(a.path, c); let ext = path.extname(p).slice(1).toLowerCase(); ext = OUTLINE_ALIAS[ext] || ext;
        const pats = OUTLINE[ext]; if (!pats) return 'Type non pris en charge : ' + (path.extname(p) || '(sans extension)');
        const out = [], L = text.split('\n');
        L.forEach((l, i) => {
          if (l.length > 300 || /^\s*(\/\/|#(?!#)|\*|--)/.test(l) && ext !== 'md' && ext !== 'py' && ext !== 'gd') return;
          if (ext === 'js' && /^\s{2,}(if|for|while|switch|catch|return|else)\b/.test(l)) return;
          if (pats.some(r => r.test(l))) out.push(String(i + 1).padStart(5) + '│ ' + l.trim().replace(/\s*\{\s*$/, '').slice(0, 140));
        });
        return out.length ? `${a.path} — ${out.length} définition(s) sur ${L.length} lignes\n` + out.slice(0, 300).join('\n') : 'Aucune définition détectée';
      },
    },
    csv_info: {
      desc: 'Aperçu d’un fichier CSV/TSV : colonnes, nombre de lignes, types probables, premières lignes. args:{path, delimiter?:",", rows?:5}',
      run: async (a, c) => {
        const { p, text } = readText(a.path, c); if (Buffer.byteLength(text) > 5 * 1048576) throw new Error('Fichier trop gros (5 Mo max)');
        const first = text.split('\n', 1)[0], delim = a.delimiter ? String(a.delimiter)[0] : (/\.tsv$/i.test(p) ? '\t' : [',', ';', '\t', '|'].map(d => [d, first.split(d).length]).sort((x, y) => y[1] - x[1])[0][0]);
        const rows = parseCsv(text, delim); if (rows.length < 1) return 'Fichier vide';
        const head = rows[0], data = rows.slice(1), n = Math.min(20, Math.max(1, +a.rows || 5));
        const type = i => { const v = data.slice(0, 200).map(r => (r[i] ?? '').trim()).filter(Boolean); if (!v.length) return 'vide'; if (v.every(x => /^-?\d+$/.test(x))) return 'entier'; if (v.every(x => /^-?\d+([.,]\d+)?$/.test(x))) return 'décimal'; if (v.every(x => /^\d{4}-\d{2}-\d{2}/.test(x))) return 'date'; return 'texte'; };
        return `${a.path} — ${data.length} ligne(s) · ${head.length} colonne(s) · séparateur ${delim === '\t' ? 'tabulation' : '« ' + delim + ' »'}\n` +
          head.map((h2, i) => `  ${i + 1}. ${h2 || '(sans nom)'} : ${type(i)}`).join('\n') + '\n\nAperçu :\n' + rows.slice(0, n + 1).map(r => r.join(' | ').slice(0, 200)).join('\n');
      },
    },
    git_status: {
      desc: 'État git du projet (branche, fichiers modifiés), en lecture seule. args:{}',
      run: async (a, c) => { const o = git(c, ['status', '--short', '--branch']).trim(); return o || 'Rien à signaler'; },
    },
    git_log: {
      desc: 'Derniers commits git (une ligne chacun), éventuellement pour un fichier. args:{n?:1-50, path?}',
      run: async (a, c) => { const n = Math.min(50, Math.max(1, +a.n || 10)); return git(c, ['log', '--oneline', '--decorate', '-n', String(n), ...gitPath(a, c)]).trim() || 'Aucun commit'; },
    },
    git_diff: {
      desc: 'Différences git non validées (résumé + contenu tronqué). args:{path?, staged?:true}',
      run: async (a, c) => {
        const base = a.staged ? ['diff', '--cached'] : ['diff'], P = gitPath(a, c), stat = git(c, [...base, '--stat', ...P]).trim();
        if (!stat) return 'Aucune différence';
        const body = git(c, [...base, '--unified=2', ...P]); return stat + '\n\n' + body.slice(0, 9000) + (body.length > 9000 ? '\n… (tronqué)' : '');
      },
    },
    hash_text: {
      desc: 'Calcule l’empreinte d’un texte ou d’un fichier (sha256, sha1, sha512, md5). args:{text? | path?, algo?:"sha256"}',
      run: async (a, c) => {
        const algo = String(a.algo || 'sha256').toLowerCase(); if (!['sha256', 'sha1', 'sha512', 'md5'].includes(algo)) throw new Error('algorithme inconnu : ' + algo);
        const data = a.path ? fs.readFileSync(readText(a.path, c).p) : String(a.text ?? ''); return algo + ' : ' + crypto.createHash(algo).update(data).digest('hex');
      },
    },
    encode_decode: {
      desc: 'Encode / décode un texte. args:{text, op:"base64-encode|base64-decode|url-encode|url-decode|hex-encode|hex-decode|json-escape|json-unescape"}',
      run: async a => {
        const t = String(a.text ?? ''), op = String(a.op || '').toLowerCase();
        const ops = {
          'base64-encode': () => Buffer.from(t, 'utf8').toString('base64'),
          'base64-decode': () => { if (/[^A-Za-z0-9+/=_\-\s]/.test(t)) throw new Error('base64 invalide'); return Buffer.from(t, 'base64').toString('utf8'); },
          'url-encode': () => encodeURIComponent(t),
          'url-decode': () => { try { return decodeURIComponent(t); } catch { throw new Error('séquence % invalide'); } },
          'hex-encode': () => Buffer.from(t, 'utf8').toString('hex'),
          'hex-decode': () => { if (!/^([0-9a-f]{2})*$/i.test(t.replace(/\s/g, ''))) throw new Error('hexadécimal invalide'); return Buffer.from(t.replace(/\s/g, ''), 'hex').toString('utf8'); },
          'json-escape': () => JSON.stringify(t).slice(1, -1),
          'json-unescape': () => { try { return JSON.parse('"' + t.replace(/"/g, '\\"') + '"'); } catch { throw new Error('échappement JSON invalide'); } },
        };
        if (!ops[op]) throw new Error('op inconnue : ' + (op || '(vide)') + ' — choix : ' + Object.keys(ops).join(', '));
        return ops[op]().slice(0, 20000);
      },
    },
    uuid_generate: {
      desc: 'Génère un ou plusieurs UUID v4. args:{count?:1-20}',
      run: async a => Array.from({ length: Math.min(20, Math.max(1, +a.count || 1)) }, () => crypto.randomUUID()).join('\n'),
    },
    regex_test: {
      desc: 'Teste une expression régulière sur un texte et montre les correspondances et groupes. args:{pattern, text, flags?:"i"}',
      run: async a => {
        const re = makeRe(a.pattern, a.flags, 'g'), t = String(a.text ?? '').slice(0, 20000), out = []; let m;
        while ((m = re.exec(t)) && out.length < 50) { out.push(`#${out.length + 1} @${m.index} « ${m[0].slice(0, 120)} »` + (m.length > 1 ? '  groupes : ' + m.slice(1).map(g => g === undefined ? '∅' : JSON.stringify(g)).join(', ') : '')); if (m[0] === '') re.lastIndex++; }
        return out.length ? out.length + ' correspondance(s)\n' + out.join('\n') : 'Aucune correspondance';
      },
    },
    date_calc: {
      desc: 'Calculs de dates : ajoute des jours/mois/années, ou compte les jours jusqu’à une date. args:{date?:"2026-10-31"(défaut=aujourd’hui), add_days?, add_months?, add_years?, until?}',
      run: async a => {
        const d0 = dateArg(a.date), d = new Date(Date.UTC(d0.getUTCFullYear(), d0.getUTCMonth(), d0.getUTCDate()));
        if (a.add_years) d.setUTCFullYear(d.getUTCFullYear() + Math.trunc(+a.add_years));
        if (a.add_months) d.setUTCMonth(d.getUTCMonth() + Math.trunc(+a.add_months));
        if (a.add_days) d.setUTCDate(d.getUTCDate() + Math.trunc(+a.add_days));
        const o = ['Date : ' + fmtDate(d)];
        if (a.until) { const u0 = dateArg(a.until), u = new Date(Date.UTC(u0.getUTCFullYear(), u0.getUTCMonth(), u0.getUTCDate())), n = Math.round((u - d) / 86400000); o.push(`Jusqu’au ${fmtDate(u)} : ${n} jour(s) (${(n / 7).toFixed(1)} semaines)`); }
        return o.join('\n');
      },
    },
    format_json: {
      desc: 'Reformate un fichier JSON (indentation, tri des clés optionnel) avec diff et sauvegarde annulable. args:{path, indent?:2, sort?:true}',
      run: async (a, c) => {
        const rel = String(a.path || ''), { p, inside } = writeGuard(rel, c), { text } = readText(rel, c); let j;
        try { j = JSON.parse(text); } catch (e) { throw new Error('JSON invalide : ' + e.message); }
        const sortKeys = v => Array.isArray(v) ? v.map(sortKeys) : v && typeof v === 'object' ? Object.fromEntries(Object.keys(v).sort().map(k => [k, sortKeys(v[k])])) : v;
        const after = JSON.stringify(a.sort ? sortKeys(j) : j, null, Math.min(8, Math.max(0, a.indent === undefined ? 2 : +a.indent))) + '\n';
        if (after === text) return { text: rel + ' est déjà formaté', path: rel };
        fs.writeFileSync(p, after); c.created?.add(p);
        return { text: 'Formaté ' + rel, diff: briefDiff(rel, text, after), changeId: inside ? await backup(c, p, text, after, true) : null, path: rel };
      },
    },
  };
};

module.exports.META = META;
module.exports.parseCsv = parseCsv;
