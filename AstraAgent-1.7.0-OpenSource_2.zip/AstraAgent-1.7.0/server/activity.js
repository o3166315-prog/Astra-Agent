// Live Activity + Error Center. Les événements viennent UNIQUEMENT de ce qui s'est réellement passé dans Astra
// (missions Swarm, appels modèles, erreurs serveur) : rien de simulé. Le flux vit en mémoire (400 derniers) ;
// les erreurs sont conservées sur disque (data/errors.json) avec un statut de résolution.
const S = require('./store');
const { classifyError } = require('./intelligence/fallback-manager');
const MAX_EVENTS = 400, MAX_ERRORS = 300, DEDUPE_MS = 10 * 60 * 1000;

function create(io) {
  const st = io || S;
  let seq = 0, errSeq = 0;
  const events = [];
  let errors = st.read('errors.json', []);
  let timer = null;
  const listeners = [];
  const flush = () => { clearTimeout(timer); timer = null; try { st.write('errors.json', errors.slice(-MAX_ERRORS)); } catch {} };
  const later = () => { if (!timer) { timer = setTimeout(flush, 1200); timer.unref && timer.unref(); } };
  const clip = (s, n) => String(s == null ? '' : s).slice(0, n);

  function log(source, message, o) {
    o = o || {};
    const ev = { id: ++seq, at: new Date().toISOString(), source, level: o.level || 'info', message: clip(message, 400), mission: o.mission || null, agent: o.agent || null, model: o.model || null, notify: !!o.notify };
    events.push(ev); if (events.length > MAX_EVENTS) events.shift();
    for (const f of listeners) { try { f(ev); } catch {} }
    return ev;
  }
  // filtre : since (id), source, level, mission, agent, model, q, limit
  function list(f) {
    f = f || {};
    let out = events.filter(e => e.id > (+f.since || 0));
    if (f.source) out = out.filter(e => e.source === f.source);
    if (f.level) out = out.filter(e => e.level === f.level);
    if (f.mission) out = out.filter(e => e.mission === f.mission);
    if (f.agent) out = out.filter(e => e.agent === f.agent);
    if (f.model) out = out.filter(e => e.model === f.model);
    if (f.q) { const q = String(f.q).toLowerCase(); out = out.filter(e => e.message.toLowerCase().includes(q)); }
    const limit = Math.max(1, Math.min(300, +f.limit || 120));
    return { events: out.slice(-limit), last: seq };
  }
  function reportError(e) {
    const message = clip(e.message, 400), origin = clip(e.origin || 'Système', 60), now = Date.now();
    const cls = classifyError(new Error(message));
    const dup = errors.find(x => x.origin === origin && x.message === message && x.status === 'open' && now - Date.parse(x.lastAt) < DEDUPE_MS);
    if (dup) { dup.count++; dup.lastAt = new Date().toISOString(); later(); return dup; }
    const rec = {
      id: 'err-' + Date.now().toString(36) + (++errSeq), at: new Date().toISOString(), lastAt: new Date().toISOString(), count: 1,
      severity: e.severity || (cls.kind === 'aborted' ? 'info' : 'error'), origin, message,
      context: clip(e.context || '', 600), solution: clip(e.solution || cls.hint, 300), kind: cls.kind, status: 'open'
    };
    errors.push(rec); if (errors.length > MAX_ERRORS) errors.shift(); later();
    log('error', origin + ' : ' + message, { level: rec.severity === 'info' ? 'info' : rec.severity === 'warn' ? 'warn' : 'error', notify: rec.severity !== 'info' });
    return rec;
  }
  const listErrors = f => { f = f || {}; return errors.filter(e => (!f.status || e.status === f.status) && (!f.severity || e.severity === f.severity)).slice().reverse(); };
  const openCount = () => errors.filter(e => e.status === 'open' && e.severity !== 'info').length;
  function setStatus(id, status) {
    if (!['open', 'resolved', 'ignored'].includes(status)) return null;
    const e = errors.find(x => x.id === id); if (!e) return null;
    e.status = status; e.resolvedAt = status === 'open' ? null : new Date().toISOString(); later(); return e;
  }
  return { log, list, reportError, listErrors, openCount, setStatus, flush, on: f => listeners.push(f), size: () => events.length };
}
module.exports = { create };
