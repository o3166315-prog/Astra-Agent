// Environnements d'exécution de l'agent : pilotes derrière une interface commune. Chaque capture est réelle (aucune simulation).
const {execFile,spawn}=require('child_process'),fs=require('fs'),os=require('os'),path=require('path'),{pathToFileURL}=require('url'),S=require('./store');
const W=process.platform==='win32',SIG=Buffer.from([0x89,0x50,0x4e,0x47]);
const sh=(f,a,o={})=>new Promise(r=>execFile(f,a,{encoding:'buffer',maxBuffer:1<<26,timeout:30000,windowsHide:true,...o},(e,so,se)=>r({ok:!e,out:so,err:(se&&se.length?se:Buffer.from(e?e.message:'')).toString().slice(0,400)})));
const has=async c=>(await sh(W?'where':'which',[c])).ok,wait=ms=>new Promise(r=>setTimeout(r,ms));
const host=(cmd,root,env)=>[cmd,[],{shell:true,cwd:root,...(env?{env}:{})}];
const xargs=(k,a)=>k==='click'?['mousemove',String(a.x),String(a.y),'click','1']:k==='type'?['type','--delay','30','--',a.text]:['key','--',a.key];
const exe=async()=>{if(process.env.KAIRO_BROWSER)return process.env.KAIRO_BROWSER;const e=process.env,c=W?[e['ProgramFiles(x86)']+'\\Microsoft\\Edge\\Application\\msedge.exe',e.ProgramFiles+'\\Microsoft\\Edge\\Application\\msedge.exe',e.ProgramFiles+'\\Google\\Chrome\\Application\\chrome.exe',e['ProgramFiles(x86)']+'\\Google\\Chrome\\Application\\chrome.exe']:process.platform==='darwin'?['/Applications/Google Chrome.app/Contents/MacOS/Google Chrome','/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge']:['chromium','chromium-browser','google-chrome','google-chrome-stable','microsoft-edge'];for(const x of c)if(W||process.platform==='darwin'?fs.existsSync(x):await has(x))return x;return null};
const PS=f=>`Add-Type -AssemblyName System.Windows.Forms,System.Drawing;Add-Type -TypeDefinition 'using System.Runtime.InteropServices;public class D{[DllImport("user32.dll")]public static extern bool SetProcessDPIAware();}';[D]::SetProcessDPIAware()|Out-Null;$b=[System.Windows.Forms.SystemInformation]::VirtualScreen;$m=New-Object System.Drawing.Bitmap $b.Width,$b.Height;$g=[System.Drawing.Graphics]::FromImage($m);$g.CopyFromScreen($b.Left,$b.Top,0,0,$m.Size);$m.Save('${f.replace(/'/g,"''")}',[System.Drawing.Imaging.ImageFormat]::Png)`;
const D=[
 {id:'browser',label:'Navigateur sans écran (Edge/Chrome) : affiche ta page web',perm:'SAFE',input:false,live:false,auto:true,
  check:async()=>(await exe())?{ok:true}:{ok:false,reason:'Edge ou Chrome introuvable (variable KAIRO_BROWSER possible)'},
  open:async()=>{const x=await exe();return{caps:{screenshot:true,navigation:true,click:false,type:false,key:false,background:true},spawn:host,close(){},shot:async(a,root)=>{let u=String(a.url||'index.html');
   if(!/^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?(\/|$)/.test(u)){if(/^[a-z][a-z0-9+.-]*:/i.test(u))throw new Error('URL refusée : seulement un fichier du projet ou http://localhost');const f=path.resolve(root,u);if(f!==root&&!f.startsWith(root+path.sep))throw new Error('Chemin hors du projet');if(!fs.existsSync(f))throw new Error('Fichier introuvable : '+u);u=pathToFileURL(f).href}
   const out=path.join(os.tmpdir(),'kairo-'+Date.now()+'.png');
   const r=await sh(x,['--headless=new','--disable-gpu','--hide-scrollbars',...(process.getuid&&process.getuid()===0?['--no-sandbox']:[]),'--user-data-dir='+path.join(os.tmpdir(),'kairo-profile'),'--window-size=1024,760','--virtual-time-budget=4000','--screenshot='+out,u],{timeout:45000});
   if(!fs.existsSync(out))throw new Error("Le navigateur n'a produit aucune capture : "+r.err);const b=fs.readFileSync(out);fs.unlinkSync(out);return require('./vision').crop(b,1024,640)}}}},
 {id:'xvfb',label:'Bureau virtuel Xvfb (Linux, WSL)',perm:'SAFE',input:true,live:true,auto:true,
  check:async()=>W?{ok:false,reason:'indisponible sur Windows natif (utilise Docker ou WSL2)'}:!(await has('Xvfb'))?{ok:false,reason:'Xvfb manquant (apt install xvfb imagemagick xdotool)'}:!(await has('import'))?{ok:false,reason:'ImageMagick manquant (import)'}:{ok:true},
  open:async()=>{let n=90;while(fs.existsSync('/tmp/.X11-unix/X'+n))n++;const d=':'+n,p=spawn('Xvfb',[d,'-screen','0','1024x640x24'],{stdio:'ignore'});
   for(let i=0;i<50&&!fs.existsSync('/tmp/.X11-unix/X'+n);i++)await wait(100);
   if(!fs.existsSync('/tmp/.X11-unix/X'+n)){p.kill();throw new Error("Xvfb n'a pas démarré")}
   const env={...process.env,DISPLAY:d},xd=await has('xdotool');return{caps:{screenshot:true,navigation:false,click:xd,type:xd,key:xd,background:true},spawn:(c,r)=>host(c,r,env),close(){p.kill()},
    shot:async()=>{const r=await sh('import',['-display',d,'-window','root','png:-']);if(!r.ok)throw new Error('import : '+r.err);return r.out},
    input:async(k,a)=>{if(!xd)throw new Error('xdotool non installé : clic/clavier indisponibles');const r=await sh('xdotool',xargs(k,a),{env});if(!r.ok)throw new Error('xdotool : '+r.err)}}}},
 {id:'docker',label:'Conteneur Docker isolé avec bureau Linux',perm:'SAFE',input:true,live:true,auto:true,
  check:async()=>!(await has('docker'))?{ok:false,reason:'Docker non installé'}:!(await sh('docker',['image','inspect','kairo-env'])).ok?{ok:false,reason:'image absente : docker build -t kairo-env server/env/docker'}:{ok:true},
  open:async(root,pid)=>{const n='kairo-'+pid;await sh('docker',['rm','-f',n]);const r=await sh('docker',['run','-d','--rm','--name',n,'-v',root+':/workspace','-w','/workspace','--memory','2g','--cpus','2','kairo-env']);if(!r.ok)throw new Error('docker run : '+r.err);await wait(1500);const xd=(await sh('docker',['exec',n,'sh','-c','command -v xdotool'])).ok;
   return{caps:{screenshot:true,navigation:false,click:xd,type:xd,key:xd,background:true},spawn:c=>['docker',['exec','-e','DISPLAY=:99','-w','/workspace',n,'sh','-lc',c],{}],close:()=>sh('docker',['rm','-f',n]),
    shot:async()=>{const r=await sh('docker',['exec',n,'import','-display',':99','-window','root','png:-']);if(!r.ok)throw new Error('import : '+r.err);return r.out},
    input:async(k,a)=>{const r=await sh('docker',['exec','-e','DISPLAY=:99',n,'xdotool',...xargs(k,a)]);if(!r.ok)throw new Error('xdotool : '+r.err)}}}},
 {id:'windows',label:'Bureau Windows réel (non isolé, lecture seule)',perm:'CONFIRM',input:false,live:true,auto:false,
  check:async()=>W?{ok:true}:{ok:false,reason:'Windows uniquement'},
  open:async()=>({caps:{screenshot:true,navigation:false,click:false,type:false,key:false,background:false},spawn:host,close(){},shot:async()=>{const f=path.join(os.tmpdir(),'kairo-s'+Date.now()+'.png'),r=await sh('powershell',['-NoProfile','-NonInteractive','-Command',PS(f)]);if(!fs.existsSync(f))throw new Error('PowerShell : '+r.err);const b=fs.readFileSync(f);fs.unlinkSync(f);return b}})}
];
const act={},shots=pid=>{const p=path.join(path.dirname(S.projDir(pid)),'shots');fs.mkdirSync(p,{recursive:true});return p};
exports.shots=shots;
exports.list=async pid=>({drivers:await Promise.all(D.map(async d=>({id:d.id,label:d.label,perm:d.perm,...await d.check()}))),active:act[pid]?(({d,inst})=>({id:d.id,label:d.label,perm:d.perm,live:d.live,caps:inst.caps}))(act[pid]):null});
exports.stop=async pid=>{const a=act[pid];if(!a)return;delete act[pid];a.procs.forEach(p=>{try{p.kill()}catch{}});await a.inst.close()};
exports.start=async(pid,id,root)=>{await exports.stop(pid);const d=D.find(x=>x.id===id);if(!d)throw new Error('Pilote inconnu');const c=await d.check();if(!c.ok)throw new Error(d.label+' : '+c.reason);act[pid]={d,root:root||S.projDir(pid),inst:await d.open(root||S.projDir(pid),pid),procs:new Set()}};
exports.killAll=()=>Object.keys(act).forEach(p=>exports.stop(p));
exports.get=pid=>{const a=act[pid];if(!a)return null;const root=a.root||S.projDir(pid);
 const save=async b=>{if(!b||b.length<64||!b.subarray(0,4).equals(SIG))throw new Error("La capture reçue n'est pas une image PNG valide");const name=Date.now()+'-'+Math.random().toString(36).slice(2,6)+'.png';fs.writeFileSync(path.join(shots(pid),name),b);return{name,url:'/api/shot?project='+pid+'&name='+name,w:b.readUInt32BE(16),h:b.readUInt32BE(20),mime:'image/png',b64:b.toString('base64')}};
 return{driver:a.d,caps:a.inst.caps,procs:a.procs,input:a.inst.input&&(a.inst.caps.click||a.inst.caps.type||a.inst.caps.key)?(k,x)=>a.inst.input(k,x):null,spawn:c=>a.inst.spawn(c,root),capture:async x=>save(await a.inst.shot(x||{},root)),raw:()=>a.inst.shot({},root)}};
