// Fallback Manager : bascule vers un modèle alternatif quand le modèle choisi échoue.
// RÈGLE DE SÉCURITÉ : une opération non idempotente (outil, écriture, commande) n'est JAMAIS relancée à l'aveugle.
function classifyError(err) {
  const m = String((err && err.message) || err || '');
  if (/interrompu|abort/i.test(m)) return { kind: 'aborted', retryable: false, hint: 'Opération interrompue par l’utilisateur.' };
  if (/401|403|cl[ée] api|api key|invalid.*key|unauthori[sz]ed/i.test(m)) return { kind: 'auth', retryable: false, hint: 'Vérifie la clé API du fournisseur dans Paramètres → Providers.' };
  if (/429|rate.?limit|quota|trop de requ/i.test(m)) return { kind: 'rate_limit', retryable: true, hint: 'Limite de requêtes atteinte : attends un peu ou utilise un autre modèle.' };
  if (/timeout|d[ée]lai|timed? out|ETIMEDOUT/i.test(m)) return { kind: 'timeout', retryable: true, hint: 'Le fournisseur n’a pas répondu dans le délai : vérifie la connexion ou essaie un modèle alternatif.' };
  if (/ECONNREFUSED|ENOTFOUND|r[ée]seau|network|connexion|ne r[ée]pond pas|fetch failed|ECONNRESET/i.test(m)) return { kind: 'network', retryable: true, hint: 'Connexion impossible : vérifie Internet ou que le serveur local (Ollama) est lancé.' };
  if (/5\d\d\b|server error|overloaded|surcharg/i.test(m)) return { kind: 'server', retryable: true, hint: 'Erreur côté fournisseur : réessaie plus tard.' };
  return { kind: 'unknown', retryable: false, hint: 'Consulte les détails techniques de l’erreur.' };
}

// candidates : [{provider, model, id}], call(candidate) : Promise, opts : { idempotent, wasExecuted(candidate), retriesPerModel, delay(ms), onAttempt }
async function runWithFallback(candidates, call, opts) {
  opts = opts || {};
  const attempts = [], retries = opts.retriesPerModel == null ? 1 : opts.retriesPerModel, delay = opts.delay || (ms => new Promise(r => setTimeout(r, ms)));
  const list = (candidates || []).filter(Boolean);
  if (!list.length) throw Object.assign(new Error('Aucun modèle candidat pour la reprise.'), { attempts });
  for (let i = 0; i < list.length; i++) {
    const c = list[i];
    for (let tryN = 0; tryN <= retries; tryN++) {
      const t0 = Date.now();
      try {
        const result = await call(c);
        attempts.push({ id: c.id || c.provider + '/' + c.model, ok: true, ms: Date.now() - t0, retry: tryN });
        return { result, used: c, attempts, fellBack: i > 0 };
      } catch (e) {
        const cls = classifyError(e);
        const rec = { id: c.id || c.provider + '/' + c.model, ok: false, ms: Date.now() - t0, retry: tryN, kind: cls.kind, error: String(e.message || e).slice(0, 240), hint: cls.hint };
        attempts.push(rec); if (opts.onAttempt) { try { opts.onAttempt(rec); } catch {} }
        if (cls.kind === 'aborted') throw Object.assign(e, { attempts });
        if (!opts.idempotent) {
          // Non idempotent : on vérifie si l'action a déjà eu lieu ; sinon on n'enchaîne pas non plus (décision humaine).
          let done = false;
          if (typeof opts.wasExecuted === 'function') { try { done = !!(await opts.wasExecuted(c)); } catch { done = true; } }
          throw Object.assign(new Error((done ? 'L’action a peut-être déjà été exécutée : pas de reprise automatique. ' : 'Opération non idempotente : pas de reprise automatique. ') + rec.error), { attempts, noRetry: true });
        }
        if (cls.retryable && tryN < retries) { await delay(600 * (tryN + 1)); continue; }
        break; // modèle suivant
      }
    }
  }
  const last = attempts[attempts.length - 1];
  throw Object.assign(new Error('Tous les modèles candidats ont échoué. Dernière erreur : ' + (last && last.error)), { attempts, exhausted: true });
}
module.exports = { classifyError, runWithFallback };
