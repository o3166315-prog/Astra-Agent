// Task Analyzer : classe une demande (code, débogage, raisonnement, vision, document, recherche, rédaction).
// Analyse HEURISTIQUE locale (mots-clés + taille), sans appel à un modèle : rapide, gratuit, mais approximative.
const CATS = [
  ['debugging', /\b(bug|erreur|error|exception|plante|crash|stack ?trace|d[ée]bog|debug|corrige|corriger|fix|ne marche pas|ne fonctionne pas|traceback)\b/i],
  ['coding', /\b(code|fonction|function|classe|class|script|programme|impl[ée]mente|refactor|api|algorithme|compile|python|javascript|typescript|node|react|c\+\+|godot|gdscript|html|css|sql|test unitaire)\b/i],
  ['vision', /\b(image|photo|capture|screenshot|sch[ée]ma|diagramme|logo|dessin|visuel)\b/i],
  ['document', /\b(r[ée]sum[ée]|r[ée]sumer|synth[èe]se|document|pdf|rapport|article|extrais|extraire|traduis|traduire)\b/i],
  ['research', /\b(compare|comparer|compar[ée]|recherche|cherche|alternatives?|meilleur(?:e)?s?|avantages|inconv[ée]nients|[ée]tat de l'art)\b/i],
  ['reasoning', /\b(explique|expliquer|pourquoi|raisonne|d[ée]montre|analyse|architecture|strat[ée]gie|calcule|probl[èe]me de logique|d[ée]cide)\b/i],
  ['writing', /\b([ée]cris un (?:texte|mail|email|message|article)|r[ée]dige|r[ée]diger|reformule|id[ée]e de|slogan|histoire|po[èe]me)\b/i]
];
const HARD = /\b(architecture|refonte|migration|s[ée]curit[ée]|concurren|asynchrone|multi-?agent|base de donn[ée]es|optimis|performance|syst[èe]me complet|plusieurs fichiers|tout le projet|tous les fichiers)\b/i;
const EASY = /\b(simple|petit|rapide|court|une ligne|juste|seulement)\b/i;
const tokens = s => Math.ceil(String(s || '').length / 3.2);

function analyze(input) {
  const o = typeof input === 'string' ? { text: input } : (input || {});
  const text = String(o.text || ''), reasons = [];
  const files = Array.isArray(o.files) ? o.files : [];
  const images = Array.isArray(o.images) ? o.images.length : (o.images | 0);
  const found = [];
  for (const [name, re] of CATS) if (re.test(text)) found.push(name);
  if (/(\.(py|js|ts|gd|cs|cpp|c|java|rs|go)\b)/i.test(text) && !found.includes('coding')) found.push('coding');
  if (/\b(trouve|cherche|d[ée]tecte).{0,30}\b(bugs?|erreurs?)\b/i.test(text) && !found.includes('debugging')) found.push('debugging');
  const imageFiles = files.filter(f => /\.(png|jpe?g|webp|gif|bmp)$/i.test(String(f.path || f.name || f))).length;
  const requiresVision = images > 0 || imageFiles > 0 || (/\b(cette|ce|l'|la) (image|photo|capture|screenshot)\b/i.test(text) && (images + imageFiles) > 0);
  if (requiresVision && !found.includes('vision')) found.unshift('vision');
  if (!found.length) found.push(text.length > 400 ? 'reasoning' : 'writing');
  // catégorie principale : débogage > code > vision > reste, dans l'ordre de CATS
  const order = ['vision', 'debugging', 'coding', 'document', 'research', 'reasoning', 'writing'];
  found.sort((a, b) => order.indexOf(a) - order.indexOf(b));
  const task = found[0];
  const n = files.length;
  let score = 0;
  if (text.length > 600) { score += 1; reasons.push('demande longue'); }
  if (n >= 3) { score += 1; reasons.push(n + ' fichiers joints'); }
  if (HARD.test(text)) { score += 2; reasons.push('mots-clés de tâche difficile'); }
  if (found.length >= 3) { score += 1; reasons.push('plusieurs types de travail'); }
  if (EASY.test(text) && score) score -= 1;
  const complexity = score >= 3 ? 'high' : score >= 1 ? 'medium' : 'low';
  const requiresTools = ['coding', 'debugging'].includes(task) || /\b(fichier|dossier|lance|ex[ée]cute|installe|test)\b/i.test(text);
  const fileChars = files.reduce((a, f) => a + (f.chars || f.size || 0), 0);
  const contextRequired = Math.max(1000, tokens(text) + Math.ceil(fileChars / 3.2) + (complexity === 'high' ? 8000 : complexity === 'medium' ? 3000 : 1000));
  let priority = 'quality';
  if (/\b(pas cher|[ée]conomique|gratuit|petit budget|moins cher)\b/i.test(text)) priority = 'cost';
  else if (/\b(rapide|vite|imm[ée]diat|urgent)\b/i.test(text) && complexity !== 'high') priority = 'speed';
  else if (complexity === 'low' && !['debugging', 'reasoning'].includes(task)) priority = 'balanced';
  if (o.priority && ['quality', 'cost', 'speed', 'balanced'].includes(o.priority)) priority = o.priority;
  return { task, categories: found, complexity, requiresVision, requiresTools, contextRequired, priority, filesCount: n, budget: o.budget ?? null, reasons, heuristic: true };
}
module.exports = { analyze, tokens, CATEGORIES: CATS.map(c => c[0]) };
