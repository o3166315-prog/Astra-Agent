// Performance Monitor : enregistre latence, échecs et volume des appels réels aux modèles.
// Rien n'est inventé : seules les mesures observées sont stockées. Les prompts et réponses ne sont JAMAIS conservés.
const MAX = 600;
function createMonitor(io) {
  const S = io || require('../store');
  let perf = S.read('intel-perf.json', []), sel = S.read('intel-selections.json', []), inc = S.read('intel-incidents.json', []);
  let timer = null;
  const flush = () => { clearTimeout(timer); timer = null; try { S.write('intel-perf.json', perf.slice(-MAX)); S.write('intel-selections.json', sel.slice(-200)); S.write('intel-incidents.json', inc.slice(-200)); } catch {} };
  const later = () => { if (!timer) { timer = setTimeout(flush, 1500); timer.unref && timer.unref(); } };
  const listeners = [];
  const emit = (type, d) => listeners.forEach(f => { try { f(type, d); } catch {} });
  function record(r) {
    const x = { at: new Date().toISOString(), provider: r.provider, model: r.model, ms: Math.max(0, Math.round(r.ms || 0)), ok: !!r.ok, inChars: r.inChars | 0, outChars: r.outChars | 0, error: r.ok ? '' : String(r.error || '').slice(0, 200), source: r.source || '' };
    perf.push(x); if (perf.length > MAX) perf.shift(); later(); emit('call', x); return x;
  }
  function stats(provider, model) {
    const rows = perf.filter(r => (!provider || r.provider === provider) && (!model || r.model === model));
    const ok = rows.filter(r => r.ok), ms = ok.map(r => r.ms).sort((a, b) => a - b);
    const sum = a => a.reduce((x, y) => x + y, 0);
    return {
      requests: rows.length, failures: rows.length - ok.length, failureRate: rows.length ? (rows.length - ok.length) / rows.length : null,
      avgMs: ms.length ? Math.round(sum(ms) / ms.length) : null, p95Ms: ms.length ? ms[Math.min(ms.length - 1, Math.floor(ms.length * 0.95))] : null,
      inChars: sum(rows.map(r => r.inChars)), outChars: sum(rows.map(r => r.outChars)), lastAt: rows.length ? rows[rows.length - 1].at : null
    };
  }
  function perModel() {
    const keys = [...new Set(perf.map(r => r.provider + '/' + r.model))];
    return keys.map(k => { const i = k.indexOf('/'); return { id: k, provider: k.slice(0, i), model: k.slice(i + 1), ...stats(k.slice(0, i), k.slice(i + 1)) }; }).sort((a, b) => b.requests - a.requests);
  }
  function logSelection(s) { const x = { at: new Date().toISOString(), ...s }; sel.push(x); later(); emit('selection', x); return x; }
  function logIncident(i) { const x = { id: 'inc-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5), at: new Date().toISOString(), ...i }; inc.push(x); later(); emit('incident', x); return x; }
  // Enveloppe chaque providers[k].chat : mesure toutes les requêtes (agent, swarm, benchmark, routage).
  function instrument(providers) {
    for (const [name, P] of Object.entries(providers)) {
      if (P.__astraWrapped || typeof P.chat !== 'function') continue;
      const orig = P.chat.bind(P);
      P.chat = async (s, m, msgs, o) => {
        const t0 = Date.now(), inChars = (msgs || []).reduce((a, x) => a + String(x.content || '').length, 0);
        try { const r = await orig(s, m, msgs, o); record({ provider: name, model: m, ms: Date.now() - t0, ok: true, inChars, outChars: String(r || '').length }); return r; }
        catch (e) { record({ provider: name, model: m, ms: Date.now() - t0, ok: false, error: e.message, inChars }); throw e; }
      };
      P.__astraWrapped = true;
    }
    return providers;
  }
  return { record, stats, perModel, logSelection, logIncident, instrument, flush, on: f => listeners.push(f), selections: () => sel.slice(-50).reverse(), incidents: () => inc.slice(-50).reverse(), _raw: () => perf };
}
module.exports = { createMonitor };
