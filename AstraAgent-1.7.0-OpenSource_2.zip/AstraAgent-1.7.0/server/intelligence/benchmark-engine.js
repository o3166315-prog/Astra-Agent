// Benchmark Engine : petites tâches standardisées, notées par des contrôles DÉTERMINISTES (pas de « modèle juge »).
// Limites assumées : les contrôles sont simples et le code produit n'est JAMAIS exécuté (analyse syntaxique + structure seulement).
// Chaque benchmark fait de vrais appels (≈ 5 requêtes par modèle) : il n'est lancé que sur demande explicite.
const vm = require('vm');
const clip = n => s => String(s || '').slice(0, n);
const stripFences = t => { const m = /```[a-z]*\n?([\s\S]*?)```/i.exec(String(t || '')); return (m ? m[1] : String(t || '')).trim(); };
const syntaxOk = code => { try { new vm.Script(code); return true; } catch { return false; } }; // compile seulement, n'exécute pas

const TASKS = [
  {
    id: 'coding', category: 'coding', title: 'Écrire une fonction',
    prompt: 'Écris en JavaScript une fonction nommée `isPalindrome(s)` qui renvoie true si la chaîne est un palindrome en ignorant la casse, les espaces et la ponctuation. Réponds uniquement avec le code.',
    score(out) {
      const code = stripFences(out), notes = []; let s = 0;
      if (syntaxOk(code)) { s += 40; notes.push('syntaxe valide'); } else notes.push('syntaxe invalide');
      if (/function\s+isPalindrome\b|isPalindrome\s*=/.test(code)) { s += 30; notes.push('fonction nommée correctement'); }
      if (/\breturn\b/.test(code)) s += 15;
      if (code.length >= String(out).trim().length * 0.5) { s += 15; notes.push('code seul'); }
      return { score: s, notes };
    }
  },
  {
    id: 'debugging', category: 'debugging', title: 'Détecter une erreur',
    prompt: 'Ce code doit additionner les éléments du tableau mais renvoie NaN. Trouve le bug et donne la correction en moins de 6 lignes.\n\nfunction sum(arr){ let t=0; for(let i=0;i<=arr.length;i++){ t+=arr[i]; } return t; }',
    score(out) {
      const t = String(out), notes = []; let s = 0;
      if (/(<=|off[- ]by[- ]one|d[ée]passe|hors (?:du )?tableau|undefined|NaN|length)/i.test(t)) { s += 40; notes.push('cause identifiée'); }
      if (/i\s*<\s*arr\.length|<\s*arr\.length|length\s*-\s*1|for\s*\(\s*const|reduce|for\s*\(\s*let\s+\w+\s+of/.test(t)) { s += 40; notes.push('correction proposée'); }
      if (t.length <= 1200) s += 20;
      return { score: s, notes };
    }
  },
  {
    id: 'document', category: 'document', title: 'Résumer un document',
    prompt: 'Résume en deux phrases maximum : « Le projet Lune réunit 3 agents autonomes chargés de produire un jeu en 12 jours. Le budget total est de 4 500 euros, dont 40 % pour les tests. Le responsable, Inès Carvalho, présentera le bilan le 5 mars. Le comité a aussi discuté de la couleur du logo, sans décision. » Conserve les chiffres clés.',
    score(out) {
      const t = String(out), notes = []; let s = 0;
      const facts = [[/\b3\b|trois/i, '3 agents'], [/12/, '12 jours'], [/4\s?500/, '4 500 €']];
      for (const [re, n] of facts) if (re.test(t)) { s += 25; notes.push(n); }
      if (t.trim().length <= 330) { s += 25; notes.push('concis'); }
      return { score: s, notes };
    }
  },
  {
    id: 'reasoning', category: 'reasoning', title: 'Raisonnement',
    prompt: 'Alice a 3 fois plus de billes que Bob. Ensemble, ils en ont 48. Combien Alice en a-t-elle ? Réponds uniquement par le nombre.',
    score(out) {
      const t = String(out).trim();
      if (/^\D*36\D*$/.test(t)) return { score: 100, notes: ['réponse exacte'] };
      if (/\b36\b/.test(t)) return { score: 60, notes: ['bonne valeur mais réponse bavarde'] };
      return { score: 0, notes: ['réponse incorrecte'] };
    }
  },
  {
    id: 'structured', category: 'structured', title: 'Produire du JSON valide',
    prompt: 'Réponds UNIQUEMENT avec un objet JSON de la forme {"name": chaîne, "tags": tableau de 3 chaînes, "priority": entier de 1 à 5} décrivant la tâche « corriger le bug de connexion ».',
    score(out) {
      const raw = String(out).trim(), notes = []; let s = 0, o = null;
      try { o = JSON.parse(stripFences(raw)); s += 50; notes.push('JSON valide'); } catch { return { score: 0, notes: ['JSON invalide'] }; }
      if (typeof o.name === 'string' && o.name) s += 15;
      if (Array.isArray(o.tags) && o.tags.length === 3 && o.tags.every(x => typeof x === 'string')) s += 20;
      if (Number.isInteger(o.priority) && o.priority >= 1 && o.priority <= 5) s += 15;
      if (!/^\s*[{`]/.test(raw)) s -= 10;
      return { score: Math.max(0, s), notes };
    }
  }
];

// chat(entry, messages) -> texte ; timeoutMs par requête. Séquentiel pour ne pas saturer les fournisseurs.
async function runBenchmark({ entries, chat, tasks, timeoutMs, onProgress, signal }) {
  const list = tasks || TASKS, results = {};
  for (const entry of entries) {
    const rows = [];
    for (const task of list) {
      if (signal && signal.aborted) break;
      const t0 = Date.now(); let row;
      try {
        const out = await Promise.race([
          chat(entry, [{ role: 'system', content: 'Tu es évalué sur une tâche courte. Réponds exactement comme demandé, sans préambule.' }, { role: 'user', content: task.prompt }]),
          new Promise((_, rej) => setTimeout(() => rej(new Error('délai dépassé')), timeoutMs || 90000))
        ]);
        const sc = task.score(out);
        row = { taskId: task.id, category: task.category, title: task.title, ok: true, score: sc.score, notes: sc.notes, ms: Date.now() - t0, sample: clip(240)(out) };
      } catch (e) { row = { taskId: task.id, category: task.category, title: task.title, ok: false, score: 0, notes: [], ms: Date.now() - t0, error: String(e.message || e).slice(0, 200) }; }
      rows.push(row); if (onProgress) onProgress(entry, row);
    }
    const byCategory = {};
    for (const r of rows) if (r.ok) byCategory[r.category] = { score: r.score };
    const okRows = rows.filter(r => r.ok);
    results[entry.id] = {
      at: new Date().toISOString(), results: rows, byCategory, failed: rows.length - okRows.length,
      overall: okRows.length ? Math.round(okRows.reduce((a, r) => a + r.score, 0) / okRows.length) : null,
      avgMs: okRows.length ? Math.round(okRows.reduce((a, r) => a + r.ms, 0) / okRows.length) : null
    };
  }
  return results;
}
module.exports = { runBenchmark, TASKS, stripFences, syntaxOk };
