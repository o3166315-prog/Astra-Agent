// Providers : Meta Model API (Muse), OpenAI, Anthropic, Gemini, Ollama, local (API compatible OpenAI).
const http=require('http'),https=require('https');
// POST en streaming via http natif : pas de timeout de 5 min (fetch coupait les générations lentes)
const post=(url,body,signal,onLine)=>new Promise((ok,ko)=>{const u=new URL(url),r=(u.protocol==='https:'?https:http).request(u,{method:'POST',headers:{'content-type':'application/json'},signal},res=>{
 if(res.statusCode>=400){let t='';res.on('data',d=>t+=d);res.on('end',()=>ko(new Error('Erreur Ollama HTTP '+res.statusCode+' : '+t.slice(0,200))));return}
 res.setEncoding('utf8');let buf='';res.on('data',d=>{buf+=d;let i;while((i=buf.indexOf('\n'))>=0){const l=buf.slice(0,i);buf=buf.slice(i+1);if(l.trim())try{onLine(JSON.parse(l))}catch(e){ko(e)}}});res.on('end',ok);res.on('error',ko)});
 r.on('error',ko);r.end(body)});
const netErr=(url,e)=>{const c=e.cause?.code||e.code||'';return new Error(e.name==='AbortError'||c==='ABORT_ERR'?'Interrompu':c==='ECONNREFUSED'?'Ollama ne répond pas ('+url.split('/')[2]+') : est-il lancé ? (ollama serve)':'Connexion avec Ollama coupée ('+(c||e.message)+') : il a peut-être manqué de mémoire. Essaie une tâche plus courte ou un modèle plus petit.')};
const J=async(url,o)=>{let r;try{r=await fetch(url,o)}catch(e){throw new Error('Réseau indisponible ('+url.split('/')[2]+') : '+e.message)}
 const t=await r.text();if(!r.ok)throw new Error(r.status===401||r.status===403?'Clé API invalide ('+r.status+')':'Erreur provider HTTP '+r.status+' : '+t.slice(0,200));return JSON.parse(t)};
const H=(k,x={})=>({'content-type':'application/json',...x});
const listOpenAIModels=async(base,key)=>{const r=await J(base.replace(/\/$/,'')+'/models',{headers:H(0,key?{authorization:'Bearer '+key}:{})});return (r.data||[]).map(x=>x.id).filter(x=>typeof x==='string').sort()};
const compatible=(label,base)=>({label,customEndpoint:!base,vision:async()=>null,models:async s=>{need(s.key,label);const endpoint=(s.url||base||'').replace(/\/$/,'');if(!endpoint)throw new Error('Configure the provider API base URL first.');return listOpenAIModels(endpoint,s.key)},chat:async(s,m,msgs)=>{need(s.key,label);const endpoint=(s.url||base||'').replace(/\/$/,'');if(!endpoint)throw new Error('Configure the provider API base URL first.');return oa(endpoint,s.key,m,msgs)}});
const genericProviders={
 openrouter:compatible('OpenRouter','https://openrouter.ai/api/v1'),
 groq:compatible('Groq','https://api.groq.com/openai/v1'),
 together:compatible('Together AI','https://api.together.xyz/v1'),
 fireworks:compatible('Fireworks AI','https://api.fireworks.ai/inference/v1'),
 deepseek:compatible('DeepSeek','https://api.deepseek.com/v1'),
 mistral:compatible('Mistral AI','https://api.mistral.ai/v1'),
 xai:compatible('xAI','https://api.x.ai/v1'),
 perplexity:compatible('Perplexity','https://api.perplexity.ai'),
 deepinfra:compatible('DeepInfra','https://api.deepinfra.com/v1/openai'),
 siliconflow:compatible('SiliconFlow','https://api.siliconflow.com/v1'),
 alibaba:compatible('Alibaba Cloud / DashScope','https://dashscope-intl.aliyuncs.com/compatible-mode/v1'),
 nebius:compatible('Nebius AI Studio','https://api.studio.nebius.com/v1'),
 baseten:compatible('Baseten (custom endpoint)',''),
 cloudflare:compatible('Cloudflare (custom gateway)','')
};
const need=(k,n)=>{if(!k)throw new Error('Clé API '+n+' manquante : Paramètres')};
const oaMsgs=ms=>ms.map(x=>x.images?{role:x.role,content:[{type:'text',text:x.content},...x.images.map(i=>({type:'image_url',image_url:{url:`data:${i.mime};base64,${i.b64}`}}))]}:x);
const anMsgs=ms=>ms.filter(x=>x.role!=='system').map(x=>x.images?{role:x.role,content:[...x.images.map(i=>({type:'image',source:{type:'base64',media_type:i.mime,data:i.b64}})),{type:'text',text:x.content}]}:x);
const oa=async(base,key,model,msgs)=>{const r=await J(base+'/chat/completions',{method:'POST',headers:H(0,key?{authorization:'Bearer '+key}:{}),body:JSON.stringify({model,messages:oaMsgs(msgs)})});return r.choices[0].message.content};
exports.providers={
 meta:{label:'Meta AI · Muse',vision:async(s,m)=>/spark|wonder|vision/i.test(m),models:async s=>{
  need(s.key,'Meta Model API');
  const r=await J('https://api.meta.ai/v1/models',{headers:H(0,{authorization:'Bearer '+s.key})});
  return (r.data||[]).map(x=>x.id).filter(Boolean);
 },chat:async(s,m,msgs)=>{need(s.key,'Meta Model API');return oa('https://api.meta.ai/v1',s.key,m,msgs)}},
 openai:{label:'OpenAI',vision:async()=>null,models:async s=>{need(s.key,'OpenAI');return listOpenAIModels('https://api.openai.com/v1',s.key)},chat:async(s,m,msgs)=>{need(s.key,'OpenAI');return oa('https://api.openai.com/v1',s.key,m,msgs)}},
 anthropic:{label:'Anthropic',vision:async()=>null,models:async s=>{need(s.key,'Anthropic');const r=await J('https://api.anthropic.com/v1/models',{headers:H(0,{'x-api-key':s.key,'anthropic-version':'2023-06-01'})});return (r.data||[]).map(x=>x.id).filter(Boolean).sort()},chat:async(s,m,msgs)=>{need(s.key,'Anthropic');
  const sys=msgs.filter(x=>x.role==='system').map(x=>x.content).join('\n');
  const r=await J('https://api.anthropic.com/v1/messages',{method:'POST',headers:H(0,{'x-api-key':s.key,'anthropic-version':'2023-06-01'}),body:JSON.stringify({model:m,max_tokens:4096,system:sys,messages:anMsgs(msgs)})});return r.content.map(c=>c.text||'').join('')}},
 gemini:{label:'Google Gemini',vision:async()=>null,models:async s=>{need(s.key,'Gemini');const r=await J('https://generativelanguage.googleapis.com/v1beta/models',{headers:H(0,{'x-goog-api-key':s.key})});return (r.models||[]).filter(x=>(x.supportedGenerationMethods||[]).includes('generateContent')).map(x=>String(x.name||'').replace(/^models\//,'')).filter(Boolean).sort()},chat:async(s,m,msgs)=>{need(s.key,'Gemini');
  const sys=msgs.filter(x=>x.role==='system').map(x=>x.content).join('\n');
  const r=await J(`https://generativelanguage.googleapis.com/v1beta/models/${m}:generateContent`,{method:'POST',headers:H(0,{'x-goog-api-key':s.key}),body:JSON.stringify({systemInstruction:{parts:[{text:sys}]},contents:msgs.filter(x=>x.role!=='system').map(x=>({role:x.role==='assistant'?'model':'user',parts:[{text:x.content},...(x.images||[]).map(i=>({inlineData:{mimeType:i.mime,data:i.b64}}))]}))})});
  return r.candidates[0].content.parts.map(p=>p.text||'').join('')}},
 ollama:{label:'Ollama (local)',vision:async(s,m)=>{try{const r=await J((s.url||'http://localhost:11434')+'/api/show',{method:'POST',headers:H(),body:JSON.stringify({model:m})});if(Array.isArray(r.capabilities))return r.capabilities.includes('vision')}catch{}return /llava|vision|-vl|vl:|minicpm-v|gemma3|moondream/i.test(m)},models:async s=>{const r=await J((s.url||'http://localhost:11434')+'/api/tags');return r.models.map(x=>x.name)},
  chat:async(s,m,msgs,o)=>{const url=(s.url||'http://localhost:11434')+'/api/chat';let out='';
  try{await post(url,JSON.stringify({model:m,messages:msgs.map(x=>x.images?{...x,images:x.images.map(i=>i.b64)}:x),stream:true,...(o?.plain?{}:{format:'json'}),keep_alive:'10m',options:{temperature:0.2,num_ctx:s.ctx||8192}}),o?.signal,j=>{if(j.error)throw new Error('Ollama : '+j.error);const pc=j.message?.content||'';out+=pc;o?.onChunk&&o.onChunk(out.length,pc,out)})}
  catch(e){if(/^(Ollama|Erreur Ollama)/.test(e.message))throw e;throw netErr(url,e)}return out}},
 local:{label:'Local (OpenAI-compatible)',vision:async()=>null,models:async s=>listOpenAIModels(s.url||'http://localhost:1234/v1',s.key),chat:(s,m,msgs)=>oa(s.url||'http://localhost:1234/v1',s.key,m,msgs)},
 ...genericProviders
};
