// Conversion locale d'images en représentation numérique compacte exploitable par un modèle SANS vision.
// Pipeline : octets -> détection format/dimensions -> décodage (PNG/JPEG/BMP natifs ; GIF/WebP/JPEG progressif via convertisseur système local)
// -> RGB (alpha composité sur blanc, ou RGBA) -> réduction contrôlée (moyenne par zones) -> orientation EXIF -> quantification/encodage -> texte structuré.
// Rien n'est envoyé à l'extérieur. Architecture à stratégies : on peut enregistrer plus tard une vraie vision multimodale (registerStrategy) sans rien réécrire.
const fs=require('fs'),os=require('os'),path=require('path'),{execFile}=require('child_process'),vision=require('./vision');
class ImageError extends Error{constructor(code,msg){super(msg);this.code=code}}
const E=(c,m)=>new ImageError(c,m);
const LIM={maxBytes:25*1024*1024,maxPixels:25e6,maxSize:256};
// ---------- 1. détection du format et des dimensions ----------
function sniff(b){if(!b||b.length<12)return null;
 if(b.readUInt32BE(0)===0x89504e47)return{format:'png',mime:'image/png',w:b.readUInt32BE(16),h:b.readUInt32BE(20)};
 if(b[0]===0xff&&b[1]===0xd8){let p=2;while(p+9<b.length){if(b[p]!==0xff){p++;continue}const m=b[p+1];if(m>=0xc0&&m<=0xcf&&![0xc4,0xc8,0xcc].includes(m))return{format:'jpeg',mime:'image/jpeg',h:b.readUInt16BE(p+5),w:b.readUInt16BE(p+7),progressive:m===0xc2};p+=2+b.readUInt16BE(p+2)}return{format:'jpeg',mime:'image/jpeg',w:0,h:0}}
 if(b.toString('latin1',0,3)==='GIF')return{format:'gif',mime:'image/gif',w:b.readUInt16LE(6),h:b.readUInt16LE(8)};
 if(b[0]===0x42&&b[1]===0x4d)return{format:'bmp',mime:'image/bmp',w:b.readInt32LE(18),h:Math.abs(b.readInt32LE(22))};
 if(b.toString('latin1',0,4)==='RIFF'&&b.toString('latin1',8,12)==='WEBP'){const t=b.toString('latin1',12,16);let w=0,h=0;try{if(t==='VP8 '){w=b.readUInt16LE(26)&0x3fff;h=b.readUInt16LE(28)&0x3fff}else if(t==='VP8L'){const v=b.readUInt32LE(21);w=(v&0x3fff)+1;h=((v>>14)&0x3fff)+1}else if(t==='VP8X'){w=1+b.readUIntLE(24,3);h=1+b.readUIntLE(27,3)}}catch{}return{format:'webp',mime:'image/webp',w,h}}
 return null}
// ---------- 2. décodeurs natifs ----------
const ZZ=[0,1,8,16,9,2,3,10,17,24,32,25,18,11,4,5,12,19,26,33,40,48,41,34,27,20,13,6,7,14,21,28,35,42,49,56,57,50,43,36,29,22,15,23,30,37,44,51,58,59,52,45,38,31,39,46,53,60,61,54,47,55,62,63];
const COS=(()=>{const t=new Float64Array(64);for(let x=0;x<8;x++)for(let u=0;u<8;u++)t[x*8+u]=(u?1:Math.SQRT1_2)*Math.cos((2*x+1)*u*Math.PI/16)/2;return t})();
const idct=(f,out,o,st)=>{const t=new Float64Array(64);for(let y=0;y<8;y++)for(let u=0;u<8;u++){let s=0;for(let v=0;v<8;v++)s+=COS[y*8+v]*f[v*8+u];t[y*8+u]=s}for(let y=0;y<8;y++)for(let x=0;x<8;x++){let s=0;for(let u=0;u<8;u++)s+=COS[x*8+u]*t[y*8+u];out[o+y*st+x]=s+128}};
const huff=(cnt,sy)=>{const maxcode=new Int32Array(18).fill(-1),valptr=new Int32Array(17),mincode=new Int32Array(17);let code=0,k=0;for(let l=1;l<=16;l++){valptr[l]=k;mincode[l]=code;code+=cnt[l-1];k+=cnt[l-1];maxcode[l]=cnt[l-1]?code-1:-1;code<<=1}return{maxcode,valptr,mincode,sy}};
const exifOrient=t=>{try{const le=t.toString('latin1',0,2)==='II',r16=o=>le?t.readUInt16LE(o):t.readUInt16BE(o),r32=o=>le?t.readUInt32LE(o):t.readUInt32BE(o),ifd=r32(4),n=r16(ifd);for(let i=0;i<n;i++){const e=ifd+2+i*12;if(r16(e)===0x0112)return r16(e+8)}}catch{}return 1};
function decodeJPEG(b,fast){let p=2,frame=null,ri=0,adobe=-1,orient=1;const qt=[],hdc=[],hac=[];
 while(p<b.length-1){if(b[p]!==0xff){p++;continue}const m=b[p+1];p+=2;if(m===0xff){p--;continue}if(m===0xd8||m===0x01||m===0x00||(m>=0xd0&&m<=0xd7))continue;if(m===0xd9)break;
  const end=p+b.readUInt16BE(p);let q=p+2;
  if(m===0xdb){while(q<end){const pq=b[q]>>4,tq=b[q]&15;q++;const t=new Int32Array(64);for(let i=0;i<64;i++){t[ZZ[i]]=pq?b.readUInt16BE(q):b[q];q+=pq?2:1}qt[tq]=t}}
  else if(m===0xc4){while(q<end){const tc=b[q]>>4,th=b[q]&15;q++;const cnt=b.subarray(q,q+16);q+=16;let n=0;for(let i=0;i<16;i++)n+=cnt[i];(tc?hac:hdc)[th]=huff(cnt,b.subarray(q,q+n));q+=n}}
  else if(m===0xc0||m===0xc1){if(b[q]!==8)throw E('UNSUPPORTED_FORMAT','JPEG non 8 bits');const n=b[q+5],comps=[];for(let i=0;i<n;i++){const o=q+6+i*3;comps.push({id:b[o],hs:b[o+1]>>4||1,vs:b[o+1]&15||1,tq:b[o+2],pred:0})}frame={h:b.readUInt16BE(q+1),w:b.readUInt16BE(q+3),comps}}
  else if(m>=0xc2&&m<=0xcf&&![0xc4,0xc8,0xcc].includes(m))throw E('NEEDS_EXTERNAL','JPEG progressif');
  else if(m===0xdd)ri=b.readUInt16BE(q);
  else if(m===0xee&&b.toString('latin1',q,q+5)==='Adobe')adobe=b[q+11];
  else if(m===0xe1&&b.toString('latin1',q,q+4)==='Exif')orient=exifOrient(b.subarray(q+6,end));
  else if(m===0xda){if(!frame)throw E('DECODE_FAILED','JPEG sans en-tête de trame');const ns=b[q],sc=[];for(let i=0;i<ns;i++){const c=frame.comps.find(x=>x.id===b[q+1+i*2]);if(!c)throw E('DECODE_FAILED','composante JPEG inconnue');c.td=b[q+2+i*2]>>4;c.ta=b[q+2+i*2]&15;sc.push(c)}
   if(frame.comps.length>3)throw E('NEEDS_EXTERNAL','JPEG CMJN');if(frame.comps.length===1){frame.comps[0].hs=frame.comps[0].vs=1}
   const {w,h,comps}=frame,mh=Math.max(...comps.map(c=>c.hs)),mv=Math.max(...comps.map(c=>c.vs)),mx_=Math.ceil(w/(8*mh)),my_=Math.ceil(h/(8*mv));
   for(const c of comps){c.pw=mx_*c.hs*(fast?1:8);c.ph=my_*c.vs*(fast?1:8);c.plane=new Uint8ClampedArray(c.pw*c.ph)}
   let pos=end,bb=0,bc=0;const bit=()=>{if(bc===0){if(pos>=b.length)throw E('DECODE_FAILED','JPEG tronqué');let v=b[pos++];if(v===0xff){if(b[pos]===0)pos++;else{pos--;v=0}}bb=v;bc=8}return(bb>>--bc)&1};
   const rd=n=>{let v=0;while(n--)v=(v<<1)|bit();return v},ext=(v,n)=>n&&v<(1<<(n-1))?v-(1<<n)+1:v,dec=t=>{let c=0;for(let l=1;l<=16;l++){c=(c<<1)|bit();if(t.maxcode[l]>=0&&c<=t.maxcode[l])return t.sy[t.valptr[l]+c-t.mincode[l]]}throw E('DECODE_FAILED','code Huffman invalide')};
   const blk=new Float64Array(64);let rst=0;
   for(let my=0;my<my_;my++)for(let mx=0;mx<mx_;mx++){
    if(ri&&rst===ri){bc=0;while(pos<b.length&&!(b[pos]===0xff&&b[pos+1]>=0xd0&&b[pos+1]<=0xd7))pos++;pos+=2;sc.forEach(c=>c.pred=0);rst=0}
    for(const c of sc){const Q=qt[c.tq],dT=hdc[c.td],aT=hac[c.ta];if(!Q||!dT||!aT)throw E('DECODE_FAILED','tables JPEG manquantes');
     for(let v=0;v<c.vs;v++)for(let hh=0;hh<c.hs;hh++){blk.fill(0);const t=dec(dT);c.pred+=t?ext(rd(t),t):0;blk[0]=c.pred*Q[0];
      for(let k=1;k<64;){const rs=dec(aT),r=rs>>4,s=rs&15;if(!s){if(r===15){k+=16;continue}break}k+=r;if(k>63)break;blk[ZZ[k]]=ext(rd(s),s)*Q[ZZ[k]];k++}
      if(fast)c.plane[(my*c.vs+v)*c.pw+mx*c.hs+hh]=blk[0]/8+128;else idct(blk,c.plane,(my*c.vs+v)*8*c.pw+(mx*c.hs+hh)*8,c.pw)}}
    rst++}
   const W=fast?Math.ceil(w/8):w,H=fast?Math.ceil(h/8):h,rgb=new Uint8Array(W*H*3),smp=(c,x,y)=>c.plane[((y*c.vs/mv)|0)*c.pw+((x*c.hs/mh)|0)];
   const cl=v=>v<0?0:v>255?255:v;
   for(let y=0;y<H;y++)for(let x=0;x<W;x++){const i=(y*W+x)*3;if(comps.length===1)rgb[i]=rgb[i+1]=rgb[i+2]=smp(comps[0],x,y);else{const Y=smp(comps[0],x,y),cb=smp(comps[1],x,y)-128,cr=smp(comps[2],x,y)-128;if(adobe===0){rgb[i]=Y;rgb[i+1]=smp(comps[1],x,y);rgb[i+2]=smp(comps[2],x,y)}else{rgb[i]=cl(Y+1.402*cr+.5);rgb[i+1]=cl(Y-.344136*cb-.714136*cr+.5);rgb[i+2]=cl(Y+1.772*cb+.5)}}}
   return{w:W,h:H,rgb,a:null,orient,reduced:fast?8:1,origW:w,origH:h}}
  p=end}
 throw E('DECODE_FAILED','JPEG sans données image')}
function decodeBMP(b){const off=b.readUInt32LE(10),hs=b.readUInt32LE(14),w=b.readInt32LE(18),hh=b.readInt32LE(22),bpp=b.readUInt16LE(28),comp=b.readUInt32LE(30);if(hs<40||(comp!==0&&comp!==3)||![8,24,32].includes(bpp))throw E('NEEDS_EXTERNAL','BMP non basique');
 const h=Math.abs(hh),rb=((w*bpp+31)>>5)<<2,rgb=new Uint8Array(w*h*3),pal=bpp===8?b.subarray(14+hs,14+hs+1024):null;
 for(let y=0;y<h;y++){const sy=hh>0?h-1-y:y;for(let x=0;x<w;x++){const o=off+sy*rb+x*(bpp/8),i=(y*w+x)*3;if(pal){const k=b[o]*4;rgb[i]=pal[k+2];rgb[i+1]=pal[k+1];rgb[i+2]=pal[k]}else{rgb[i]=b[o+2];rgb[i+1]=b[o+1];rgb[i+2]=b[o]}}}return{w,h,rgb,a:null,orient:1,reduced:1}}
// ---------- 3. convertisseur système local (GIF, WebP, JPEG progressif…) : aucune dépendance Node ----------
const run=(f,a)=>new Promise((ok,ko)=>execFile(f,a,{timeout:30000,windowsHide:true,maxBuffer:1<<24},(e,so)=>e?ko(e):ok(so)));
async function viaSystem(buf,fmt){const f=path.join(os.tmpdir(),'kairo-img-'+process.pid+'-'+Date.now()+'.'+({jpeg:'jpg'}[fmt]||fmt)),o=f+'.png';fs.writeFileSync(f,buf);
 const W=process.platform==='win32',ps=`Add-Type -AssemblyName System.Drawing;$i=[System.Drawing.Image]::FromFile('${f.replace(/'/g,"''")}');$i.Save('${o.replace(/'/g,"''")}',[System.Drawing.Imaging.ImageFormat]::Png);$i.Dispose()`;
 const tries=W?[['powershell',['-NoProfile','-NonInteractive','-Command',ps]]]:[...(process.platform==='darwin'?[['sips',['-s','format','png',f,'--out',o]]]:[]),['magick',[f+'[0]','-colorspace','sRGB',o]],['convert',[f+'[0]','-colorspace','sRGB',o]]];
 try{for(const[c,a]of tries){try{await run(c,a)}catch{continue}if(fs.existsSync(o)&&fs.statSync(o).size>0)return fs.readFileSync(o)}
  throw E('UNSUPPORTED_FORMAT',`Le format ${fmt.toUpperCase()} (ou cette variante) n'est pas décodable en natif et aucun convertisseur local n'est disponible (${W?'PowerShell/System.Drawing':'ImageMagick ou sips'}). Convertis l'image en PNG ou JPEG.`)}
 finally{for(const x of[f,o])try{fs.unlinkSync(x)}catch{}}}
async function decodeAny(buf,info,wantDim){const png=b=>{try{return{...vision.decode(b),orient:1,reduced:1}}catch(e){throw e instanceof ImageError?e:E('DECODE_FAILED','PNG illisible ou corrompu : '+e.message)}};
 if(info.format==='png')return{...png(buf),via:'natif PNG'};
 if(info.format==='jpeg'&&!info.progressive){try{const fast=info.w*info.h>3e6&&wantDim*8<=Math.max(info.w,info.h);const d=decodeJPEG(buf,fast);return{...d,via:fast?'natif JPEG (DC seul, 1/8)':'natif JPEG'}}catch(e){if(e.code!=='NEEDS_EXTERNAL'){if(e instanceof ImageError)throw e;throw E('DECODE_FAILED','JPEG illisible ou corrompu : '+e.message)}}}
 if(info.format==='bmp'){try{return{...decodeBMP(buf),via:'natif BMP'}}catch(e){if(e.code!=='NEEDS_EXTERNAL')throw E('DECODE_FAILED','BMP illisible : '+e.message)}}
 const pngBuf=await viaSystem(buf,info.format);return{...png(pngBuf),orient:1,via:'convertisseur système -> PNG'}}
// ---------- 4. réduction (moyenne par zones), orientation, quantification ----------
function resize(img,tw,th,keep){const{w,h,rgb,a}=img,ch=keep?4:3,out=new Uint8Array(tw*th*ch);
 for(let ty=0;ty<th;ty++){const y0=Math.floor(ty*h/th),y1=Math.max(y0+1,Math.floor((ty+1)*h/th));for(let tx=0;tx<tw;tx++){const x0=Math.floor(tx*w/tw),x1=Math.max(x0+1,Math.floor((tx+1)*w/tw));let r=0,g=0,bl=0,sa=0,n=0;
  for(let y=y0;y<y1;y++)for(let x=x0;x<x1;x++){const i=y*w+x,al=a?a[i]:255;if(keep){r+=rgb[i*3]*al;g+=rgb[i*3+1]*al;bl+=rgb[i*3+2]*al;sa+=al}else{r+=(rgb[i*3]*al+255*(255-al))/255;g+=(rgb[i*3+1]*al+255*(255-al))/255;bl+=(rgb[i*3+2]*al+255*(255-al))/255}n++}
  const o=(ty*tw+tx)*ch;if(keep){if(sa>0){out[o]=Math.round(r/sa);out[o+1]=Math.round(g/sa);out[o+2]=Math.round(bl/sa)}out[o+3]=Math.round(sa/n)}else{out[o]=Math.round(r/n);out[o+1]=Math.round(g/n);out[o+2]=Math.round(bl/n)}}}
 return{w:tw,h:th,px:out,ch}}
function orientate(r,o){if(!o||o===1)return r;const{w,h,px,ch}=r,sw=o>=5,dw=sw?h:w,dh=sw?w:h,out=new Uint8Array(dw*dh*ch);
 for(let y=0;y<dh;y++)for(let x=0;x<dw;x++){let sx,sy;switch(o){case 2:sx=w-1-x;sy=y;break;case 3:sx=w-1-x;sy=h-1-y;break;case 4:sx=x;sy=h-1-y;break;case 5:sx=y;sy=x;break;case 6:sx=y;sy=h-1-x;break;case 7:sx=w-1-y;sy=h-1-x;break;case 8:sx=w-1-y;sy=x;break;default:sx=x;sy=y}
  for(let c=0;c<ch;c++)out[(y*dw+x)*ch+c]=px[(sy*w+sx)*ch+c]}return{w:dw,h:dh,px:out,ch}}
const d2=(a,b)=>(a[0]-b[0])**2+(a[1]-b[1])**2+(a[2]-b[2])**2,SYM='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
function quantize(px,ch,n,K){const hist=new Map();for(let i=0;i<n;i++){const r=px[i*ch],g=px[i*ch+1],b=px[i*ch+2],k=((r>>4)<<8)|((g>>4)<<4)|(b>>4);let e=hist.get(k);if(!e)hist.set(k,e={n:0,r:0,g:0,b:0});e.n++;e.r+=r;e.g+=g;e.b+=b}
 const cand=[...hist.values()].map(e=>({n:e.n,c:[e.r/e.n,e.g/e.n,e.b/e.n]})).sort((a,b)=>b.n-a.n);let pal;
 if(cand.length<=K)pal=cand.map(e=>e.c);else{pal=[];const used=new Set();for(const thr of[60,36,20,8,0]){for(const e of cand){if(pal.length>=K)break;if(!used.has(e)&&pal.every(p=>d2(p,e.c)>thr*thr)){pal.push(e.c);used.add(e)}}if(pal.length>=K)break}}
 const idx=new Uint8Array(n);const assign=()=>{for(let i=0;i<n;i++){const p=[px[i*ch],px[i*ch+1],px[i*ch+2]];let b=0,bd=1e9;for(let j=0;j<pal.length;j++){const d=d2(p,pal[j]);if(d<bd){bd=d;b=j}}idx[i]=b}};
 assign();if(cand.length>K)for(let it=0;it<2;it++){const s=pal.map(()=>[0,0,0,0]);for(let i=0;i<n;i++){const t=s[idx[i]];t[0]+=px[i*ch];t[1]+=px[i*ch+1];t[2]+=px[i*ch+2];t[3]++}pal=pal.map((p,j)=>s[j][3]?[s[j][0]/s[j][3],s[j][1]/s[j][3],s[j][2]/s[j][3]]:p);assign()}
 const cnt=new Array(pal.length).fill(0);for(const v of idx)cnt[v]++;const ord=pal.map((_,i)=>i).sort((a,b)=>cnt[b]-cnt[a]),remap=[];ord.forEach((o,ni)=>remap[o]=ni);
 return{pal:ord.map(i=>pal[i].map(Math.round)),idx:idx.map(v=>remap[v])}}
// ---------- 5. représentations ----------
const hx=v=>v.toString(16).padStart(2,'0'),fmtNum=(v,norm)=>norm==='float'?String(Math.round(v/255*1000)/1000):String(v);
function render(enc,r,q,norm,matrix){const{w,h,px,ch}=r,rows=[];
 if(enc==='json'){for(let i=0;i<w*h;i++){const t=[0,1,2].map(c=>fmtNum(px[i*ch+c],norm));if(ch===4)t.push(fmtNum(px[i*ch+3],norm));rows.push('['+t.join(',')+']')}return'['+rows.join(',')+']'}
 if(enc==='hex'||enc==='hex12'){for(let y=0;y<h;y++){const t=[];for(let x=0;x<w;x++){const i=(y*w+x)*ch;t.push(enc==='hex'?hx(px[i])+hx(px[i+1])+hx(px[i+2]):(px[i]>>4).toString(16)+(px[i+1]>>4).toString(16)+(px[i+2]>>4).toString(16))}rows.push(t.join(enc==='hex'?' ':''))}return rows.join('\n')}
 for(let y=0;y<h;y++){const s=[];for(let x=0;x<w;x++)s.push(SYM[q.idx[y*w+x]]);
  if(enc==='palette')rows.push(matrix?s.join(' '):s.join(''));
  else{const runs=[];let a=0;while(a<s.length){let b=a;while(b<s.length&&s[b]===s[a])b++;runs.push(b-a>=4?s[a]+'*'+(b-a):s[a].repeat(b-a));a=b}rows.push(runs.join(' '))}}
 return rows.join('\n')}
const aspect=(w,h)=>{const g=(a,b)=>b?g(b,a%b):a,d=g(w,h),a=w/d,b=h/d;return a<=32&&b<=32?a+':'+b:(w/h).toFixed(2)+':1'};
const legend=pal=>pal.map((c,i)=>`${SYM[i]}=#${hx(c[0])}${hx(c[1])}${hx(c[2])}(${vision.name(...c)})`).join(' ');
const ENCDESC={json:'liste JSON de pixels [r,g,b] (ligne par ligne, du haut-gauche vers le bas-droite)',hex:'une couleur hexadécimale RRGGBB par pixel, séparées par des espaces, une ligne par rangée',hex12:'3 chiffres hexadécimaux par pixel (4 bits par canal : RGB), sans séparateur, une ligne par rangée',palette:'un symbole par pixel (voir légende de la palette), une ligne par rangée','palette-rle':'comme palette, avec compression par plages : "x*N" = le symbole x répété N fois ; une ligne par rangée'};
// ---------- 6. API principale ----------
async function prepare(buf,o={}){const maxBytes=o.maxBytes||LIM.maxBytes,maxPixels=o.maxPixels||LIM.maxPixels;
 if(!Buffer.isBuffer(buf)||!buf.length)throw E('EMPTY','Image vide ou illisible.');
 if(buf.length>maxBytes)throw E('TOO_LARGE',`Image trop lourde (${(buf.length/1048576).toFixed(1)} Mo ; maximum ${(maxBytes/1048576).toFixed(0)} Mo).`);
 const info=sniff(buf);if(!info)throw E('UNSUPPORTED_FORMAT','Format d’image non reconnu (PNG, JPEG, GIF, BMP ou WebP attendus).');
 if(info.w*info.h>maxPixels)throw E('TOO_MANY_PIXELS',`Image trop grande (${info.w}×${info.h} = ${(info.w*info.h/1e6).toFixed(1)} Mpx ; maximum ${(maxPixels/1e6).toFixed(0)} Mpx).`);
 const budget=Math.max(800,o.maxChars||6000),sizeReq=o.size==='auto'||!o.size?0:Math.max(4,Math.min(LIM.maxSize,+o.size||0)),norm=o.normalize==='float'?'float':'int',keepA=o.alpha==='keep';
 const t0=Date.now(),dec=await decodeAny(buf,info,sizeReq||128);
 const fullW=dec.origW||dec.w,fullH=dec.origH||dec.h,swap=dec.orient>=5,origW=swap?fullH:fullW,origH=swap?fullW:fullH;
 // couche texte "Vision Lite" (régions, couleurs, texte OCR) sur une version ≤1280 px, calculée avant pour réserver le budget
 let lite='',liteNote='';if(o.lite!==false&&dec.w*dec.h>=4096){try{const sc=Math.min(1,1280/Math.max(dec.w,dec.h)),lw=Math.max(1,Math.round(dec.w*sc)),lh=Math.max(1,Math.round(dec.h*sc)),r=sc<1?resize(dec,lw,lh,false):{w:dec.w,h:dec.h,px:dec.rgb},png=vision.encodeRGB(r.w,r.h,r.px),a=await vision.analyze(png,{noOcr:o.ocr===false});lite=a.text;liteNote=sc<1?`(analyse faite sur une version réduite à ${r.w}×${r.h}, coordonnées dans cette échelle)`:''}catch(e){lite=''}}
 const liteCost=lite?lite.length+120:0,dataBudget=Math.max(700,budget-liteCost-700);
 const maxStart=sizeReq||(budget>=14000?128:96),sizes=[128,96,64,48,40,32,24,16,12,8].filter(s=>s<=maxStart);if(!sizes.length||sizes[0]!==maxStart)sizes.unshift(maxStart);
 const baseDim=Math.min(sizes[0],Math.max(dec.w,dec.h)),sc0=Math.min(1,baseDim/Math.max(dec.w,dec.h));
 let big=resize(dec,Math.max(1,Math.round(dec.w*sc0)),Math.max(1,Math.round(dec.h*sc0)),keepA);big=orientate(big,dec.orient);
 const wantEnc=o.encoding&&o.encoding!=='auto'?o.encoding:'auto',notes=[];let chosen=null;
 for(const S of sizes){const sc=Math.min(1,S/Math.max(big.w,big.h)),r=sc<1?resize({w:big.w,h:big.h,rgb:keepA?big.px.filter((_,i)=>i%4<3):big.px,a:null},Math.max(1,Math.round(big.w*sc)),Math.max(1,Math.round(big.h*sc)),false):big;
  const n=r.w*r.h,q=quantize(r.px,r.ch,n,Math.min(o.colors||16,62)),encs=wantEnc==='auto'?['palette-rle','palette']:[wantEnc==='rle'?'palette-rle':wantEnc];
  for(const e of encs){const body=render(e,r,q,norm,false),total=body.length+(e.startsWith('palette')?legend(q.pal).length:0);if(!chosen||total<chosen.total)chosen={enc:e,r,q,body,total,S}}
  if(chosen&&chosen.total<=dataBudget){if(wantEnc!=='auto'||true)break}chosen=chosen&&chosen.total<=dataBudget?chosen:chosen}
 if(chosen&&chosen.total>dataBudget){notes.push('le budget de taille est très serré : résolution minimale atteinte')}
 if(sizeReq&&chosen.S<sizeReq&&Math.max(chosen.r.w,chosen.r.h)<Math.min(sizeReq,Math.max(big.w,big.h)))notes.push(`résolution demandée ${sizeReq} réduite à ${chosen.S} pour tenir dans le budget (~${Math.round(dataBudget/3.2)} jetons)`);
 const{r,q,enc}=chosen,body=chosen.body,pal=enc.startsWith('palette'),orientLabel=origW>origH*1.05?'paysage (landscape)':origH>origW*1.05?'portrait':'carré',channels=r.ch;
 const matrixTxt=o.matrix?render('palette',r,q,norm,true)+'\n\nLuminosité (0=noir … 9=blanc) :\n'+Array.from({length:r.h},(_,y)=>Array.from({length:r.w},(_,x)=>{const i=(y*r.w+x)*r.ch;return Math.min(9,Math.floor((0.2126*r.px[i]+0.7152*r.px[i+1]+0.0722*r.px[i+2])/25.6))}).join(' ')).join('\n'):'';
 const meta={name:o.name||'image',format:info.format.toUpperCase(),mime:info.mime,bytes:buf.length,original:{width:origW,height:origH},aspect:aspect(origW,origH),orientation:orientLabel,exifOrientation:dec.orient||1,decodedVia:dec.via,decodeMs:Date.now()-t0};
 const analysis={width:r.w,height:r.h,scale:+(Math.max(r.w,r.h)/Math.max(origW,origH)).toFixed(4),method:'moyenne par zones (box filter), sans agrandissement',colorspace:keepA?'RGBA (alpha conservé)':'RGB (transparence composée sur blanc)',channels,values:norm==='float'?'flottants normalisés 0–1':'entiers 0–255',encoding:enc,colors:pal?q.pal.length:undefined,chars:body.length,approxTokens:Math.round((body.length+(pal?legend(q.pal).length:0))/3.2),sizeRequested:sizeReq||'auto',notes};
 const head=`[IMAGE « ${meta.name} » — représentation numérique locale, générée sans modèle de vision]\nformat : ${meta.format} · dimensions originales : ${origW}×${origH} px (${meta.aspect}, ${orientLabel})${dec.orient>1?' · orientation EXIF '+dec.orient+' appliquée':''} · poids : ${Math.round(buf.length/1024)} Ko\nrésolution d’analyse : ${r.w}×${r.h} px (échelle ${analysis.scale}, ${analysis.method}) · espace couleur : ${analysis.colorspace} · canaux : ${channels} · valeurs : ${analysis.values}\nencodage : ${enc} — ${ENCDESC[enc]}${pal?` · ${q.pal.length} couleurs`:''}${notes.length?'\nremarque : '+notes.join(' ; '):''}\n`;
 const data=(pal?`légende : ${legend(q.pal)}\n`:'')+'données (ligne 1 = haut de l’image) :\n'+body+(matrixTxt?'\n\n[matrice lisible]\n'+matrixTxt:'');
 const text=head+data+(lite?`\n\n[ANALYSE DES RÉGIONS ${liteNote}]\n${lite}`:'')+'\n[/IMAGE]';
 const out={ok:true,meta,analysis,text,rep:{width:r.w,height:r.h,channels,encoding:enc,data:body,palette:pal?q.pal:undefined}};
 Object.defineProperty(out,'_px',{value:r.px,enumerable:false});
 out.json=()=>({width:r.w,height:r.h,channels,normalize:norm==='float'?'0-1':'0-255',original:meta.original,data:Array.from({length:r.w*r.h},(_,i)=>Array.from({length:channels},(_,c)=>norm==='float'?Math.round(r.px[i*channels+c]/255*1000)/1000:r.px[i*channels+c]))});
 return out}
// ---------- 7. stratégies d'interprétation d'image (extensible : vraie vision multimodale plus tard) ----------
const strategies=[];
const registerStrategy=s=>{strategies.push(s);strategies.sort((a,b)=>a.priority-b.priority)};
registerStrategy({id:'native',priority:10,available:async c=>c.mode!=='numeric'&&!!c.canSee,run:async(img)=>({images:[{mime:img.mime,b64:img.buf.toString('base64')}],info:{mode:'native'}})});
registerStrategy({id:'model',priority:20,available:async c=>c.mode!=='numeric'&&!!c.settings?.vision?.model&&!!c.describe,run:async(img,c)=>{const d=await c.describe(img);return{text:`[IMAGE « ${img.name} » décrite par le modèle de vision ${c.settings.vision.model}]\n${d}\n[/IMAGE]`,info:{mode:'model'}}}});
registerStrategy({id:'numeric',priority:90,available:async()=>true,run:async(img,c)=>{const r=await prepare(img.buf,{name:img.name,maxChars:c.budget,size:c.settings?.imageSize,encoding:c.settings?.imageEncoding,normalize:c.settings?.imageNormalize,matrix:c.settings?.imageMatrix,lite:c.settings?.imageLite});return{text:r.text,info:{mode:'numeric',meta:r.meta,analysis:r.analysis}}}});
async function resolve(img,ctx){for(const s of strategies){let ok=false;try{ok=await s.available(ctx)}catch{}if(!ok)continue;try{return{id:s.id,...await s.run(img,ctx)}}catch(e){if(s.id==='numeric')throw e}}throw E('NO_STRATEGY','Aucune stratégie disponible pour interpréter cette image.')}
module.exports={prepare,sniff,resolve,registerStrategy,ImageError,LIM,decodeJPEG,resize};
