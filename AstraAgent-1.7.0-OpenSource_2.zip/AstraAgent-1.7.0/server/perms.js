// Permissions : chaque action est classée SAFE / CONFIRM / DANGER avec une catégorie
// PROJECT_DEVELOPMENT | SYSTEM | NETWORK | DESTRUCTIVE. Les autorisations (grants) ne couvrent JAMAIS DESTRUCTIVE ni DANGER.
const fs=require('fs'),path=require('path'),os=require('os'),pathGuard=require('./path-guard');
const R={SAFE:0,CONFIRM:1,DANGER:2},mk=(level,cat,reason)=>({level,cat,reason}),OK=mk('SAFE','PROJECT_DEVELOPMENT','');
const worst=(a,b)=>R[b.level]>R[a.level]||(R[b.level]===R[a.level]&&b.reason&&!a.reason)?b:a,home=os.homedir();
const norm=(p,base)=>pathGuard.normalizeAnyPath(p,base||process.cwd());
const inside=(a,root)=>pathGuard.isInside(a,root);
const CRIT=/^(\/(etc|bin|sbin|usr|boot|sys|proc|dev|lib|lib64|var|root|opt)(\/|$)|[a-z]:\\(windows|program files|programdata))/i;
const critical=a=>CRIT.test(a)||a===path.parse(a).root||a===home;
const PATHY=/^(~|[a-zA-Z]:[\\/]|\.{1,2}([\\/]|$)|\/|[\w.@-]+[\\/])[^\s()'";|<>*?]*$/;
const isPath=t=>PATHY.test(t)&&!/^\/[a-z]$/i.test(t)&&!/^https?:/i.test(t);
const tok=s=>{const t=[];let c='',q=null,h=false;for(const ch of s){if(q){if(ch===q)q=null;else c+=ch;continue}if(ch==='"'||ch==="'"){q=ch;h=true;continue}if(/\s/.test(ch)){if(c||h)t.push(c);c='';h=false;continue}c+=ch}if(c||h)t.push(c);return t};
const split=s=>{const o=[];let c='',q=null;for(let i=0;i<s.length;i++){const ch=s[i];if(q){c+=ch;if(ch===q)q=null;continue}if(ch==='"'||ch==="'"){q=ch;c+=ch;continue}
 if((ch==='&'&&s[i+1]==='&')||(ch==='|'&&s[i+1]==='|')){o.push(c);c='';i++;continue}if(ch===';'||ch==='\n'||ch==='|'||(ch==='&'&&s[i+1]!=='>'&&s[i-1]!=='>')){o.push(c);c='';continue}c+=ch}o.push(c);return o.map(x=>x.trim()).filter(Boolean)};
const S=x=>new Set(x.split(' '));
const DANGER_EXE=S('format mkfs fdisk parted diskpart shutdown reboot halt poweroff sudo su runas doas bcdedit cipher takeown wipefs shred mount umount init telinit passwd useradd userdel usermod net netsh'),
 SYSTEM_EXE=S('apt apt-get yum dnf pacman brew choco winget scoop snap setx kill pkill killall taskkill systemctl service sc crontab schtasks docker podman kubectl xargs explorer open xdg-open'),
 NET_EXE=S('curl wget iwr irm invoke-webrequest invoke-restmethod ssh scp sftp ftp telnet nc ncat netcat nmap ping tracert traceroute nslookup dig rsync'),
 RM_EXE=S('rm del erase rmdir rd remove-item ri unlink rimraf'),BUILD_DIRS=S('node_modules dist build out .cache target __pycache__ .next obj bin .gradle .venv venv'),
 SAFE_EXE=S('node deno python python3 py pytest tsc tsx ts-node eslint prettier jest vitest cmake ctest cpack make gmake mingw32-make ninja msbuild gcc g++ cc c++ clang clang++ cl link ar ld rustc go gofmt dotnet java javac jar mvn gradle gradlew kotlinc godot godot4 blender chrome chromium chromium-browser google-chrome msedge firefox echo cat type ls dir pwd mkdir md touch cp copy xcopy robocopy mv move ren rename head tail wc sort uniq grep egrep rg findstr find tree sleep timeout which where whereis env printenv set date whoami hostname uname ver cls clear sed awk tr cut diff fc cmp tar unzip zip gzip gunzip 7z true false test pip pip3 npm npx pnpm yarn bun cargo git cd');
const NPM_NET=S('publish login logout adduser audit outdated view info show search ping deprecate owner access star dist-tag');
const lh=a=>a.some(x=>/localhost|127\.0\.0\.1|\[::1\]/i.test(x));
function pathCheck(t,st,exe){for(const x0 of t){let x=x0;if(x.startsWith('-')){if(!x.includes('='))continue;x=x.slice(x.indexOf('=')+1)}if(!isPath(x))continue;const a=norm(x,st.base);if(!inside(a,st.root))return mk('CONFIRM','SYSTEM','chemin hors du projet : '+a)}return OK}
function installCls(st,label,g){if(g)return mk('CONFIRM','SYSTEM','installation globale : '+label);if(st.ctx.userInstall)return mk('SAFE','PROJECT_DEVELOPMENT','autorisé par la demande (installation)');return mk('CONFIRM','PROJECT_DEVELOPMENT','installation de dépendances : '+label)}
function run(text,st,depth){let c=OK;for(const s of split(text)){c=worst(c,seg(s,st,depth));if(c.level==='DANGER')break}return c}
function ps(text,st,depth){if(/(remove-item|\bri\b|\brm\b|\bdel\b|rmdir)[^;|]*-recurse|format-volume|clear-disk|remove-partition|initialize-disk|stop-computer|restart-computer|set-executionpolicy|invoke-expression|\biex\b|(new|set|remove)-(service|itemproperty)|hk(lm|cu|cr|u):|registry::|disable-|uninstall-/i.test(text))return mk('DANGER','SYSTEM','commande PowerShell critique');
 let c=OK;for(const s of split(text)){const t=tok(s),h=t[0]||'';if(/^[A-Za-z]+-[A-Za-z]+$/.test(h)){const v=h.split('-')[0].toLowerCase();
  if(/^(invoke-webrequest|invoke-restmethod|start-bitstransfer)$/i.test(h)&&!lh(t))c=worst(c,mk('CONFIRM','NETWORK','accès réseau (PowerShell)'));
  else if(/^remove-item$/i.test(h))c=worst(c,mk('CONFIRM','DESTRUCTIVE','suppression (Remove-Item)'));
  else if(!['get','select','where','write','test','measure','sort','group','out','convertto','convertfrom','join','split','resolve','compare','foreach','format','new','set','add','copy','move','rename','set','start','import','export','clear'].includes(v))c=worst(c,mk('CONFIRM','SYSTEM','cmdlet non reconnu : '+h));
  else c=worst(c,pathCheck(t.slice(1),st,h))}else c=worst(c,seg(s,st,depth+1));if(c.level==='DANGER')break}return c}
function seg(s,st,depth){let t=tok(s);while(t.length&&/^[A-Za-z_]\w*=/.test(t[0]))t.shift();if(!t.length)return OK;let cls=OK;
 for(let i=0;i<t.length;i++){const m=/^\d?>>?(.*)$/.exec(t[i]);if(m){const tg=m[1]||t[i+1];if(tg&&!/^&/.test(tg)&&tg!=='/dev/null'&&tg.toLowerCase()!=='nul'){const a=norm(tg,st.base);if(!inside(a,st.root))cls=worst(cls,critical(a)?mk('DANGER','SYSTEM','redirection vers '+a):mk('CONFIRM','SYSTEM','redirection hors du projet : '+a))}t.splice(i,m[1]?1:2);i--}}
 if(!t.length)return cls;
 const exe=path.basename(t[0].replace(/\\/g,'/')).toLowerCase().replace(/\.(exe|cmd|bat|com|ps1)$/,''),args=t.slice(1),al=args.map(x=>x.toLowerCase()),sub=al.find(x=>!x.startsWith('-')&&!/^\/[a-z]$/.test(x)),has=(...f)=>al.some(x=>f.includes(x)),ret=c=>worst(cls,c);
 if(depth>3)return ret(mk('CONFIRM','SYSTEM','commande trop imbriquée'));
 if(['sh','bash','zsh','dash','ksh'].includes(exe)){const i=al.indexOf('-c');return i>=0?ret(run(args.slice(i+1).join(' '),st,depth+1)):ret(mk('CONFIRM','SYSTEM','shell interactif/script'))}
 if(exe==='cmd'){const i=al.findIndex(x=>x==='/c'||x==='/k');return i>=0?ret(run(args.slice(i+1).join(' '),st,depth+1)):ret(mk('CONFIRM','SYSTEM','cmd interactif'))}
 if(exe==='powershell'||exe==='pwsh'){if(has('-encodedcommand','-enc','-e'))return ret(mk('DANGER','SYSTEM','PowerShell encodé (opaque)'));const i=al.findIndex(x=>x==='-command'||x==='-c'),f=al.indexOf('-file');
  if(f>=0)return ret(pathCheck([args[f+1]||''],st,exe));return ret(ps(args.slice(i>=0?i+1:0).filter(x=>!/^-(noprofile|noninteractive|nologo|executionpolicy|bypass)$/i.test(x)).join(' '),st,depth+1))}
 if(['env','time','nohup','command','exec','call','start','nice','stdbuf'].includes(exe)){const r=args.filter(x=>x!==''&&!/^\/(b|wait|min|max|d)$/i.test(x));while(r[0]&&/^[A-Za-z_]\w*=/.test(r[0]))r.shift();return r.length?ret(run(r.join(' '),st,depth+1)):cls}
 if(['cd','chdir','pushd','set-location','sl'].includes(exe)){const x=args.find(a=>!/^\/[a-z]$/i.test(a)&&!a.startsWith('-'));if(!x)return cls;const a=norm(x,st.base);st.base=a;return inside(a,st.root)?cls:ret(mk('CONFIRM','SYSTEM','changement de dossier hors du projet : '+a))}
 if(DANGER_EXE.has(exe))return ret(mk('DANGER','SYSTEM','commande système critique : '+exe));
 // Inline interpreter snippets can access the host filesystem and process APIs;
 // they must never be silently treated as ordinary project-local commands.
 if(exe==='node'&&has('-e','--eval','-p','--print'))return ret(mk('CONFIRM','SYSTEM','exécution de code JavaScript inline'));
 if(['python','python3','py'].includes(exe)&&has('-c'))return ret(mk('CONFIRM','SYSTEM','exécution de code Python inline'));
 if(exe==='deno'&&['eval','-e','--eval'].some(x=>al.includes(x)))return ret(mk('CONFIRM','SYSTEM','exécution de code Deno inline'));

 if(exe==='dd')return ret(al.some(x=>x.startsWith('of='))?mk('DANGER','DESTRUCTIVE','dd : écriture brute sur un périphérique/fichier'):OK);
 if(exe==='reg')return ret(sub==='query'?OK:mk('DANGER','SYSTEM','modification du registre'));
 if(['chmod','chown','chgrp','icacls'].includes(exe)&&al.some(x=>['-r','-rf','--recursive','/t'].includes(x))){const tg=args.filter(isPath);return ret(tg.length&&tg.every(x=>inside(norm(x,st.base),st.root))?mk('CONFIRM','SYSTEM','permissions récursives'):mk('DANGER','SYSTEM','permissions récursives hors du projet'))}
 if(RM_EXE.has(exe)){const win=['del','erase','rmdir','rd'].includes(exe),fl=x=>x.startsWith('-')||(win&&/^\/[a-z]$/i.test(x)),rec=al.some(x=>/^-[a-z]*r/.test(x)&&exe==='rm'||x==='-recurse'||x==='--recursive'||x==='/s')||exe==='rimraf'||exe==='rmdir'&&!win,tg=args.filter(x=>!fl(x));
  if(!tg.length||tg.some(x=>/^(\*|\.|\.\.|\/|~|[a-zA-Z]:[\\/]?)$/.test(x)))return ret(mk('DANGER','DESTRUCTIVE','suppression massive ou de la racine'));
  const ab=tg.map(x=>norm(x,st.base));if(ab.some(a=>!inside(a,st.root)))return ret(mk('DANGER','DESTRUCTIVE','suppression hors du projet'));
  if(rec)return ret(ab.every(a=>BUILD_DIRS.has(path.basename(a).toLowerCase()))?mk('CONFIRM','DESTRUCTIVE','nettoyage d\'un dossier de build'):mk('DANGER','DESTRUCTIVE','suppression récursive'));
  return ret(ab.every(a=>st.ctx.created?.has(a))?OK:mk('CONFIRM','DESTRUCTIVE','suppression de fichier(s) non créé(s) par l\'agent'))}
 if(exe==='robocopy'&&has('/mir','/purge'))return ret(mk('CONFIRM','DESTRUCTIVE','robocopy en miroir (supprime à destination)'));
 if(exe==='find'&&has('-delete','-exec','-execdir','-ok'))return ret(mk('CONFIRM','SYSTEM','find avec action'));
 if(NET_EXE.has(exe))return ret(['curl','wget','iwr','irm','invoke-webrequest','invoke-restmethod','ping'].includes(exe)&&lh(args)?OK:mk('CONFIRM','NETWORK','accès réseau : '+exe));
 if(SYSTEM_EXE.has(exe))return ret(mk('CONFIRM','SYSTEM','commande système : '+exe));
 const g=has('-g','--global','-global');
 if(['npx','pnpx','bunx'].includes(exe)){const p=args.find(a=>!a.startsWith('-'))||'';return ret(has('--no-install','--no')||fs.existsSync(path.join(st.base,'node_modules','.bin',p))||fs.existsSync(path.join(st.base,'node_modules','.bin',p+'.cmd'))?pathCheck(args,st,exe):installCls(st,'npx '+p,false))}
 if(['npm','pnpm','yarn','bun'].includes(exe)){if(['install','i','add','ci','update','upgrade','up','exec','dlx','create'].includes(sub)||(exe==='yarn'&&!args.length)||(sub==='init'&&args.some(a=>/@|create-/.test(a))))return ret(installCls(st,exe+' '+(sub||'install'),g));if(NPM_NET.has(sub))return ret(mk('CONFIRM','NETWORK','npm '+sub));if(['test','run','start','dev','build','preview'].includes(sub))return ret(mk('CONFIRM','PROJECT_DEVELOPMENT','exécution d’un script du projet : '+exe+' '+sub));return ret(pathCheck(args,st,exe))}
 const py=['python','python3','py'].includes(exe)&&al[al.indexOf('-m')+1]==='pip',pip=['pip','pip3'].includes(exe)||py;
 if(pip){const ps_=py?al.slice(al.indexOf('pip')+1).find(x=>!x.startsWith('-')):sub;if(['install','download','wheel'].includes(ps_))return ret(installCls(st,'pip '+ps_,false));if(ps_==='uninstall')return ret(mk('CONFIRM','SYSTEM','pip uninstall'));return ret(OK)}
 if(exe==='cargo'){if(sub==='install')return ret(installCls(st,'cargo install',true));if(['add','update','fetch','publish','login','search','yank'].includes(sub))return ret(installCls(st,'cargo '+sub,false));return ret(pathCheck(args,st,exe))}
 if(exe==='go'&&(['get','install'].includes(sub)||(sub==='mod'&&['tidy','download','vendor'].includes(al[1]))))return ret(installCls(st,'go '+sub,false));
 if(exe==='dotnet'&&(['restore','tool','nuget','add'].includes(sub)))return ret(installCls(st,'dotnet '+sub,false));
 if(exe==='git'){if(['clone','fetch','pull','push','ls-remote','submodule','lfs'].includes(sub))return ret(mk('CONFIRM','NETWORK','git '+sub));
  if(sub==='config'&&has('--global','--system'))return ret(mk('CONFIRM','SYSTEM','git config global'));
  if(sub==='clean'||(sub==='reset'&&has('--hard'))||(['checkout','restore'].includes(sub)&&(has('--','.','-f','--force')))||(sub==='branch'&&has('-d'))||(sub==='stash'&&['drop','clear'].includes(al[1])))return ret(mk('CONFIRM','DESTRUCTIVE','git : perte possible de modifications ('+sub+')'));return ret(pathCheck(args,st,exe))}
 if(SAFE_EXE.has(exe))return ret(pathCheck(args,st,exe));
 if(isPath(t[0])||/^\.[\\/]/.test(t[0])){const a=norm(t[0],st.base);if(inside(a,st.root)&&fs.existsSync(a))return ret(pathCheck(args,st,exe))}
 return ret(mk('CONFIRM','SYSTEM','programme non reconnu : '+exe));
}
exports.norm=norm;exports.inside=inside;exports.critical=critical;
exports.classifyCommand=(cmd,root,ctx={})=>{const w=String(cmd);if(/\b(curl|wget|iwr|irm|invoke-webrequest)\b[^|;&\n]*\|\s*(sudo\s+)?(sh|bash|zsh|iex|invoke-expression|powershell|pwsh|python3?|node)\b/i.test(w)||/\b(iex|invoke-expression)\b/i.test(w))return mk('DANGER','NETWORK','exécution de code téléchargé ou évalué dynamiquement');
 const st={root,ctx,base:root};let c=run(w,st,0);for(const m of w.matchAll(/\$\(([^)]*)\)|`([^`]*)`/g))c=worst(c,run(m[1]||m[2],st,1));return c};
exports.fileOp=(op,p,root,ctx={})=>{const a=norm(p,root);
 if(inside(a,root)){if(op==='delete'){try{if(fs.statSync(a).isDirectory())return mk('DANGER','DESTRUCTIVE','suppression d\'un dossier')}catch{}return ctx.created?.has(a)?mk('SAFE','PROJECT_DEVELOPMENT','fichier créé par l\'agent'):mk('CONFIRM','DESTRUCTIVE','suppression d\'un fichier non créé par l\'agent')}return OK}
 if(op==='read')return mk('CONFIRM','SYSTEM','lecture hors du projet : '+a);
 if(op==='delete'||critical(a))return mk('DANGER','DESTRUCTIVE','écriture/suppression sur un chemin système ou hors du projet : '+a);
 return mk('CONFIRM','SYSTEM','écriture hors du projet : '+a)};
exports.classifyTool=(name,a,ctx)=>{a=a||{};const root=ctx.root;
 if(['read_file','list_dir','analyze_image'].includes(name))return exports.fileOp('read',a.path||'.',root,ctx);
 if(name==='write_file')return exports.fileOp('write',a.path,root,ctx);
 if(name==='delete_file')return exports.fileOp('delete',a.path,root,ctx);
 if(name==='run_command')return exports.classifyCommand(a.command,root,ctx);
 if(name==='fetch_url')return lh([String(a.url||'')])?OK:mk('CONFIRM','NETWORK','téléchargement : '+a.url);
 const lv=(...x)=>x.reduce((m,y)=>R[y.level]>R[m.level]?y:m);
 if(['read_lines','file_info','json_query','check_syntax'].includes(name))return exports.fileOp('read',a.path,root,ctx);
 if(name==='find_files')return exports.fileOp('read',a.path||'.',root,ctx);
 if(name==='diff_files')return lv(exports.fileOp('read',a.a,root,ctx),exports.fileOp('read',a.b,root,ctx));
 if(['edit_file','append_file','make_dir'].includes(name))return exports.fileOp('write',a.path,root,ctx);
 if(name==='replace_in_files')return exports.fileOp('write',a.path||'.',root,ctx);
 if(name==='move_file')return lv(exports.fileOp('write',a.from,root,ctx),exports.fileOp('write',a.to,root,ctx));
 if(name==='copy_file')return lv(exports.fileOp('read',a.from,root,ctx),exports.fileOp('write',a.to,root,ctx));
 if(name==='run_tests'){const t=require('./moretools').detectTest(root);return t?mk('CONFIRM','PROJECT_DEVELOPMENT','exécution du script de test du projet : '+t):OK}
 if(['search_regex','tree','code_stats','find_todos','outline_code','csv_info'].includes(name))return exports.fileOp('read',a.path||'.',root,ctx);
 if(name==='format_json')return exports.fileOp('write',a.path,root,ctx);
 if(name==='hash_text')return a.path?exports.fileOp('read',a.path,root,ctx):OK;
 if(['git_status','git_log','git_diff','encode_decode','uuid_generate','regex_test','date_calc'].includes(name))return OK;
 if(name==='http_request')return lh([String(a.url||'')])?OK:mk('CONFIRM','NETWORK','requête '+String(a.method||'GET').toUpperCase()+' : '+a.url);
 if(['search_files','remember','detect_tools','gui_click','gui_type','gui_key','calculate','get_time','system_info','project_summary','todo'].includes(name))return OK;
 if(name==='screenshot')return ctx.env?.driver.perm==='SAFE'?OK:mk('CONFIRM','SYSTEM','capture de ton bureau réel (peut montrer des données privées)');
 if(name.startsWith('mcp:'))return mk('CONFIRM','SYSTEM','outil MCP externe');
 return mk('CONFIRM','SYSTEM','outil non classé : '+name)};
exports.decide=(c,g={})=>{if(c.level==='SAFE')return{perm:'SAFE',auto:c.reason?'demande':''};if(c.level==='DANGER')return{perm:'DANGER'};
 const ok=(c.cat==='PROJECT_DEVELOPMENT'&&g.dev)||(c.cat==='SYSTEM'&&g.system)||(c.cat==='NETWORK'&&g.network);return ok?{perm:'SAFE',auto:'autorisation '+c.cat}:{perm:'CONFIRM'}};
