#!/usr/bin/env node
// Serveur MCP de démonstration pour Kairo : stdio, JSON-RPC 2.0 (un message par ligne), zéro dépendance.
// Outils : get_time, calculate, roll_dice, text_stats, note_add, notes_list
const fs=require('fs'),path=require('path'),readline=require('readline');
const safeCalculate=require('../server/moretools').calc;
const NOTES=path.join(__dirname,'notes.json');
const load=()=>{try{return JSON.parse(fs.readFileSync(NOTES,'utf8'))}catch{return[]}};
const text=t=>({content:[{type:'text',text:String(t)}]});
const TOOLS={
 get_time:{description:"Donne la date et l'heure actuelles, éventuellement dans un fuseau horaire (ex: Asia/Tokyo, Europe/Paris).",inputSchema:{type:'object',properties:{timezone:{type:'string',description:'Fuseau IANA, optionnel'}}},
  run:a=>{try{return text(new Date().toLocaleString('fr-FR',{timeZone:a.timezone||undefined,dateStyle:'full',timeStyle:'medium'})+(a.timezone?' ('+a.timezone+')':''))}catch{throw new Error('Fuseau horaire inconnu : '+a.timezone)}}},
 calculate:{description:'Calcule une expression mathématique (+ - * / % ^ et parenthèses).',inputSchema:{type:'object',properties:{expression:{type:'string'}},required:['expression']},
  run:a=>{const e=String(a.expression||'');const v=safeCalculate(e);return text(e+' = '+v)}},
 roll_dice:{description:'Lance des dés.',inputSchema:{type:'object',properties:{faces:{type:'number',description:'Nombre de faces (défaut 6)'},count:{type:'number',description:'Nombre de dés (défaut 1, max 20)'}}},
  run:a=>{const f=Math.min(1000,Math.max(2,Math.floor(+a.faces||6))),n=Math.min(20,Math.max(1,Math.floor(+a.count||1))),r=Array.from({length:n},()=>1+Math.floor(Math.random()*f));return text(n+'d'+f+' : '+r.join(', ')+' (total '+r.reduce((x,y)=>x+y,0)+')')}},
 text_stats:{description:"Compte les mots, caractères et lignes d'un texte.",inputSchema:{type:'object',properties:{text:{type:'string'}},required:['text']},
  run:a=>{const t=String(a.text||'');return text('mots : '+(t.trim()?t.trim().split(/\s+/).length:0)+', caractères : '+t.length+', lignes : '+t.split('\n').length)}},
 note_add:{description:'Ajoute une note (sauvegardée dans mcp-demo/notes.json).',inputSchema:{type:'object',properties:{text:{type:'string'}},required:['text']},
  run:a=>{if(!a.text)throw new Error('texte vide');const n=load();n.push({at:new Date().toISOString(),text:String(a.text).slice(0,500)});fs.writeFileSync(NOTES,JSON.stringify(n,null,2));return text('Note ajoutée (total '+n.length+')')}},
 notes_list:{description:'Liste les notes enregistrées.',inputSchema:{type:'object',properties:{}},run:()=>{const n=load();return text(n.length?n.map((x,i)=>(i+1)+'. '+x.text).join('\n'):'Aucune note')}}
};
const send=m=>process.stdout.write(JSON.stringify({jsonrpc:'2.0',...m})+'\n');
readline.createInterface({input:process.stdin}).on('line',l=>{let m;try{m=JSON.parse(l)}catch{return}
 const{id,method,params}=m;if(id===undefined)return; // notifications : pas de réponse
 if(method==='initialize')return send({id,result:{protocolVersion:params?.protocolVersion||'2024-11-05',capabilities:{tools:{}},serverInfo:{name:'kairo-demo',version:'1.0.0'}}});
 if(method==='ping')return send({id,result:{}});
 if(method==='tools/list')return send({id,result:{tools:Object.entries(TOOLS).map(([name,t])=>({name,description:t.description,inputSchema:t.inputSchema}))}});
 if(method==='tools/call'){const t=TOOLS[params?.name];if(!t)return send({id,error:{code:-32602,message:'Outil inconnu : '+params?.name}});
  try{return send({id,result:t.run(params.arguments||{})})}catch(e){return send({id,result:{isError:true,content:[{type:'text',text:'ERREUR : '+e.message}]}})}}
 send({id,error:{code:-32601,message:'Méthode inconnue : '+method}})});
