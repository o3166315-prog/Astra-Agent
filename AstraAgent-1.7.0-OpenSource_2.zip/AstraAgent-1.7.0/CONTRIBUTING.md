# Contributing to Astra Agent

Thanks for considering a contribution.

## Before opening a change
- Check existing issues and feature plans to avoid duplicate work.
- Keep changes focused and document user-visible behavior.
- Do not commit API keys, `.env` files, local `data/`, project workspaces, screenshots containing private data, or personal information.
- Do not weaken the SAFE / CONFIRM / DANGER permission model or the localhost-only server binding.

## Development

Requirements: Node.js 18 or newer. Astra Agent intentionally has no mandatory npm runtime dependencies.

```bash
npm test
npm run test:integration
npm start
```

Open `http://localhost:3000` on the same computer.

## Pull requests
Include:
1. A concise problem statement and proposed behavior.
2. Tests for new behavior and regressions.
3. Any required documentation or feature-plan updates.
4. A note identifying provider calls that were mocked versus tested against a real API.

Never claim a cloud provider integration was tested with a real account unless it actually was.
