# Kairo V4 (sur la base de V3 Final)

## Permissions et autonomie
- Nouveau moteur `server/perms.js` : analyse réelle des commandes (découpage &&, ||, ;, |, redirections, sous-commandes, $(...), bash -c / cmd /c / powershell -Command, chemins hors projet, sous-commandes npm/pip/git/cargo/go…). Fini la regex unique.
- SAFE : lire, chercher, créer/modifier les fichiers du projet, compiler, lancer/tester, commandes de développement normales. CONFIRM : installation de dépendances, réseau, hors-projet, programmes inconnus. DANGER : suppression récursive/massive, formatage, shutdown, sudo, registre, disque…
- Catégories PROJECT_DEVELOPMENT / SYSTEM / NETWORK / DESTRUCTIVE. Autorisations par projet (Paramètres) ou par discussion (« développe librement ce projet ») : elles ne couvrent jamais DESTRUCTIVE ni DANGER.
- La demande explicite de l'utilisateur autorise l'action demandée (ex. « installe les dépendances »).
- Les cartes d'action affichent la catégorie et la raison de toute confirmation.

## Agent
- Nouveau prompt système, protocole typé (action / observation / correction / clarification / final) compatible avec l'ancien JSON.
- Clarification intelligente (`server/intent.js`) : « Crée-moi une page web » -> 3-4 questions ciblées sans appel au modèle ; « Crée-moi un logiciel » -> base générique puis question.
- Vérification automatique : si du code a été écrit sans être exécuté/observé, l'agent est relancé une fois avant de conclure.
- Détection réelle des outils (`server/caps.js`) : Node, npm, Python, CMake, Git, PowerShell, compilateurs, Blender, Godot… injectée dans le contexte + outil `detect_tools`.
- Outils : `run_command` accepte désormais un code de sortie ≠ 0 comme erreur, hors-projet possible avec confirmation, `analyze_image`.
- Correction de la V3 : `askLoop` non déclaré (la détection de boucle plantait) ; `env.get()` utilisait le dossier par défaut au lieu du dossier réel du projet.

## Vision
- Vision Lite (`server/vision.js`) : décodeur PNG maison -> grille -> régions, boutons, objets, positions, couleurs, texte (Tesseract si installé, OCR ciblé des boutons), carte ASCII ; fonctionne avec tout modèle.
- Mémoire visuelle : résumé compact de chaque capture + différences entre captures (ajouts/retraits/déplacements), anciennes images retirées du contexte.
- Capacités explicites par pilote (capture, navigation, clic, saisie, touches, processus de fond). Navigateur sans écran : SAFE, recadré correctement (le viewport réel était plus petit que la fenêtre).

## Images importées (`server/imagecodec.js`)
- Détection du format/dimensions, décodage local PNG/JPEG/BMP natif (GIF, WebP, JPEG progressif via PowerShell/ImageMagick/sips), orientation EXIF, alpha, réduction par moyenne de zones, palette/RLE/hex/JSON, normalisation 0-255 ou 0-1, matrice lisible, limites 25 Mo / 25 Mpx, erreurs typées.
- Stratégies extensibles (`registerStrategy`) : vision native > modèle de vision > représentation numérique.

## Interface
- Thème Système / Clair / Sombre / Bleu nuit enregistré dans les réglages serveur.
- Captures et analyse dans le chat, timeline avec captures et résumés, capacités détectées, autorisations, réglages d'images et de vision.

## Tests
`npm test` : 13 tests d'images + 20 scénarios de bout en bout (faux modèle scripté, tout le reste réel).
