# Astra Agent 1.7.0 — Final planned public release

## Model Discovery

- Replaced hard-coded OpenAI model IDs with dynamic `GET /v1/models` discovery.
- Added Anthropic `GET /v1/models` discovery.
- Added Gemini model discovery and filters for models advertising `generateContent` support.
- Added OpenAI-compatible provider adapters for OpenRouter, Groq, Together AI, Fireworks AI, DeepSeek, Mistral, xAI, Perplexity, DeepInfra, SiliconFlow, Alibaba Cloud DashScope and Nebius AI Studio.
- Added custom-compatible endpoint entries for Baseten and Cloudflare gateways.
- Added configurable API base URL overrides for compatible providers.
- Added automated tests for provider registration, dynamic model listing and custom endpoint configuration.

## Important limitations

- OpenAI-compatible endpoints do not necessarily share identical feature support.
- Discovery returns model IDs; it does not establish pricing, account entitlement, regional access or all model capabilities.
- Vision/audio/tool/reasoning capabilities remain unknown unless confirmed by reliable provider metadata or an actual capability test.
- Baseten and Cloudflare entries require a deployment or gateway exposing the expected compatible API routes.
- This release does not add persistent cloud execution, remote account sync, a secure plugin sandbox or a complete image-generation engine.

## Base

Built from Astra Agent 1.6.1 Hardened. Existing security fixes and regression tests are retained.
