# Astra Agent 1.5.3 — correctifs de sécurité

## Faille corrigée (critique)
Avant 1.5.3, le serveur écoutait sur toutes les interfaces et `/api/exec` exécutait des commandes sans authentification : tout appareil du réseau local (ou un site web ouvert dans ton navigateur) pouvait lancer des commandes sur ton PC.

## Correctifs
- Écoute uniquement sur `127.0.0.1` (modifiable avec `ASTRA_HOST`, déconseillé).
- Contrôle de l'en-tête `Host` (protection contre le DNS-rebinding) et de l'en-tête `Origin` (protection contre les sites tiers). Hôtes supplémentaires : `ASTRA_ALLOWED_HOSTS=a,b`.
- Jeton aléatoire par démarrage, requis pour toutes les routes `/api/*`. Il est posé dans un cookie `HttpOnly; SameSite=Strict` quand tu ouvres la page : recharge la page après un redémarrage du serveur. Jeton fixe possible avec `ASTRA_TOKEN`.
- `/api/exec` (terminal) passe par le système de permissions : DANGER = bloqué, CONFIRM = fenêtre de confirmation dans l'interface, SAFE = exécuté.
- `GET /api/settings` et `GET /api/projects` ne modifient plus rien (POST obligatoire). `/api/settings` et `/api/models` valident le fournisseur.
- Fichiers statiques : contrôle de chemin strict + en-têtes `nosniff` et `no-referrer`.

## Tests
- Nouveau `tests/security.test.js` (14 tests). `npm test` l'inclut.
- Suite complète : 80 tests OK, 0 échec.

## Reste à faire
- Le nom « Kairo » apparaît encore dans l'interface (renommage prévu plus tard).
