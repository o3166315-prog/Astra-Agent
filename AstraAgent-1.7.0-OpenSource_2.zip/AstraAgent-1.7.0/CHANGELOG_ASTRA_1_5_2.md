# Astra Agent 1.5.2 — nouvelle identité

## Inclus dans cette première étape
- Nom du paquet npm : `astra-agent`.
- Version applicative : `1.5.2`.
- Titre, en-têtes et textes visibles de l’interface renommés Astra Agent.
- Persona de l’agent renommée Astra Agent.
- Journal de démarrage renommé.
- Variable `ASTRA_DATA` ajoutée avec priorité, tout en conservant `KAIRO_DATA` comme compatibilité.
- Documentation principale mise à jour.

## Compatibilité volontaire
Les dossiers internes `.kairo`, les noms historiques de fichiers et `KairoUI` ne sont pas renommés dans cette étape : ils peuvent être utilisés par des projets existants ou des extensions. Une migration de ces éléments sans rupture sera traitée séparément.

## Non inclus / à développer
Multi-agents, cloud persistant, synchronisation mobile, Live Monitor multi-agents, marketplace, comptes Web et packaging Electron ne sont pas encore implémentés. Ils restent les prochaines étapes de développement.
