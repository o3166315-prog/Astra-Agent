/* Astra Agent 1.5.6 — Voice, Self-Healing, Auto Testing and Mission Recovery UI.
   Speech recognition/synthesis use browser/OS services; model replies use the selected Astra provider. */
(function () {
  'use strict';
  let prefs = { provider: '', model: '', voiceURI: '', lang: 'fr-FR', rate: 1, autoSpeak: true };
  let live = false, recognition = null, speaking = false;

  const el = id => document.getElementById(id);
  const safeText = value => String(value == null ? '' : value);
  const speechApi = () => window.SpeechRecognition || window.webkitSpeechRecognition;

  function refreshVoiceChoices() {
    const select = el('voiceSelect');
    if (!select) return;
    const voices = window.speechSynthesis?.getVoices?.() || [];
    select.innerHTML = '<option value="">Voix système par défaut</option>' + voices.map(v =>
      `<option value="${esc(v.voiceURI)}">${esc(v.name)} · ${esc(v.lang)}</option>`
    ).join('');
    select.value = prefs.voiceURI || '';
  }

  function say(text) {
    if (!window.speechSynthesis || !window.SpeechSynthesisUtterance) return;
    const clean = safeText(text)
      .replace(/```[\s\S]*?```/g, ' Code omis. ')
      .replace(/https?:\/\/\S+/g, ' lien ')
      .replace(/[`*_#>]/g, ' ')
      .replace(/\s+/g, ' ').trim().slice(0, 12000);
    if (!clean) return;
    window.speechSynthesis.cancel();
    speaking = true;
    try { recognition?.stop(); } catch {}
    const utterance = new SpeechSynthesisUtterance(clean);
    utterance.lang = prefs.lang || 'fr-FR';
    utterance.rate = Number(prefs.rate) || 1;
    const voice = window.speechSynthesis.getVoices().find(v => v.voiceURI === prefs.voiceURI);
    if (voice) utterance.voice = voice;
    utterance.onend = utterance.onerror = () => {
      speaking = false;
      if (live && !busy) startRecognition();
    };
    window.speechSynthesis.speak(utterance);
  }

  function startRecognition() {
    const SR = speechApi();
    if (!live || busy || speaking || !SR || recognition) return;
    try {
      const r = new SR();
      r.lang = prefs.lang || 'fr-FR';
      r.continuous = true;
      r.interimResults = false;
      r.onresult = event => {
        for (let i = event.resultIndex; i < event.results.length; i++) {
          const result = event.results[i];
          const transcript = result.isFinal ? safeText(result[0]?.transcript).trim() : '';
          if (transcript && !busy && live) {
            el('message').value = transcript;
            r.stop();
            sendMessage();
            break;
          }
        }
      };
      r.onerror = event => {
        if (!['no-speech', 'aborted'].includes(event.error)) setStatus('Micro : ' + event.error, false);
      };
      r.onend = () => {
        if (recognition === r) recognition = null;
        if (live && !busy && !speaking) setTimeout(startRecognition, 500);
      };
      recognition = r;
      r.start();
    } catch (error) {
      recognition = null;
      setStatus('Micro indisponible : ' + error.message, false);
    }
  }

  async function dictate() {
    const SR = speechApi();
    if (!SR) { alert('Reconnaissance vocale non supportée. Essaie Chrome ou Edge.'); return; }
    const r = new SR();
    r.lang = prefs.lang || 'fr-FR';
    r.interimResults = true;
    r.onresult = event => {
      let transcript = '';
      for (const result of event.results) transcript += result[0].transcript;
      el('message').value = transcript;
    };
    r.onend = () => el('mic')?.classList.remove('active');
    r.onerror = () => el('mic')?.classList.remove('active');
    el('mic')?.classList.add('active');
    try { r.start(); } catch (error) { el('mic')?.classList.remove('active'); alert(error.message); }
  }

  async function toggleLive() {
    if (live) {
      live = false;
      try { recognition?.stop(); } catch {}
      recognition = null;
      window.speechSynthesis?.cancel();
      speaking = false;
      el('voiceLive')?.classList.remove('active');
      el('voiceLive').title = 'Démarrer la conversation vocale';
      setStatus('Conversation vocale arrêtée', false);
      return;
    }
    if (!speechApi()) { alert('La reconnaissance vocale n’est pas disponible dans ce navigateur. Essaie Chrome ou Edge.'); return; }
    if (prefs.provider) {
      el('provider').value = prefs.provider;
      await loadModels();
      if (prefs.model && Array.from(el('model').options).some(o => o.value === prefs.model)) el('model').value = prefs.model;
    }
    live = true;
    el('voiceLive')?.classList.add('active');
    el('voiceLive').title = 'Arrêter la conversation vocale';
    setStatus('Écoute…', false);
    startRecognition();
  }

  function mountSettings() {
    const host = el('settingsBody');
    if (!host || el('astraVoiceSettings')) return;
    const block = document.createElement('div');
    block.className = 'panel-block';
    block.id = 'astraVoiceSettings';
    block.innerHTML = `
      <h4>Voix & conversation avec les agents</h4>
      <div class="row"><select class="select grow" id="voiceProvider"><option value="">Fournisseur de l’en-tête</option>${Object.entries(S.providers).map(([k,v]) => `<option value="${esc(k)}">${esc(v)}</option>`).join('')}</select><select class="select grow" id="voiceModel"><option value="">Modèle de l’en-tête</option></select></div>
      <div class="row" style="margin-top:6px"><select class="select grow" id="voiceLang"><option value="fr-FR">Français</option><option value="en-US">English (US)</option><option value="en-GB">English (UK)</option><option value="ar-DZ">العربية</option></select><select class="select grow" id="voiceSelect"><option value="">Voix système par défaut</option></select></div>
      <div class="row" style="margin-top:6px;align-items:center"><span class="panel-note">Vitesse</span><input class="grow" type="range" id="voiceRate" min="0.7" max="1.4" step="0.1"><label class="panel-note"><input type="checkbox" id="voiceAutoSpeak"> Lire les réponses en mode Live</label></div>
      <div class="row" style="margin-top:6px"><button class="action" id="voiceSave">Enregistrer</button><button class="action" id="voiceTest">Tester la voix</button></div>
      <div class="panel-note" style="margin-top:6px">Le fournisseur et le modèle sélectionnés génèrent les réponses. La reconnaissance et la synthèse vocales utilisent les services vocaux du navigateur / système et les voix installées. La reconnaissance peut nécessiter Internet selon le navigateur.</div>`;
    host.prepend(block);
    el('voiceProvider').value = prefs.provider || '';
    el('voiceLang').value = prefs.lang || 'fr-FR';
    el('voiceRate').value = prefs.rate || 1;
    el('voiceAutoSpeak').checked = prefs.autoSpeak !== false;
    refreshVoiceChoices();
    const loadVoiceModels = async () => {
      const provider = el('voiceProvider').value;
      if (!provider) { el('voiceModel').innerHTML = '<option value="">Modèle de l’en-tête</option>'; return; }
      const result = await api('models?p=' + encodeURIComponent(provider));
      el('voiceModel').innerHTML = (result.models?.length ? result.models : ['']).map(m => `<option value="${esc(m)}">${esc(m || 'Aucun modèle')}</option>`).join('');
      if (prefs.model && result.models?.includes(prefs.model)) el('voiceModel').value = prefs.model;
    };
    el('voiceProvider').onchange = loadVoiceModels;
    loadVoiceModels();
    el('voiceSave').onclick = async () => {
      const next = { provider: el('voiceProvider').value, model: el('voiceModel').value, voiceURI: el('voiceSelect').value,
        lang: el('voiceLang').value, rate: Number(el('voiceRate').value), autoSpeak: el('voiceAutoSpeak').checked };
      const result = await api('voice-settings', 'POST', next);
      if (result.error) { alert(result.error); return; }
      prefs = { ...prefs, ...next };
      el('voiceSave').textContent = '✓ Enregistré';
    };
    el('voiceTest').onclick = () => say('Bonjour, je suis Astra Agent. La synthèse vocale est prête.');
  }

  async function renderHealing(q) {
    q.innerHTML = `<div class="panel-block"><h4>Astra Self-Healing</h4><div class="panel-note">Diagnostic en lecture seule des erreurs et de la syntaxe. Aucune correction n’est appliquée sans ton accord.</div><div class="row" style="margin-top:8px"><button class="action" id="healRefresh">Actualiser</button><button class="action primary" id="healDiagnose">Analyser avec l’IA</button></div></div><div id="healScan" class="panel-block">Analyse locale…</div><div id="healErrors" class="panel-block"></div><div id="healAnswer" class="panel-block"></div>`;
    const load = async () => {
      const result = await api('self-healing?project=' + encodeURIComponent(cur));
      if (!q.isConnected) return;
      if (result.error) { el('healScan').textContent = result.error; return; }
      const scan = result.scan || {};
      el('healScan').innerHTML = `<h4>Vérification locale</h4><div class="panel-note">${scan.filesScanned || 0} fichiers parcourus · ${scan.checked?.javascript || 0} JavaScript · ${scan.checked?.json || 0} JSON</div>` +
        (scan.issues?.length ? scan.issues.map(x => `<div class="panel-note" style="color:var(--danger);margin-top:5px"><b>${esc(x.file)}</b> · ${esc(x.kind)}<br>${esc(x.message)}</div>`).join('') : '<div class="panel-note" style="color:var(--ok)">Aucune erreur de syntaxe détectée dans les fichiers vérifiés.</div>');
      const errors = result.errors || [];
      el('healErrors').innerHTML = '<h4>Erreurs ouvertes enregistrées</h4>' + (errors.length ? errors.slice(0, 12).map(e => `<div class="panel-block"><b>${esc(e.origin)}</b><div class="panel-note">${esc(e.lastAt || e.at)} · ${esc(e.kind || e.severity)}</div><div>${esc(e.message)}</div>${e.solution ? `<div class="panel-note">Piste : ${esc(e.solution)}</div>` : ''}</div>`).join('') : '<div class="panel-note">Aucune erreur ouverte enregistrée.</div>');
    };
    el('healRefresh').onclick = load;
    await load();
    el('healDiagnose').onclick = async () => {
      const button = el('healDiagnose'); button.disabled = true; button.textContent = 'Analyse…';
      const result = await api('self-healing/diagnose', 'POST', { project: cur, provider: el('provider').value, model: el('model').value });
      button.disabled = false; button.textContent = 'Analyser avec l’IA';
      if (result.error) { el('healAnswer').textContent = 'Diagnostic indisponible : ' + result.error; return; }
      el('healAnswer').innerHTML = `<h4>Diagnostic proposé</h4><pre style="white-space:pre-wrap;max-height:320px;overflow:auto">${esc(result.answer)}</pre><button class="action primary" id="healPrepare">Préparer une correction</button><div class="panel-note">Aucun fichier n’a été modifié pendant le diagnostic.</div>`;
      el('healPrepare').onclick = () => {
        if (!confirm('Envoyer ce diagnostic à Astra Agent pour qu’il prépare les corrections ? Les opérations sensibles demanderont encore une validation.')) return;
        el('message').value = 'Analyse ce diagnostic, identifie la correction minimale, vérifie les fichiers concernés, explique les changements, puis applique uniquement les corrections nécessaires et lance les tests disponibles. Diagnostic :\n' + result.answer;
        tab = 'chat'; renderRightTabs(); renderRight(); el('message').focus();
      };
    };
  }

  async function renderTesting(q) {
    q.innerHTML = `<div class="panel-block"><h4>Astra Auto Testing</h4><div id="testCommand" class="panel-note">Détection des tests…</div><div class="row" style="margin-top:8px"><button class="action primary" id="runProjectTests">Lancer les tests</button><label class="panel-note"><input type="checkbox" id="autoTestAfter"> Tests auto après modification</label></div></div><div id="testLatest" class="panel-block"></div><div id="testHistory" class="panel-block"></div>`;
    const result = await api('testing?project=' + encodeURIComponent(cur));
    if (!q.isConnected) return;
    el('testCommand').textContent = result.command ? 'Commande détectée : ' + result.command : 'Aucune commande de test détectée pour ce projet.';
    el('autoTestAfter').checked = !!result.autoAfterChanges;
    const history = () => {
      const reports = result.reports || [];
      el('testHistory').innerHTML = '<h4>Historique</h4>' + (reports.length ? reports.slice(0, 8).map(r => `<div class="panel-block"><b>${esc(r.status)}</b> · ${esc(r.command || '—')}<div class="panel-note">${esc(r.finishedAt || '')} · ${Math.round((r.durationMs || 0) / 1000)} s</div></div>`).join('') : '<div class="panel-note">Aucun rapport enregistré.</div>');
    };
    el('autoTestAfter').onchange = async () => {
      const enabled = el('autoTestAfter').checked;
      if (enabled && !confirm('Après chaque modification, les tests déclarés dans ce projet seront exécutés. Un script de test peut modifier des fichiers ou contacter le réseau. Activer cette option ?')) { el('autoTestAfter').checked = false; return; }
      const saved = await api('testing/settings', 'POST', { autoAfterChanges: enabled });
      if (saved.error) { alert(saved.error); el('autoTestAfter').checked = !enabled; }
    };
    el('runProjectTests').disabled = !result.command;
    el('runProjectTests').onclick = async () => {
      if (!confirm('Exécuter la commande de test déclarée par ce projet ? Un script de test peut lui-même modifier des fichiers.')) return;
      const button = el('runProjectTests'); button.disabled = true; button.textContent = 'Tests en cours…';
      const response = await api('testing/run', 'POST', { project: cur, confirm: true });
      button.disabled = false; button.textContent = 'Lancer les tests';
      if (response.error) { el('testLatest').textContent = response.error; return; }
      result.reports = response.reports || [];
      const report = response.report || {};
      el('testLatest').innerHTML = `<h4>Rapport</h4><b style="color:${report.status === 'passed' ? 'var(--ok)' : report.status === 'failed' ? 'var(--danger)' : 'var(--warn)'}">${esc(report.status || 'inconnu')}</b><div class="panel-note">${esc(report.command || 'Aucune commande')} · ${Math.round((report.durationMs || 0) / 1000)} s${report.regressionCandidate ? ' · échec après un test réussi précédent' : ''}</div><pre style="white-space:pre-wrap;max-height:300px;overflow:auto">${esc(report.output || 'Aucune sortie')}</pre>`;
      history();
    };
    history();
  }

  async function renderRecovery(q) {
    q.innerHTML = `<div class="panel-block"><h4>Astra Mission Recovery & Export</h4><div class="panel-note">Les missions en mode Agent sauvegardent des checkpoints et créent un instantané du projet avant de commencer.</div><div class="row" style="margin-top:8px"><button class="action" id="makeSnapshot">Créer un instantané</button><a class="action primary" download style="text-decoration:none" href="/api/recovery/export?project=${encodeURIComponent(cur)}">Exporter ZIP</a></div></div><div id="recoveryMissions" class="panel-block">Chargement…</div><div id="recoverySnapshots" class="panel-block"></div>`;
    const load = async () => {
      const result = await api('recovery?project=' + encodeURIComponent(cur));
      if (!q.isConnected) return;
      if (result.error) { el('recoveryMissions').textContent = result.error; return; }
      el('recoveryMissions').innerHTML = '<h4>Missions récentes</h4>' + (result.missions?.length ? result.missions.map(m => `<div class="panel-block"><b>${esc(m.title)}</b><div class="panel-note">${esc(m.status)} · ${esc(m.updatedAt || m.startedAt)} · ${m.checkpoints || 0} événements sauvegardés</div>${['interrupted', 'running', 'failed'].includes(m.status) ? `<button class="mini" data-resume-mission="${esc(m.id)}">Restaurer la conversation</button>` : ''}</div>`).join('') : '<div class="panel-note">Aucune mission enregistrée.</div>');
      el('recoverySnapshots').innerHTML = '<h4>Instantanés</h4>' + (result.snapshots?.length ? result.snapshots.map(s => `<div class="panel-block"><b>${esc(s.reason || 'Instantané')}</b><div class="panel-note">${esc(s.createdAt)} · ${s.files?.length || 0} fichiers · ${((s.totalBytes || 0) / 1048576).toFixed(1)} Mo${s.truncated ? ' · incomplet, restauration désactivée' : ''}</div><button class="mini" data-restore-snapshot="${esc(s.id)}" ${s.truncated ? 'disabled' : ''}>Restaurer cet état</button></div>`).join('') : '<div class="panel-note">Aucun instantané disponible.</div>');
      q.querySelectorAll('[data-resume-mission]').forEach(button => button.onclick = async () => {
        const restored = await api('recovery', 'POST', { project: cur, op: 'restore-conversation', missionId: button.dataset.resumeMission });
        if (restored.error) { alert(restored.error); return; }
        conv = restored.conversation; localStorage['c' + cur] = conv; await replayConv(conv);
        tab = 'chat'; renderRightTabs(); renderRight();
        el('message').value = 'Reprends la mission interrompue à partir du dernier état sauvegardé. Vérifie les fichiers actuels et les actions déjà effectuées avant de continuer.';
      });
      q.querySelectorAll('[data-restore-snapshot]').forEach(button => button.onclick = async () => {
        if (!confirm('Restaurer tout le projet à cet instantané ? Les fichiers ajoutés depuis seront déplacés en quarantaine. Une sauvegarde de sécurité sera créée avant la restauration.')) return;
        const restored = await api('recovery', 'POST', { project: cur, op: 'restore-snapshot', snapshotId: button.dataset.restoreSnapshot, confirm: true });
        if (restored.error) { alert(restored.error); return; }
        alert('Restauration terminée. Fichiers remis : ' + (restored.restored || 0) + ' · mis en quarantaine : ' + (restored.quarantined || 0) + ' · sauvegarde : ' + (restored.backup || 'créée'));
        await loadFiles(); renderTree(); await load();
      });
    };
    el('makeSnapshot').onclick = async () => {
      const result = await api('recovery', 'POST', { project: cur, op: 'snapshot', reason: 'instantané manuel' });
      if (result.error) { alert(result.error); return; }
      await load(); setStatus('Instantané créé', false);
    };
    await load();
  }

  function afterSend() { if (live && !speaking && !busy) setTimeout(startRecognition, 450); }
  function onFinal(text) { if (live && prefs.autoSpeak !== false) say(text); }
  function init(voiceSettings) {
    prefs = { ...prefs, ...(voiceSettings || {}) };
    const mic = el('mic'); if (mic) mic.onclick = dictate;
    const liveButton = el('voiceLive'); if (liveButton) liveButton.onclick = toggleLive;
    window.speechSynthesis?.addEventListener?.('voiceschanged', refreshVoiceChoices);
  }
  window.AstraVoice = { init, mountSettings, afterSend, onFinal, dictate, toggleLive };
  window.renderHealing = renderHealing;
  window.renderTesting = renderTesting;
  window.renderRecovery = renderRecovery;
})();
