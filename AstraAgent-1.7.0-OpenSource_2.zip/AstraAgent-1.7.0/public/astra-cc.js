/* Astra Command Center (1.5.5) : cockpit unique — missions, agents, modèles, graphe de communication,
   ressources, erreurs, diagnostic. Couche additive chargée après index.html et kairo-ui.js.
   Toutes les données viennent de /api/cc/*, /api/comm-graph et /api/intelligence/* : rien n'est simulé. */
(() => {
'use strict';
const $q = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
const X = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const A = (u, m, b) => api(u, m, b);
const fmtB = n => n == null ? '—' : n > 1e9 ? (n / 1e9).toFixed(1) + ' Go' : (n / 1e6).toFixed(0) + ' Mo';
const dur = ms => window.AstraComm.fmtDuration(ms);
const hh = iso => String(iso || '').slice(11, 19);
const toast = (m, t) => { try { AstraUI.toast(m, t || 'info'); } catch { try { setStatus(m, false); } catch {} } };
const download = (name, text, type) => { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([text], { type: type || 'text/plain' })); a.download = name; document.body.append(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500); };
const pill = (t, k) => `<span class="cc-pill ${k || ''}">${X(t)}</span>`;
const STATUS = { running: ['En cours', 'run'], paused: ['En pause', 'warn'], completed: ['Terminée', 'ok'], failed: ['Échec', 'err'], interrupted: ['Interrompue', 'warn'] };
const PAGES = [['overview', 'Overview'], ['missions', 'Missions'], ['agents', 'Agents'], ['models', 'Models'], ['graph', 'Communication Graph'], ['resources', 'Resources'], ['errors', 'Error Center'], ['notifs', 'Notifications'], ['diag', 'Diagnostics'], ['workspaces', 'Workspaces']];
const st = { page: 'overview', timer: null, graphMission: null, replay: null, sel: null, selMsg: null, pos: {}, view: null, bench: null, lastAct: 0, act: [], actFilter: {}, readNotif: +localStorage.ccRead || 0 };
let root;

function build() {
  root = document.createElement('div'); root.className = 'cc'; root.id = 'cc'; root.setAttribute('role', 'dialog'); root.setAttribute('aria-label', 'Astra Command Center');
  root.innerHTML = `<aside class="cc-side"><div class="cc-brand">COMMAND CENTER</div><nav class="cc-nav" id="ccNav"></nav></aside><section class="cc-main"><div class="cc-top"><h2 id="ccTitle"></h2><span class="grow" style="flex:1"></span><span class="cc-note" id="ccStamp"></span><button class="action" id="ccRefresh">Actualiser</button><button class="action" id="ccClose">Fermer (Échap)</button></div><div class="cc-body" id="ccBody"></div></section>`;
  document.body.append(root);
  $q('#ccClose').onclick = close; $q('#ccRefresh').onclick = () => render(true);
  renderNav();
}
function renderNav() {
  const unread = st.act.filter(e => e.notify && e.id > st.readNotif).length;
  $q('#ccNav').innerHTML = PAGES.map(([k, l]) => `<button data-p="${k}" class="${st.page === k ? 'on' : ''}">${X(l)}${k === 'notifs' && unread ? `<span class="badge">${unread}</span>` : ''}${k === 'errors' && st.errOpen ? `<span class="badge">${st.errOpen}</span>` : ''}</button>`).join('') +
    '<hr><button data-go="term">Terminal ↗</button><button data-go="files">Files ↗</button><button data-go="swarm">Swarm ↗</button><button data-go="settings">Settings ↗</button>';
  $$('#ccNav [data-p]').forEach(b => b.onclick = () => go(b.dataset.p));
  $$('#ccNav [data-go]').forEach(b => b.onclick = () => { const g = b.dataset.go; close(); if (g === 'settings') return $q('#settingsBtn').click(); tab = g === 'files' ? 'files' : g; renderRightTabs(); renderRight(); try { document.getElementById('agentPanel').classList.add('open'); } catch {} });
}
function open(page) { if (!root) build(); root.classList.add('open'); go(page || st.page); }
function close() { if (!root) return; root.classList.remove('open'); clearInterval(st.timer); stopReplay(); }
function go(p) { st.page = p; clearInterval(st.timer); stopReplay(); renderNav(); $q('#ccTitle').textContent = PAGES.find(x => x[0] === p)[1]; render(true); const every = { overview: 2000, resources: 3000, agents: 2000, missions: 3000, graph: 2000, errors: 4000, notifs: 3000 }[p]; if (every) st.timer = setInterval(() => render(false), every); }
async function pollAct() { const r = await A('cc/activity?limit=200&since=' + st.lastAct).catch(() => null); if (r && r.events) { if (r.events.length) { st.act.push(...r.events); st.act = st.act.slice(-400); } st.lastAct = r.last || st.lastAct; } }
async function render(force) {
  const b = $q('#ccBody'); if (!b) return;
  try { await pollAct(); const e = await A('cc/errors?status=open'); st.errOpen = (e.errors || []).filter(x => x.severity !== 'info').length; renderNav();
    await ({ overview, missions, agents, models, graph, resources, errors, notifs, diag, workspaces })[st.page](b, force); $q('#ccStamp').textContent = 'mis à jour ' + new Date().toLocaleTimeString(); }
  catch (e) { b.innerHTML = `<div class="cc-card"><b>Erreur d’affichage</b><div class="cc-note">${X(e.message)}</div></div>`; }
}
const keepUI = (b, fn) => { const y = b.scrollTop; fn(); b.scrollTop = y; };

/* ── Overview ── */
function actHtml(list, n) { return list.slice(-(n || 40)).reverse().map(e => `<div class="${e.level}"><time>${hh(e.at)}</time><b>${X(e.source)}</b> · ${X(e.message)}</div>`).join('') || '<div class="cc-note">Aucun événement pour le moment.</div>'; }
async function overview(b) {
  const [o, r] = await Promise.all([A('cc/overview'), A('cc/resources')]);
  keepUI(b, () => b.innerHTML = `<div class="cc-grid">
   <div class="cc-card"><h4>Agents actifs</h4><div class="cc-big">${o.agents.active}</div><div class="cc-sub">${o.agents.waiting} en attente · ${o.agents.total} au total</div></div>
   <div class="cc-card"><h4>Missions actives</h4><div class="cc-big">${o.missions.active}</div><div class="cc-sub">${o.missions.recent} terminée(s) en 24 h · ${o.missions.total} enregistrée(s)</div></div>
   <div class="cc-card"><h4>Fournisseurs configurés</h4><div class="cc-big">${o.models.count}</div><div class="cc-sub">${o.models.providers.map(p => X(p.label)).join(', ') || 'aucun'}</div></div>
   <div class="cc-card"><h4>Erreurs ouvertes</h4><div class="cc-big" style="color:${o.errors.open ? 'var(--danger)' : 'var(--ok)'}">${o.errors.open}</div><div class="cc-sub">Mode modèles : ${X(o.intelligence.mode)}</div></div></div>
   <div class="cc-section"><h3>Quick Actions</h3><div class="cc-row">
    <button class="action primary" data-q="mission">New Mission</button><button class="action" data-q="term">Open Terminal</button><button class="action" data-q="agent">Create Agent</button><button class="action" data-q="logs">View Logs</button><button class="action" data-q="models">Open Model Manager</button><button class="action" data-q="diag">Run Diagnostics</button></div></div>
   <div class="cc-grid cc-section"><div class="cc-card"><h4>CPU</h4><div class="cc-big">${r.cpu.percent ?? '—'} %</div><div class="cc-bar ${r.cpu.percent > 85 ? 'err' : ''}"><i style="width:${r.cpu.percent || 0}%"></i></div></div>
   <div class="cc-card"><h4>RAM</h4><div class="cc-big">${r.ram.percent} %</div><div class="cc-bar ${r.ram.percent > 90 ? 'err' : ''}"><i style="width:${r.ram.percent}%"></i></div><div class="cc-sub">${fmtB(r.ram.usedBytes)} / ${fmtB(r.ram.totalBytes)}</div></div>
   <div class="cc-card"><h4>Astra</h4><div class="cc-big">${fmtB(r.astra.rssBytes)}</div><div class="cc-sub">actif depuis ${dur(r.astra.uptimeSec * 1000)}</div></div></div>
   <div class="cc-section"><div class="cc-row"><h3 class="grow">Live Activity</h3>${['', 'swarm', 'model', 'error', 'system'].map(s => `<button class="mini ${st.actFilter.s === s || (!s && !st.actFilter.s) ? 'on' : ''}" data-f="${s}">${s || 'tout'}</button>`).join('')}</div><div class="cc-card cc-act">${actHtml(st.act.filter(e => !st.actFilter.s || e.source === st.actFilter.s))}</div></div>`);
  $$('[data-f]', b).forEach(x => x.onclick = () => { st.actFilter.s = x.dataset.f; render(); });
  $$('[data-q]', b).forEach(x => x.onclick = () => ({
    mission: () => { close(); tab = 'swarm'; renderRightTabs(); renderRight(); $q('#agentPanel').classList.add('open'); }, term: () => { close(); tab = 'term'; renderRightTabs(); renderRight(); },
    agent: () => { close(); tab = 'swarm'; renderRightTabs(); renderRight(); }, logs: () => { st.actFilter = {}; $q('.cc-act', b).scrollIntoView(); }, models: () => go('models'), diag: () => go('diag')
  })[x.dataset.q]());
}

/* ── Missions ── */
async function missions(b) {
  const { missions: ms } = await A('cc/missions');
  keepUI(b, () => b.innerHTML = `<div class="cc-scroll"><table class="cc-tbl"><tr><th>Nom</th><th>ID</th><th>Status</th><th>Agents</th><th>Progress</th><th>Duration</th><th>Model</th><th>Actions</th></tr>${ms.map(m => { const s = STATUS[m.status] || [m.status, '']; return `<tr><td><b>${X(m.title.slice(0, 60))}</b><div class="cc-note">${X(m.projectName)}</div></td><td><code>${X(m.id)}</code></td><td>${pill(s[0], s[1])}</td><td>${m.agents.map(a => X(a.name)).join(', ')}</td><td><div class="cc-bar"><i style="width:${m.progress}%"></i></div><div class="cc-note">${m.progress} %</div></td><td>${dur(m.durationMs)}</td><td class="cc-note">${X(m.model)}</td><td><div class="cc-row">
   <button class="mini" data-a="open" data-id="${m.id}" data-p="${m.project}">Ouvrir</button><button class="mini" data-a="graph" data-id="${m.id}" data-p="${m.project}">Graphe</button>
   ${m.live ? (m.status === 'paused' ? `<button class="mini" data-a="resume" data-id="${m.id}">Reprendre</button>` : `<button class="mini" data-a="pause" data-id="${m.id}">Pause</button>`) + `<button class="mini danger" data-a="cancel" data-id="${m.id}">Annuler</button>` : ''}
   <button class="mini" data-a="logs" data-id="${m.id}" data-p="${m.project}">Logs</button><button class="mini" data-a="report" data-id="${m.id}">Rapport</button></div></td></tr>`; }).join('') || '<tr><td colspan="8" class="cc-note">Aucune mission. Lance-en une depuis Swarm.</td></tr>'}</table></div><div id="ccLogs" class="cc-section"></div>`);
  $$('[data-a]', b).forEach(x => x.onclick = async () => {
    const id = x.dataset.id, a = x.dataset.a;
    if (a === 'open' || a === 'graph') { if (x.dataset.p !== cur) { cur = x.dataset.p; localStorage.cur = cur; conv = null; renderProviders(); await refreshProject(); clearThread(); } if (a === 'graph') { st.graphMission = id; return go('graph'); } const l = await A('swarm-missions?project=' + cur); swarmMission = (l || []).find(m => m.id === id) || null; close(); tab = 'swarm'; renderRightTabs(); renderRight(); $q('#agentPanel').classList.add('open'); return; }
    if (a === 'logs') { const r = await A('swarm-replay?project=' + x.dataset.p + '&id=' + id); $q('#ccLogs').innerHTML = `<div class="cc-card"><h4>Logs · ${X(r.title || id)}</h4><div class="cc-act">${(r.timeline || []).map(t => `<div><time>${hh(t.at)}</time><b>${X(t.actor)}</b> · ${X(t.message)}</div>`).join('') || 'Aucun événement.'}</div></div>`; return; }
    if (a === 'report') { const r = await A('cc/mission-report?id=' + id); if (r.error) return toast(r.error, 'err'); download(r.filename, r.text, 'text/markdown'); return; }
    if (a === 'cancel') { let r = await A('cc/mission-control', 'POST', { id, action: 'cancel' }); if (r.needConfirm) { if (!confirm(r.reason + '\n\nConfirmer l’annulation ?')) return; r = await A('cc/mission-control', 'POST', { id, action: 'cancel', confirm: true }); } return r.error ? toast(r.error, 'err') : (toast('Mission : arrêt demandé', 'warn'), render()); }
    const r = await A('cc/mission-control', 'POST', { id, action: a }); r.error ? toast(r.error, 'err') : render();
  });
}

/* ── Agents ── */
async function agents(b) {
  const { missions: ms } = await A('cc/missions'), live = ms.filter(m => m.live), shown = live.length ? live : ms.slice(0, 1);
  keepUI(b, () => b.innerHTML = (shown.length ? shown.map(m => `<div class="cc-section"><h3>${X(m.title.slice(0, 70))} ${pill((STATUS[m.status] || [m.status])[0], (STATUS[m.status] || [])[1])}</h3><div class="cc-grid">${m.agents.map(a => `<div class="cc-card"><div class="cc-row"><b class="grow">${X(a.name)}</b>${pill(a.status, a.status === 'working' ? 'run' : a.status === 'completed' ? 'ok' : a.status === 'failed' ? 'err' : 'warn')}</div><div class="cc-note">${X(a.provider)} · ${X(a.model)}</div>${m.live ? `<div class="cc-row" style="margin-top:8px">${a.status === 'working' ? `<button class="mini" data-c="pause" data-m="${m.id}" data-w="${a.id}">Pause</button>` : ''}${a.status === 'paused' ? `<button class="mini" data-c="resume" data-m="${m.id}" data-w="${a.id}">Reprendre</button>` : ''}${['working', 'pausing', 'paused'].includes(a.status) ? `<button class="mini danger" data-c="stop" data-m="${m.id}" data-w="${a.id}">Stop</button>` : ''}</div>` : ''}</div>`).join('')}</div></div>`).join('') : '<div class="cc-card cc-note">Aucune mission pour le moment.</div>') +
   `<div class="cc-section"><h3>Agents configurés (Swarm)</h3><div class="cc-grid">${(typeof swarmAgents !== 'undefined' ? swarmAgents : []).map(a => `<div class="cc-card"><b>${X(a.name)}</b><div class="cc-note">${X(a.role)}</div><div class="cc-note">${X(a.provider)} · ${X(a.model || '—')}</div></div>`).join('')}</div></div>`);
  $$('[data-c]', b).forEach(x => x.onclick = async () => { const r = await A('swarm-control', 'POST', { id: x.dataset.m, workerId: x.dataset.w, action: x.dataset.c }); r.error ? toast(r.error, 'err') : render(); });
}

/* ── Communication Graph ── */
const C = () => window.AstraComm;
async function loadGraph(id) {
  if (!id) return null;
  const list = (await A('cc/missions')).missions, m = list.find(x => x.id === id); if (!m) return null;
  if (m.live && typeof swarmMission !== 'undefined' && swarmMission && swarmMission.id === id) return { mission: m, graph: C().buildGraph(swarmMission) };
  const r = await A('comm-graph?project=' + m.project + '&id=' + id); return r.graph ? { mission: m, graph: r.graph } : null;
}
function stopReplay() { if (st.replay && st.replay.t) clearInterval(st.replay.t); if (st.replay) st.replay.t = null; }
async function graph(b, force) {
  const { missions: ms } = await A('cc/missions');
  if (!st.graphMission || !ms.find(m => m.id === st.graphMission)) st.graphMission = (ms.find(m => m.live) || ms[0] || {}).id;
  if (st.replay && st.replay.playing && !force) return; // la relecture ne doit pas être écrasée par le rafraîchissement
  const data = await loadGraph(st.graphMission);
  if (!ms.length || !data) { b.innerHTML = '<div class="cc-card"><b>Aucune mission à afficher.</b><div class="cc-note">Lance une mission Astra Swarm : le graphe se construit à partir de ses échanges réels.</div></div>'; return; }
  const g = data.graph; st.g = g;
  if (!st.replay || st.replay.mid !== st.graphMission) st.replay = { mid: st.graphMission, i: null, playing: false, t: null };
  const live = data.mission.live, ri = st.replay.i, state = ri == null ? null : C().stateAt(g, ri);
  const shown = state ? g.messages.slice(0, state.shown) : g.messages;
  keepUI(b, () => b.innerHTML = `<div class="cc-row"><select class="select" id="gSel">${ms.map(m => `<option value="${m.id}" ${m.id === st.graphMission ? 'selected' : ''}>${X(m.title.slice(0, 50))} · ${X((STATUS[m.status] || [m.status])[0])}</option>`).join('')}</select>
   ${live ? pill('LIVE', 'run') : pill('archive')} <span class="grow cc-note">${X(g.diagnosis)}</span><button class="mini" id="gJson">Export JSON</button><button class="mini" id="gSvg">Export SVG</button></div>
   <div class="cc-graph cc-section"><div><svg class="cc-svg" id="gSvg0" viewBox="0 0 720 420"></svg>
    <div class="cc-card" style="margin-top:10px"><h4>Replay</h4><div class="cc-note">Relecture des échanges déjà enregistrés. Rien n’est ré-exécuté.</div><div class="cc-row" style="margin-top:6px"><button class="mini" id="rPrev">←</button><button class="mini" id="rPlay">${st.replay.playing ? '⏸ Pause' : '▶ Lecture'}</button><button class="mini" id="rNext">→</button><input type="range" id="rSeek" min="0" max="${Math.max(0, g.messages.length - 1)}" value="${ri == null ? Math.max(0, g.messages.length - 1) : ri}" style="flex:1"><button class="mini" id="rLive">Fin</button><span class="cc-note">${state ? state.shown : g.messages.length} / ${g.messages.length}</span></div></div>
    <div class="cc-section"><h3>Event Timeline</h3><div class="cc-card cc-act">${g.timeline.slice(-60).reverse().map(t => `<div><time>${new Date(t.at).toISOString().slice(11, 19)}</time><b>${X(t.actor)}</b> · ${X(t.text)}</div>`).join('') || '—'}</div></div></div>
   <div><div class="cc-card" id="gPanel"></div>
    ${g.alerts.length ? `<div class="cc-card" style="margin-top:10px"><h4>Alertes & goulots</h4>${g.alerts.slice(0, 8).map(a => `<div class="cc-note ${a.level === 'error' ? '' : 'cc-warn'}">• ${X(a.text)}</div>`).join('')}</div>` : ''}
    <div class="cc-card" style="margin-top:10px"><h4>Message Inspector (${shown.length})</h4><div class="cc-row" style="margin-bottom:6px"><select class="select" id="gType"><option value="">tous types</option>${['TASK_ASSIGNMENT', 'TASK_RESULT', 'STATUS_UPDATE', 'ERROR', 'RESPONSE'].map(t => `<option ${st.fType === t ? 'selected' : ''}>${t}</option>`).join('')}</select></div>
    <div class="cc-list">${shown.filter(m => (!st.fType || m.type === st.fType) && (!st.sel || m.from === st.sel || m.to === st.sel)).slice().reverse().map(m => `<div class="cc-msg ${m.status} ${st.selMsg === m.id ? 'sel' : ''}" data-m="${m.id}"><b>${m.id.replace('msg_', '#')}</b> ${pill(m.status, m.status === 'delivered' ? 'ok' : m.status === 'failed' ? 'err' : 'warn')} <span class="cc-note">${new Date(m.timestamp).toISOString().slice(11, 19)}</span><div>${X(nm(g, m.from))} → ${X(nm(g, m.to))} · <code>${m.type}</code></div>${st.selMsg === m.id ? `<div class="cc-note" style="white-space:pre-wrap;margin-top:4px">« ${X(m.content)} »</div>` : ''}</div>`).join('') || '<div class="cc-note">Aucun message.</div>'}</div></div></div></div>`);
  drawGraph(g, state); drawPanel(g);
  $q('#gSel').onchange = e => { st.graphMission = e.target.value; st.sel = null; st.selMsg = null; st.pos = {}; render(true); };
  $q('#gType').onchange = e => { st.fType = e.target.value; render(true); };
  $$('[data-m]', b).forEach(x => x.onclick = () => { st.selMsg = st.selMsg === x.dataset.m ? null : x.dataset.m; render(true); });
  $q('#gJson').onclick = () => download('astra-graph-' + g.missionId + '.json', JSON.stringify(C().toExport(g), null, 2), 'application/json');
  $q('#gSvg').onclick = () => download('astra-graph-' + g.missionId + '.svg', C().toSVG(g, curPos(g)), 'image/svg+xml');
  const seek = i => { st.replay.i = Math.max(0, Math.min(g.messages.length - 1, i)); render(true); };
  $q('#rPrev').onclick = () => { stopReplay(); st.replay.playing = false; seek((st.replay.i ?? g.messages.length - 1) - 1); };
  $q('#rNext').onclick = () => { stopReplay(); st.replay.playing = false; seek((st.replay.i ?? -1) + 1); };
  $q('#rSeek').oninput = e => { stopReplay(); st.replay.playing = false; seek(+e.target.value); };
  $q('#rLive').onclick = () => { stopReplay(); st.replay.playing = false; st.replay.i = null; render(true); };
  $q('#rPlay').onclick = () => { if (st.replay.playing) { stopReplay(); st.replay.playing = false; return render(true); } st.replay.playing = true; if (st.replay.i == null || st.replay.i >= g.messages.length - 1) st.replay.i = -1; st.replay.t = setInterval(() => { if (st.replay.i >= g.messages.length - 1) { stopReplay(); st.replay.playing = false; return render(true); } st.replay.i++; render(true); }, 800); render(true); };
}
const nm = (g, id) => (g.nodes.find(n => n.id === id) || {}).label || id;
const curPos = g => ({ ...C().layout(g, 720, 420), ...st.pos });
function drawGraph(g, state) {
  const svg = $q('#gSvg0'); if (!svg) return; const P = curPos(g), col = C().COLORS;
  const hot = state && state.message ? state.message.from + '>' + state.message.to : null, counts = state ? state.edgeCounts : null;
  const draw = () => {
    svg.innerHTML = '<defs><marker id="ar" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M0 0L10 5L0 10z" fill="#57a3ff"/></marker></defs>' +
      g.edges.filter(e => !counts || counts[e.id]).map(e => { const a = P[e.from], b2 = P[e.to]; if (!a || !b2) return ''; const bend = e.from < e.to ? 12 : -12, mx = (a.x + b2.x) / 2, my = (a.y + b2.y) / 2 + bend; return `<path d="M${a.x} ${a.y} Q${mx} ${my} ${b2.x} ${b2.y}" fill="none" stroke="${e.failed ? '#f06c7a' : '#57a3ff'}" stroke-width="${hot === e.id ? 3.5 : 1.6}" marker-end="url(#ar)" opacity="${hot && hot !== e.id ? .45 : .9}"/><text class="mut" x="${mx}" y="${my - 5}" text-anchor="middle" font-size="10">${counts ? counts[e.id] : e.count}</text>`; }).join('') +
      g.nodes.map(n => { const p = P[n.id]; return `<g class="node ${st.sel === n.id ? 'sel' : ''}" data-n="${n.id}"><rect x="${p.x - 62}" y="${p.y - 24}" width="124" height="48" rx="9" stroke="${col[n.status] || '#8492aa'}"/><text x="${p.x}" y="${p.y - 4}" text-anchor="middle" font-weight="700">${X(n.label.slice(0, 16))}</text><text class="mut" x="${p.x}" y="${p.y + 13}" text-anchor="middle" font-size="10">${X(n.status)}</text></g>`; }).join('');
    $$('.node', svg).forEach(el => bindNode(el, svg, g, draw));
  };
  draw();
  svg.onwheel = ev => { ev.preventDefault(); const v = (st.view || [0, 0, 720, 420]).slice(), k = ev.deltaY > 0 ? 1.1 : 0.9, w = Math.max(240, Math.min(2160, v[2] * k)), h = w * 420 / 720; v[0] += (v[2] - w) / 2; v[1] += (v[3] - h) / 2; v[2] = w; v[3] = h; st.view = v; svg.setAttribute('viewBox', v.join(' ')); };
  if (st.view) svg.setAttribute('viewBox', st.view.join(' '));
}
function bindNode(el, svg, g, redraw) {
  el.onpointerdown = ev => {
    ev.preventDefault(); const id = el.dataset.n; let moved = false; el.setPointerCapture(ev.pointerId);
    const pt = e => { const r = svg.getBoundingClientRect(), v = (svg.viewBox.baseVal); return { x: v.x + (e.clientX - r.left) * v.width / r.width, y: v.y + (e.clientY - r.top) * v.height / r.height }; };
    el.onpointermove = e => { moved = true; st.pos[id] = pt(e); redraw(); };
    el.onpointerup = () => { el.onpointermove = null; el.onpointerup = null; if (!moved) { st.sel = st.sel === id ? null : id; render(true); } };
  };
}
function drawPanel(g) {
  const p = $q('#gPanel'); if (!p) return; const n = g.nodes.find(x => x.id === st.sel);
  if (!n) { p.innerHTML = `<h4>Agents</h4><div class="cc-note">Clique un agent pour voir ses informations. Glisse pour le déplacer, molette pour zoomer.</div>${g.nodes.map(x => `<div class="cc-row" style="margin-top:4px"><span class="cc-pill" style="color:${C().COLORS[x.status]}">${X(x.status)}</span><b>${X(x.label)}</b></div>`).join('')}`; return; }
  p.innerHTML = `<h4>Agent</h4><table class="cc-tbl">${[['Nom', n.label], ['ID', n.id], ['Rôle', n.role], ['Modèle', (n.provider ? n.provider + ' / ' : '') + n.model], ['Statut', n.rawStatus || n.status], ['Mission', n.task], ['Temps actif', n.activeMs ? dur(n.activeMs) : '—'], ['Messages reçus', n.received], ['Messages envoyés', n.sent], ['Dernière action', n.lastAction]].filter(r => r[1] !== undefined && r[1] !== '').map(r => `<tr><th>${r[0]}</th><td>${X(r[1])}</td></tr>`).join('')}</table>`;
}

/* ── Models (Model Intelligence) ── */
const SRC = { tested: ['testé', 'ok'], declared: ['déclaré', 'ok'], heuristic: ['heuristique', 'warn'], user: ['saisi', ''], unknown: ['inconnu', ''], local: ['local', 'ok'] };
const sp = s => { const x = SRC[s] || ['?', '']; return pill(x[0], x[1]); };
async function models(b, force) {
  if (!force && st.modelsBusy) return; if (!force && $q('#mTask') && document.activeElement && b.contains(document.activeElement)) return;
  const s = await A('intelligence' + (force === true && st.refreshModels ? '?refresh=1' : '')); st.refreshModels = false;
  const c = s.config, es = s.registry.entries;
  keepUI(b, () => b.innerHTML = `<div class="cc-card"><h4>Mode de sélection</h4><div class="cc-row">${[['auto', 'Auto — Astra choisit seul pour chaque message du chat'], ['hybrid', 'Hybrid (recommandé) — Astra propose et explique, tu décides'], ['manual', 'Manual — tu choisis le fournisseur et le modèle']].map(([k, l]) => `<label class="cc-row"><input type="radio" name="mi-mode" value="${k}" ${c.mode === k ? 'checked' : ''}>${X(l)}</label>`).join('')}</div>
    <div class="cc-row" style="margin-top:8px"><label class="cc-row"><input type="checkbox" id="miFb" ${c.fallback ? 'checked' : ''}>Fallback automatique du coordinateur Swarm (appels de texte seulement, jamais les actions d’outils)</label><label class="cc-row"><input type="checkbox" id="miLocal" ${c.localOnly ? 'checked' : ''}>Modèles locaux uniquement</label><label class="cc-row">Budget max / 1M jetons <input class="input" id="miBudget" style="width:80px" value="${c.maxCostPer1M || ''}" placeholder="aucun"></label></div>
    <div class="cc-note" style="margin-top:6px">Le Task Analyzer est heuristique (mots-clés) : il ne consulte aucun modèle. Les capacités ne comptent comme « testées » qu’après un benchmark ; sinon la note est neutre et signalée.</div></div>
   <div class="cc-card cc-section"><h4>Pondération du score (somme normalisée)</h4><div class="cc-row">${Object.entries(c.weights).map(([k, v]) => `<label class="cc-row">${X({ capability: 'Capacité', quality: 'Qualité', cost: 'Coût', latency: 'Latence', context: 'Contexte', reliability: 'Fiabilité' }[k])} <input class="input" data-w="${k}" style="width:56px" value="${v}"></label>`).join('')}<button class="action" id="miSave">Enregistrer</button></div></div>
   <div class="cc-card cc-section"><h4>Essayer le routage sur une demande</h4><textarea class="input" id="mTask" rows="2" placeholder="Ex. : Analyse ce projet Python, trouve les bugs et corrige-les"></textarea><div class="cc-row" style="margin-top:6px"><button class="action primary" id="mRoute">Analyser et recommander</button><span class="cc-note">Aucun appel au modèle : analyse locale + classement.</span></div><div id="mRes"></div></div>
   <div class="cc-section"><div class="cc-row"><h3 class="grow">Model Registry (${es.length})</h3><button class="mini" id="miReload">Recharger la liste</button></div>${s.registry.problems.map(p => `<div class="cc-note ${p.level === 'warn' ? 'cc-warn' : ''}">• ${X(p.label)} : ${X(p.error)}</div>`).join('')}
   <div class="cc-scroll"><table class="cc-tbl"><tr><th></th><th>Modèle</th><th>Type</th><th>Vision</th><th>Contexte</th><th>Coût /1M (entrée/sortie)</th><th>Capacités testées</th><th>Latence · échecs</th></tr>${es.map(e => `<tr><td><input type="checkbox" data-bm="${X(e.id)}"></td><td><b>${X(e.model)}</b><div class="cc-note">${X(e.providerLabel)}</div></td><td>${X(e.type)}</td><td>${e.vision.value === null ? '—' : e.vision.value ? 'oui' : 'non'} ${sp(e.vision.source)}</td>
    <td><input class="input" data-ov="${X(e.id)}" data-k="context" style="width:78px" value="${e.context.source === 'user' && e.type !== 'local' ? e.context.value : ''}" placeholder="${e.context.value || 'inconnu'}" ${e.type === 'local' ? 'disabled' : ''}></td>
    <td>${e.type === 'local' ? 'gratuit ' + sp('local') : `<input class="input" data-ov="${X(e.id)}" data-k="costIn" style="width:56px" value="${e.cost.source === 'user' ? e.cost.in : ''}" placeholder="?"> / <input class="input" data-ov="${X(e.id)}" data-k="costOut" style="width:56px" value="${e.cost.source === 'user' ? e.cost.out : ''}" placeholder="?">`}</td>
    <td>${['coding', 'debugging', 'reasoning', 'document', 'structured'].map(k => e.capabilities[k].score == null ? '' : `<div class="cc-note">${k} <b>${e.capabilities[k].score}</b></div>`).join('') || `<span class="cc-note">non testé</span>`}</td><td class="cc-note">${e.perf && e.perf.requests ? `${e.perf.avgMs ?? '—'} ms · ${e.perf.failures}/${e.perf.requests}` : '—'}</td></tr>`).join('') || '<tr><td colspan="8" class="cc-note">Aucun modèle disponible : configure un fournisseur (Paramètres → Providers) ou lance Ollama.</td></tr>'}</table></div>
   <div class="cc-row" style="margin-top:8px"><button class="action" id="miOv">Enregistrer contexte et prix</button><button class="action primary" id="miBench">Lancer le benchmark sur la sélection</button><span class="cc-note">5 requêtes réelles par modèle (peut coûter). Contrôles simples, le code produit n’est jamais exécuté. Prix saisis par toi : jamais supposés.</span></div><div id="miProg" class="cc-note"></div></div>
   <div class="cc-grid cc-section"><div class="cc-card"><h4>Performance observée</h4>${s.perModel.map(m => `<div class="cc-note"><b>${X(m.id)}</b> · ${m.requests} req · ${m.avgMs ?? '—'} ms moy. · ${(m.failureRate * 100 || 0).toFixed(0)} % échecs</div>`).join('') || '<div class="cc-note">Aucune requête mesurée.</div>'}</div>
   <div class="cc-card"><h4>Historique des sélections</h4>${s.selections.slice(0, 8).map(x => `<div class="cc-note">${hh(x.at)} · ${X(x.chosen || x.recommended)} · ${X(x.by)} · ${X(x.task)}</div>`).join('') || '<div class="cc-note">—</div>'}</div>
   <div class="cc-card"><h4>Reprises (fallback)</h4>${s.incidents.slice(0, 6).map(x => `<div class="cc-note">${hh(x.at)} · ${X(x.summary)}</div>`).join('') || '<div class="cc-note">Aucune.</div>'}</div></div>
   <div class="cc-card cc-section"><h4>Derniers benchmarks</h4>${Object.entries(s.benchmarks).map(([id, r]) => `<div class="cc-note"><b>${X(id)}</b> · ${hh(r.at)} · global ${r.overall ?? '—'}/100 · ${r.failed} échec(s) · ${(r.results || []).map(x => X(x.taskId) + ' ' + (x.ok ? x.score : 'ERR')).join(' · ')}</div>`).join('') || '<div class="cc-note">Aucun benchmark lancé.</div>'}</div>`);
  const save = async body => { const r = await A('intelligence/settings', 'POST', body); r.error ? toast(r.error, 'err') : toast('Réglages enregistrés', 'ok'); };
  $$('[name=mi-mode]', b).forEach(x => x.onchange = () => save({ mode: x.value }));
  $q('#miFb').onchange = e => save({ fallback: e.target.checked }); $q('#miLocal').onchange = e => save({ localOnly: e.target.checked }); $q('#miBudget').onchange = e => save({ maxCostPer1M: e.target.value });
  $q('#miSave').onclick = () => save({ weights: Object.fromEntries($$('[data-w]', b).map(i => [i.dataset.w, i.value])), maxCostPer1M: $q('#miBudget').value });
  $q('#miReload').onclick = () => { st.refreshModels = true; render(true); };
  $q('#miOv').onclick = () => { const ov = {}; $$('[data-ov]', b).forEach(i => { (ov[i.dataset.ov] = ov[i.dataset.ov] || {})[i.dataset.k] = i.value; }); save({ overrides: ov }).then(() => render(true)); };
  $q('#mRoute').onclick = async () => {
    const msg = $q('#mTask').value.trim(); if (!msg) return; const r = await A('intelligence/route', 'POST', { message: msg }), t = r.task;
    $q('#mRes').innerHTML = `<div class="cc-section"><div class="cc-row">${pill('tâche : ' + t.task, 'run')}${pill('complexité : ' + t.complexity)}${pill('priorité : ' + t.priority)}${t.requiresVision ? pill('vision requise', 'warn') : ''}${pill('contexte ≈ ' + t.contextRequired + ' jetons')}</div><p>${X(r.explanation)}</p>
    ${r.ranking.slice(0, 5).map(x => `<div class="cc-card" style="margin-bottom:6px"><div class="cc-row"><b class="grow">${X(x.id)}</b>${pill(x.score + '/100', 'ok')}${pill('confiance ' + x.confidence + ' %', x.confidence < 50 ? 'warn' : '')}<button class="mini" data-use="${X(x.provider)}|${X(x.model)}">Utiliser dans le chat</button></div><div class="cc-note">${x.parts.map(p => `${X(p.label)} ${p.points}${p.known ? '' : '*'}`).join(' · ')}</div>${x.warnings.map(w => `<div class="cc-note cc-warn">* ${X(w)}</div>`).join('')}</div>`).join('')}
    ${r.eliminated.length ? `<div class="cc-note">Éliminés : ${r.eliminated.map(x => X(x.id) + ' (' + X(x.reasons.join(', ')) + ')').join(' ; ')}</div>` : ''}</div>`;
    $$('[data-use]', b).forEach(x => x.onclick = async () => { const [pv, md] = x.dataset.use.split('|'); localStorage.pv = pv; localStorage.md = md; $q('#provider').value = pv; await loadModels(); $q('#model').value = md; toast('Modèle appliqué : ' + pv + '/' + md, 'ok'); });
  };
  $q('#miBench').onclick = async () => {
    const ids = $$('[data-bm]:checked', b).map(i => i.dataset.bm); if (!ids.length) return toast('Coche au moins un modèle', 'warn');
    let r = await fetch('/api/intelligence/benchmark', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ models: ids }) }); const first = await r.json().catch(() => ({}));
    if (!r.ok && first.needConfirm) { if (!confirm(first.reason + '\n\nLancer ?')) return; r = await fetch('/api/intelligence/benchmark', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ models: ids, confirm: true }) }); } else if (!r.ok) return toast(first.error || 'Erreur', 'err');
    st.modelsBusy = true; const prog = $q('#miProg'), rd = r.body.getReader(), dec = new TextDecoder(); let buf = '';
    try { for (;;) { const { done, value } = await rd.read(); if (done) break; buf += dec.decode(value); let i; while ((i = buf.indexOf('\n\n')) >= 0) { const l = buf.slice(0, i); buf = buf.slice(i + 2); if (!l.startsWith('data: ')) continue; const e = JSON.parse(l.slice(6)); if (prog) prog.textContent = e.type === 'progress' ? `${e.model} · ${e.title} : ${e.ok ? e.score + '/100' : 'échec'}` : e.type === 'done' ? 'Terminé.' : (e.text || ''); } } } finally { st.modelsBusy = false; }
    render(true);
  };
}

/* ── Resources ── */
async function resources(b) {
  const r = await A('cc/resources'), bar = (p, w) => `<div class="cc-bar ${p > (w || 85) ? 'err' : ''}"><i style="width:${p || 0}%"></i></div>`;
  keepUI(b, () => b.innerHTML = `<div class="cc-note">${X(r.scope)}</div><div class="cc-grid cc-section">
   <div class="cc-card"><h4>CPU</h4><div class="cc-big">${r.cpu.percent ?? '—'} %</div>${bar(r.cpu.percent)}<div class="cc-sub">${r.cpu.cores} cœurs · ${X(r.cpu.model)}</div></div>
   <div class="cc-card"><h4>RAM</h4><div class="cc-big">${r.ram.percent} %</div>${bar(r.ram.percent, 90)}<div class="cc-sub">${fmtB(r.ram.usedBytes)} / ${fmtB(r.ram.totalBytes)}</div></div>
   <div class="cc-card"><h4>GPU</h4>${r.gpu.available ? `<div class="cc-big">${r.gpu.utilization} %</div>${bar(r.gpu.utilization)}<div class="cc-sub">${X(r.gpu.name)} · ${r.gpu.memUsedMb}/${r.gpu.memTotalMb} Mo</div>` : `<div class="cc-note">Non disponible — ${X(r.gpu.reason)}</div>`}</div>
   <div class="cc-card"><h4>Stockage</h4>${r.disk ? `<div class="cc-big">${fmtB(r.disk.freeBytes)}</div><div class="cc-sub">libres sur ${fmtB(r.disk.totalBytes)}</div>` : '<div class="cc-note">Non disponible</div>'}</div>
   <div class="cc-card"><h4>Réseau (requêtes modèles, 1 h)</h4><div class="cc-big">${r.network.modelRequestsLastHour}</div><div class="cc-sub">${r.network.failuresLastHour} échec(s) · ${(r.network.sentCharsLastHour / 1000).toFixed(0)}k car. envoyés</div><div class="cc-note">${X(r.network.note)}</div></div>
   <div class="cc-card"><h4>Processus Astra</h4><div class="cc-big">${fmtB(r.astra.rssBytes)}</div><div class="cc-sub">PID ${r.astra.pid} · Node ${X(r.astra.node)} · ${dur(r.astra.uptimeSec * 1000)}</div></div></div>
   <div class="cc-card cc-section"><h4>Modèles locaux (Ollama)</h4>${r.localModels.reachable ? (r.localModels.running.map(m => `<div>${X(m.name)} · ${fmtB(m.sizeBytes)} (VRAM ${fmtB(m.vramBytes)})</div>`).join('') || '<div class="cc-note">Ollama joignable, aucun modèle chargé.</div>') : '<div class="cc-note">Ollama non joignable.</div>'}</div>`);
}

/* ── Errors / Notifications / Diagnostics / Workspaces ── */
async function errors(b) {
  const { errors: es } = await A('cc/errors');
  keepUI(b, () => b.innerHTML = `<div class="cc-note">Erreurs réellement survenues (modèles, Swarm, serveur). Les répétitions identiques sont regroupées.</div>` + (es.map(e => `<div class="cc-card cc-section"><div class="cc-row"><b class="grow">${X(e.origin)}</b>${pill(e.severity, e.severity === 'error' ? 'err' : 'warn')}${pill(e.status, e.status === 'open' ? 'warn' : 'ok')}${e.count > 1 ? pill('×' + e.count) : ''}</div><div style="margin:4px 0">${X(e.message)}</div><div class="cc-note">${X(e.id)} · ${new Date(e.at).toLocaleString()}${e.context ? ' · ' + X(e.context) : ''}</div><div class="cc-note"><b>Solution :</b> ${X(e.solution)}</div><div class="cc-row" style="margin-top:6px">${e.status === 'open' ? `<button class="mini" data-e="resolved" data-id="${e.id}">Marquer résolue</button><button class="mini" data-e="ignored" data-id="${e.id}">Ignorer</button>` : `<button class="mini" data-e="open" data-id="${e.id}">Rouvrir</button>`}</div></div>`).join('') || '<div class="cc-card cc-section">Aucune erreur enregistrée.</div>'));
  $$('[data-e]', b).forEach(x => x.onclick = async () => { await A('cc/errors', 'POST', { id: x.dataset.id, status: x.dataset.e }); render(); });
}
async function notifs(b) {
  const list = st.act.filter(e => e.notify).slice().reverse();
  keepUI(b, () => b.innerHTML = `<div class="cc-row"><span class="cc-note grow">Alertes de la session : fins de mission, erreurs, agents en pause, reprises de modèle. Elles restent dans Astra (pas de notification système).</span><button class="mini" id="nRead">Tout marquer comme lu</button></div><div class="cc-card cc-section cc-act">${list.map(e => `<div class="${e.level}">${e.id > st.readNotif ? '● ' : ''}<time>${hh(e.at)}</time><b>${X(e.source)}</b> · ${X(e.message)}</div>`).join('') || 'Aucune alerte.'}</div>`);
  $q('#nRead').onclick = () => { st.readNotif = st.lastAct; localStorage.ccRead = st.readNotif; renderNav(); render(); };
}
async function diag(b, force) {
  if (!force && st.diagDone) return; st.diagDone = true; b.innerHTML = '<div class="cc-note">Diagnostic en cours…</div>';
  const d = await A('cc/diagnostics');
  b.innerHTML = `<div class="cc-row"><h3 class="grow">Résultat : ${pill(d.status, d.status === 'ok' ? 'ok' : d.status === 'warn' ? 'warn' : 'fail')}</h3><button class="action primary" id="dRun">Relancer</button></div><table class="cc-tbl cc-section">${d.checks.map(c => `<tr><td>${pill(c.status, c.status === 'ok' ? 'ok' : c.status === 'warn' ? 'warn' : c.status === 'fail' ? 'fail' : '')}</td><td><b>${X(c.label)}</b><div class="cc-note">${X(c.detail)}</div>${c.fix ? `<div class="cc-note cc-warn">→ ${X(c.fix)}</div>` : ''}</td></tr>`).join('')}</table>`;
  $q('#dRun').onclick = () => { st.diagDone = false; diag(b, true); };
}
async function workspaces(b) {
  const { workspaces: ws } = await A('cc/workspaces');
  b.innerHTML = `<div class="cc-grid">${ws.map(w => `<div class="cc-card"><div class="cc-row"><b class="grow">${X(w.name)}</b>${w.exists ? '' : pill('dossier introuvable', 'warn')}${w.id === cur ? pill('ouvert', 'run') : ''}</div><div class="cc-note">${X(w.root || w.storage)}</div><div class="cc-sub">${w.missions} mission(s)${w.active ? ' · ' + w.active + ' active(s)' : ''}${w.last ? ' · dernière : ' + X(w.last.title.slice(0, 30)) : ''}</div><div style="margin-top:8px"><button class="mini" data-ws="${w.id}" ${w.exists ? '' : 'disabled'}>Ouvrir</button></div></div>`).join('')}</div>`;
  $$('[data-ws]', b).forEach(x => x.onclick = async () => { cur = x.dataset.ws; localStorage.cur = cur; conv = null; $q('#projects').value = cur; await refreshProject(); clearThread(); toast('Projet ouvert', 'ok'); render(true); });
}

/* ── Intégrations : bouton, commandes, route de chat, recommandation hybride ── */
function integrate() {
  const bar = $q('.kbar'), mk = () => { const b = document.createElement('button'); b.className = 'kib cc-bell'; b.type = 'button'; b.title = 'Command Center (Alt+Maj+K)'; b.setAttribute('aria-label', 'Command Center'); b.innerHTML = '<svg class="svg-icon"><use href="icons/icons.svg#layers"></use></svg>'; b.onclick = () => open(); return b; };
  if (bar) bar.insertBefore(mk(), bar.querySelector('.kib')); else { const t = $q('.toolbar .grow'); if (t) t.after(mk()); }
  try { for (const [k, l] of PAGES) AstraUI.registerCommand('cc.' + k, 'Command Center : ' + l, 'Command Center', 'layers', k === 'overview' ? 'Alt+Maj+K' : '', () => open(k)); } catch {}
  window.addEventListener('keydown', e => { if (e.altKey && e.shiftKey && !e.ctrlKey && !e.metaKey && e.code === 'KeyK') { e.preventDefault(); root && root.classList.contains('open') ? close() : open(); } else if (e.key === 'Escape' && root && root.classList.contains('open') && !$q('dialog[open]')) close(); }, true);
  const orig = window.renderChatEvent;
  if (typeof orig === 'function') window.renderChatEvent = function (c, e) {
    if (e && e.t === 'route') { const d = document.createElement('div'); d.className = 'cc-chip-route'; d.textContent = e.error ? '⚠ ' + e.error : '✦ Modèle choisi par Astra : ' + e.id + ' — ' + e.explanation; c.append(d); return; }
    return orig.apply(this, arguments);
  };
  const mode = $q('#mode');
  if (mode) { const btn = document.createElement('button'); btn.type = 'button'; btn.className = 'icon'; btn.title = 'Recommander un modèle pour la demande en cours'; btn.textContent = '✦'; mode.after(btn);
    btn.onclick = async () => { const msg = $q('#message').value.trim(); if (!msg) return toast('Écris d’abord ta demande, puis clique ✦.', 'warn'); const r = await A('intelligence/route', 'POST', { message: msg, files: (attachments || []).map(f => ({ name: f.name })) }); if (!r.recommended) return toast(r.explanation, 'warn');
      if (confirm(r.explanation + '\n\nAppliquer ' + r.recommended.id + ' ?')) { localStorage.pv = r.recommended.provider; localStorage.md = r.recommended.model; $q('#provider').value = r.recommended.provider; await loadModels(); $q('#model').value = r.recommended.model; } }; }
  setInterval(() => { if (!root || !root.classList.contains('open')) pollAct().then(renderNavSafe); }, 5000);
}
const renderNavSafe = () => { if (root) renderNav(); };
function init() { try { integrate(); } catch (e) { console.warn('[command-center]', e); } window.AstraCC = { open, close }; }
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => setTimeout(init, 0)); else setTimeout(init, 0);
})();
