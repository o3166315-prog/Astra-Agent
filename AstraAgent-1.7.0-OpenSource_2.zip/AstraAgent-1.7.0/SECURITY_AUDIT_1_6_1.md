# Astra Agent 1.6.1 — rapport d'audit ciblé

**Date :** 4 novembre 2026  
**Base examinée :** archive `AstraAgent-1.6.0-OpenSource.zip` fournie dans cette conversation.  
**Intégration :** composants Self-Healing, Auto Testing, Voice navigateur et Mission Recovery/Export repris de `AstraAgent-1.5.6.zip`, puis raccordés à la base 1.6.0.  
**Nature du document :** revue ciblée du code et tests automatisés ; ce n'est pas un audit indépendant certifié ni une garantie d'absence de vulnérabilités.

## Correctifs appliqués

| Point examiné | Changement effectué |
|---|---|
| Liens symboliques | Validation centralisée des composants du chemin ; refus dans les chemins projet, les permissions, les parcours, les snapshots et l'export. |
| Liens matériels | Refus des fichiers ayant plusieurs liens (`nlink > 1`) dans les contrôles de chemins. |
| Racines trop larges | `/` et le dossier personnel sont refusés comme racine de workspace. Les chemins parents contenant un lien symbolique sont également refusés. |
| Calculatrice | `new Function` supprimé de la calculatrice de l'agent **et** de celle du serveur MCP de démonstration. Un parseur limité aux opérations et fonctions mathématiques autorisées est utilisé. |
| JSON HTTP | Un corps JSON invalide ou d'un type inattendu renvoie HTTP 400 ; les corps trop volumineux sont rejetés. |
| Paramètres de provider | Une mise à jour de clé sans URL ne remplace plus l'URL existante ; l'effacement d'URL doit être explicite. |
| Écriture de paramètres | Écriture dans un fichier temporaire du même dossier, synchronisation, puis renommage atomique. |
| Recovery | Recovery partage maintenant le gestionnaire Time Machine ; les fichiers apparus depuis le snapshot sont déplacés en quarantaine au lieu d'être supprimés. |
| Fichiers internes | Les accès aux sauvegardes internes `.kairo` sont validés avant les écritures. |
| Scripts de test | Les scripts `npm test`, `npm run ...` et l'outil `run_tests` exigent une confirmation, car ils exécutent du code défini par le projet. |
| Modules récupérés | Self-Healing reste en lecture seule ; Auto Testing détecte les tests et ne les lance qu'après autorisation ; Voice utilise les API vocales du navigateur ; Recovery fournit checkpoints et export ZIP avec exclusions de secrets. |

## Tests réalisés

- `npm test` : **réussi** après intégration des correctifs. La suite couvre Council, Time Machine, providers simulés, conversion d'images, outils, permissions, sécurité HTTP, Swarm, historique de mission, Communication Graph, Model Intelligence, Command Center, durcissement des chemins, stockage atomique, Recovery et liens symboliques internes.
- Tests de sécurité HTTP : **18 réussis, 0 échec** dans la suite ciblée.
- Contrôles de durcissement : **12 réussis, 0 échec** après l'ajout du contrôle des liens matériels.
- Calculatrice du serveur MCP de démonstration : test séparé réussi ; opération mathématique correcte et tentative d'accès JavaScript rejetée.
- Route MCP locale : ajout, démarrage, lecture de la liste des outils et arrêt vérifiés dans un test manuel isolé.
- `node --check public/astra-modules.js` et `node --check mcp-demo/server.js` : réussis.

### Test d'intégration complet : non certifié

`tests/agent.test.js` a été lancé. Les scénarios de création HTML, clarification, création/exécution Node et compilation CMake ont réussi. Les scénarios qui nécessitent un navigateur ont été ignorés dans cet environnement. Le processus complet a ensuite dépassé le délai disponible pendant les scénarios suivants ; **la suite d'intégration n'est donc pas déclarée réussie**. Le fonctionnement MCP a été vérifié séparément via le client et la route API.

## Limites de sécurité restantes

1. **Pas de sandbox au niveau du système d'exploitation.** Le moteur de permissions réduit les actions dangereuses, mais le processus Node conserve les droits du compte qui lance Astra.
2. **Risque TOCTOU.** Un chemin peut théoriquement être remplacé entre sa validation et l'opération fichier. Les contrôles actuels ne remplacent pas une isolation OS fondée sur des descripteurs et des restrictions système.
3. **Serveurs MCP tiers.** Un serveur MCP configuré est un programme local et s'exécute avec les droits du compte. Il n'est pas isolé dans un conteneur dédié. N'ajouter que des serveurs de confiance.
4. **Providers externes.** Les tests automatiques utilisent des mocks ou des serveurs locaux ; ils ne prouvent pas qu'une clé Meta, OpenAI, Anthropic ou Gemini fonctionne.
5. **Fonctions non livrées.** Cloud persistant, authentification multi-compte, tableau de bord Web/mobile distant, Marketplace avec sandbox et Astra Image Engine de génération/édition ne sont pas implémentés dans cette archive. Image-to-Data est un convertisseur local, pas un générateur d'images.
6. **Voice.** Dictée et lecture vocale dépendent des capacités du navigateur et du système ; ce n'est pas un service vocal cloud autonome.

## Recommandations avant publication publique

- Tester la restauration, l'export et les liens symboliques sur Windows 10, car cette archive a été testée dans un environnement Linux.
- Faire une revue indépendante de la surface API et du moteur de permissions.
- Vérifier l'historique Git, les secrets et les licences de chaque dépendance/ressource avant de publier le dépôt.
- Pour une isolation forte des outils et serveurs MCP, exécuter les tâches dans un compte OS restreint ou un conteneur correctement configuré.
