const fs = require('fs');
const os = require('os');
const path = require('path');
const assert = require('assert');
const SW = require('../server/swarm');
const perms = require('../server/perms');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'astra-swarm-test-'));
try {
  const project = path.join(tmp, 'project');
  const snapshot = path.join(tmp, 'snapshot');
  const workerA = path.join(tmp, 'worker-a');
  const workerB = path.join(tmp, 'worker-b');
  fs.mkdirSync(path.join(project, 'src'), { recursive: true });
  fs.writeFileSync(path.join(project, 'src', 'main.js'), 'console.log("before");\n');
  fs.writeFileSync(path.join(project, '.env'), 'SECRET=do-not-copy');
  fs.mkdirSync(path.join(project, 'node_modules', 'pkg'), { recursive: true });
  fs.writeFileSync(path.join(project, 'node_modules', 'pkg', 'index.js'), 'ignored');

  const snap = SW.copyWorkspace(project, snapshot);
  assert(snap.count === 1, 'only the project source file should be copied');
  assert(!fs.existsSync(path.join(snapshot, '.env')), 'environment secrets must be excluded');
  assert(!fs.existsSync(path.join(snapshot, 'node_modules')), 'dependencies must be excluded');
  fs.cpSync(snapshot, workerA, { recursive: true });
  fs.cpSync(snapshot, workerB, { recursive: true });

  fs.writeFileSync(path.join(workerA, 'src', 'main.js'), 'console.log("agent A");\n');
  fs.writeFileSync(path.join(workerA, 'src', 'new.js'), 'module.exports = 1;\n');
  let changesA = SW.collectChanges(workerA, snap.baseline, 'a1');
  assert(changesA.length === 2, 'modified and created files should be detected');
  const missionA = { changes: SW.summarizeChanges(changesA, workerA), workers: [{ id: 'a1', workspace: workerA }] };
  const mergedA = SW.mergeChanges(project, missionA);
  assert(mergedA.applied.length === 2, 'non-conflicting changes should be merged');
  assert(fs.readFileSync(path.join(project, 'src', 'main.js'), 'utf8').includes('agent A'));
  assert(fs.existsSync(path.join(project, 'src', 'new.js')));

  const inlineCode = perms.classifyCommand('node -e \"process.exit(0)\"', project);
  assert(inlineCode.level === 'CONFIRM', 'inline code execution must require confirmation');
  assert(perms.classifyCommand('python -c \"print(1)\"', project).level === 'CONFIRM', 'inline Python execution must require confirmation');
  assert(perms.classifyCommand('deno eval \"Deno.exit(0)\"', project).level === 'CONFIRM', 'inline Deno execution must require confirmation');

  // If the source project changes after the snapshot, merge must refuse to overwrite it.
  fs.writeFileSync(path.join(project, 'src', 'main.js'), 'human edit after mission\n');
  fs.writeFileSync(path.join(workerB, 'src', 'main.js'), 'console.log("agent B");\n');
  const changesB = SW.summarizeChanges(SW.collectChanges(workerB, snap.baseline, 'a2'), workerB);
  const missionB = { changes: changesB, workers: [{ id: 'a2', workspace: workerB }] };
  const mergedB = SW.mergeChanges(project, missionB);
  assert(mergedB.conflicts.some(x => x.path === 'src/main.js'), 'modified live files must be treated as conflicts');
  assert(fs.readFileSync(path.join(project, 'src', 'main.js'), 'utf8').includes('human edit'));

  console.log('✓ Astra Swarm : copie isolée, exclusion des secrets/dépendances, détection des changements et fusion protégée');
} finally {
  fs.rmSync(tmp, { recursive: true, force: true });
}
