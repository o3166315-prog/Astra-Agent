const assert = require('assert');
const G = require('../server/comm-graph');

const base = '2026-11-03T10:00:';
const mission = {
  id: 'm1', title: 'Jeu 2D', status: 'ready_for_review', createdAt: base + '00.000Z',
  coordinator: { provider: 'meta', model: 'muse' },
  review: 'Tout est cohérent.',
  workers: [
    { id: 'a1', name: 'Developer', role: 'Dev', provider: 'meta', model: 'muse', task: 'Créer game.js', status: 'completed', startedAt: base + '05.000Z', finishedAt: base + '20.000Z' },
    { id: 'a2', name: 'Designer', role: 'UI', provider: 'meta', model: 'muse', task: 'Créer style.css', status: 'completed', startedAt: base + '05.000Z', finishedAt: base + '55.000Z' },
    { id: 'a3', name: 'Tester', role: 'QA', provider: 'meta', model: 'muse', task: 'Écrire TESTS.md', status: 'failed', startedAt: base + '05.000Z', finishedAt: base + '30.000Z' }
  ],
  events: [
    { at: base + '01.000Z', type: 'mission', copyStats: { files: 3 } },
    { at: base + '04.000Z', type: 'plan', plan: ['p'], workers: [{ id: 'a1', name: 'Developer', task: 'Créer game.js' }, { id: 'a2', name: 'Designer', task: 'Créer style.css' }, { id: 'a3', name: 'Tester', task: 'Écrire TESTS.md' }] },
    { at: base + '05.000Z', type: 'worker', workerId: 'a1', status: 'working', lastAction: 'Démarrage' },
    { at: base + '05.100Z', type: 'worker', workerId: 'a2', status: 'working', lastAction: 'Démarrage' },
    { at: base + '05.200Z', type: 'worker', workerId: 'a3', status: 'working', lastAction: 'Démarrage' },
    { at: base + '10.000Z', type: 'worker-event', workerId: 'a1', event: { at: base + '10.000Z', type: 'tool', message: 'Outil : write_file' } },
    { at: base + '20.000Z', type: 'worker', workerId: 'a1', status: 'completed', result: 'game.js créé', changes: 1 },
    { at: base + '29.000Z', type: 'worker-event', workerId: 'a3', event: { at: base + '29.000Z', type: 'error', message: 'Clé API invalide (401)' } },
    { at: base + '30.000Z', type: 'worker', workerId: 'a3', status: 'failed', result: 'Clé API invalide (401)' },
    { at: base + '55.000Z', type: 'worker', workerId: 'a2', status: 'completed', result: 'style.css créé', changes: 1 },
    { at: base + '56.000Z', type: 'review-start', text: 'Revue' },
    { at: base + '58.000Z', type: 'complete', conflicts: ['index.html'] }
  ]
};

const g = G.buildGraph(mission, { now: Date.parse(base + '59.000Z') });

// Messages réels uniquement, avec la structure AgentMessage
const types = g.messages.map(m => m.type);
assert.strictEqual(types.filter(t => t === 'TASK_ASSIGNMENT').length, 3, 'une attribution par agent');
assert.strictEqual(types.filter(t => t === 'TASK_RESULT').length, 2, 'seuls les agents qui ont terminé envoient un résultat');
assert.strictEqual(types.filter(t => t === 'RESPONSE').length, 1);
assert(!types.includes('QUESTION'), 'aucune question inter-agents inventée');
for (const m of g.messages) {
  for (const k of ['id', 'missionId', 'from', 'to', 'type', 'content', 'timestamp', 'status']) assert(k in m, 'champ ' + k);
  assert(['pending', 'delivered', 'failed'].includes(m.status));
}
assert(g.messages.every((m, i, a) => !i || a[i - 1].timestamp <= m.timestamp), 'messages chronologiques');

// Statuts d'acheminement
const assign = g.messages.filter(m => m.type === 'TASK_ASSIGNMENT');
assert(assign.every(m => m.status === 'delivered'), 'attribution livrée une fois l’agent démarré');
assert(g.messages.filter(m => m.type === 'TASK_RESULT').every(m => m.status === 'delivered'), 'résultats livrés au reviewer');
const errors = g.messages.filter(m => m.type === 'ERROR');
assert.strictEqual(errors.length, 1, 'une seule erreur (pas de doublon erreur + échec)');
assert.strictEqual(errors[0].status, 'failed');
assert.strictEqual(errors[0].from, 'a3');

// Nœuds et arêtes
assert.deepStrictEqual(g.nodes.map(n => n.id), ['coordinator', 'a1', 'a2', 'a3', 'reviewer']);
const a1 = g.nodes.find(n => n.id === 'a1');
assert.strictEqual(a1.status, 'done');
assert.strictEqual(a1.received, 1, 'a1 a reçu sa tâche');
assert.strictEqual(a1.sent, 2, 'a1 : statut + résultat');
assert.strictEqual(g.nodes.find(n => n.id === 'a3').status, 'error');
const e = g.edges.find(x => x.id === 'coordinator>a1');
assert.strictEqual(e.count, 1);
assert(g.edges.find(x => x.id === 'a3>coordinator').failed === 1);

// Détection des goulots et alertes
assert(g.bottlenecks.some(b => b.agentId === 'a2'), 'Designer ralentit la mission');
assert(g.alerts.some(a => a.level === 'error' && /401/.test(a.text)));
assert(g.alerts.some(a => /index\.html/.test(a.text)), 'conflit signalé');
assert(/terminée/i.test(g.diagnosis));

// Relecture : uniquement des événements enregistrés, jusqu'à l'étape demandée
const s0 = G.stateAt(g, 0);
assert.strictEqual(s0.shown, 1);
assert.strictEqual(s0.message.type, 'TASK_ASSIGNMENT');
const sEnd = G.stateAt(g, 999);
assert.strictEqual(sEnd.shown, g.messages.length);

// Export
const svg = G.toSVG(g);
assert(svg.startsWith('<svg') && svg.includes('Developer') && svg.endsWith('</svg>'));
assert.strictEqual(G.toExport(g).format, 'astra-communication-graph');

// Mission en cours : diagnostic « pourquoi bloquée »
const live = G.buildGraph({
  id: 'm2', status: 'planning', workers: [{ id: 'a1', name: 'Dev', status: 'queued' }], events: [{ at: base + '01.000Z', type: 'mission' }]
}, { now: Date.parse(base + '02.000Z') });
assert(/plan/i.test(live.diagnosis));
const paused = G.buildGraph({
  id: 'm3', status: 'working', workers: [{ id: 'a1', name: 'Dev', status: 'paused' }, { id: 'a2', name: 'QA', status: 'working' }],
  events: [{ at: base + '03.000Z', type: 'worker', workerId: 'a1', status: 'working' }, { at: base + '04.000Z', type: 'worker', workerId: 'a1', status: 'paused', lastAction: 'En pause' }]
}, { now: Date.parse(base + '05.000Z') });
assert(/pause/.test(paused.diagnosis) && /Dev/.test(paused.diagnosis));
// Agent silencieux depuis longtemps
const stale = G.buildGraph({
  id: 'm4', status: 'working', workers: [{ id: 'a1', name: 'Dev', status: 'working' }],
  events: [{ at: base + '03.000Z', type: 'worker', workerId: 'a1', status: 'working' }]
}, { now: Date.parse(base + '03.000Z') + 5 * 60000 });
assert(stale.bottlenecks.some(b => /aucune activité/.test(b.text)));
// Sans événement plan (historique tronqué) : on garde les tâches connues
const noPlan = G.buildGraph({ id: 'm5', status: 'working', workers: [{ id: 'a1', name: 'Dev', task: 'X', status: 'working' }], events: [] }, {});
assert.strictEqual(noPlan.messages.filter(m => m.type === 'TASK_ASSIGNMENT').length, 1);
// Mission sans aucune donnée : ne plante pas
assert.doesNotThrow(() => G.buildGraph(null));
console.log('✓ Astra Communication Graph : messages réels, statuts, goulots, diagnostic, relecture et export');
