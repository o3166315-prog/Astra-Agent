'use strict';
const assert=require('assert'),fs=require('fs'),os=require('os'),path=require('path');
const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'astra-internal-link-'));
(async()=>{
  const root=path.join(tmp,'project'),outside=path.join(tmp,'outside');
  fs.mkdirSync(root);fs.mkdirSync(outside);
  fs.symlinkSync(outside,path.join(root,'.kairo'),'dir');
  const {tools}=require('../server/tools');
  await assert.rejects(()=>tools.write_file.run({path:'safe.txt',content:'must not be written'},{root,created:new Set()}),/Lien symbolique refusé/);
  assert.strictEqual(fs.existsSync(path.join(root,'safe.txt')),false,'la cible ne doit pas être modifiée si le backup interne est un lien symbolique');
  assert.strictEqual(fs.readdirSync(outside).length,0,'aucun fichier ne doit être écrit hors du projet');
  await assert.rejects(()=>tools.todo.run({action:'add',text:'test'},{root}),/Lien symbolique refusé/);
  assert.strictEqual(fs.readdirSync(outside).length,0);
  console.log('✓ liens symboliques internes .kairo refusés avant toute écriture et sans sortie du projet');
})().catch(e=>{console.error(e);process.exitCode=1}).finally(()=>fs.rmSync(tmp,{recursive:true,force:true}));
