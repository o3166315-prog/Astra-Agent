// Test de bout en bout : vrai serveur Astra + faux fournisseur OpenAI-compatible (aucun appel Internet, aucun coût).
// Vérifie : lancement réel d'une mission Swarm (régression S.dataDir), graphe issu d'événements réels,
// Command Center (missions, rapport, activité, erreurs, ressources, diagnostic) et Model Intelligence (routes).
const http = require('http'), fs = require('fs'), os = require('os'), path = require('path'), assert = require('assert');
const { spawn } = require('child_process');

const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'astra-cp-')), DATA = path.join(TMP, 'data'), PROJ = path.join(TMP, 'proj');
fs.mkdirSync(PROJ, { recursive: true }); fs.writeFileSync(path.join(PROJ, 'README.md'), '# Demo\n');
const TOKEN = 'cp-' + Math.random().toString(36).slice(2), PORT = 4900 + Math.floor(Math.random() * 400), MOCK_PORT = PORT + 500;
let mockCalls = 0, failMode = false;

// Faux fournisseur : /models, /chat/completions
const mock = http.createServer((req, res) => {
  let b = ''; req.on('data', d => b += d); req.on('end', () => {
    const j = (o, c = 200) => { res.writeHead(c, { 'content-type': 'application/json' }); res.end(JSON.stringify(o)); };
    if (req.url.endsWith('/models')) return j({ data: [{ id: 'mock-small' }, { id: 'mock-large' }] });
    mockCalls++;
    if (failMode) return j({ error: 'boom' }, 500);
    const body = JSON.parse(b || '{}'), sys = String((body.messages || [])[0]?.content || ''), usr = String((body.messages || []).at(-1)?.content || '');
    let content;
    if (/coordinator of Astra Swarm/.test(sys)) content = JSON.stringify({ plan: ['A', 'B'], tasks: [{ agentId: 'a1', task: 'Écrire a.txt' }, { agentId: 'a2', task: 'Écrire b.txt' }] });
    else if (/reviewer indépendant/.test(sys)) content = 'Revue : tout est cohérent.';
    else if (/évalué sur une tâche courte/.test(sys)) content = /Alice/.test(usr) ? '36' : '{"name":"x","tags":["a","b","c"],"priority":2}';
    else content = JSON.stringify({ type: 'final', say: 'Terminé' });
    j({ choices: [{ message: { content } }] });
  });
}).listen(MOCK_PORT, '127.0.0.1');

const srv = spawn('node', ['server/index.js'], { env: { ...process.env, PORT, ASTRA_TOKEN: TOKEN, ASTRA_DATA: DATA, HOME: TMP, USERPROFILE: TMP } });
let srvLog = ''; srv.stdout.on('data', d => srvLog += d); srv.stderr.on('data', d => srvLog += d);
const rq = (method, url, body, raw) => new Promise((ok, ko) => {
  const r = http.request({ host: '127.0.0.1', port: PORT, path: url, method, headers: { host: 'localhost:' + PORT, 'x-astra-token': TOKEN, 'content-type': 'application/json' } }, res => {
    let t = ''; res.on('data', d => t += d); res.on('end', () => { let json = null; try { json = JSON.parse(t); } catch {} ok({ status: res.statusCode, json, text: t }); });
  }); r.on('error', ko); if (body) r.write(JSON.stringify(body)); r.end();
});
const sleep = ms => new Promise(r => setTimeout(r, ms));
let okN = 0, koN = 0;
const T = async (n, f) => { try { await f(); okN++; console.log('  ✓ ' + n); } catch (e) { koN++; console.log('  ✗ ' + n + '\n    ' + String(e.message || e).split('\n')[0]); } };

(async () => {
  for (let i = 0; i < 60; i++) { try { await rq('GET', '/api/state'); break; } catch { await sleep(100); } }
  const proj = (await rq('POST', '/api/projects', { name: 'demo', root: PROJ })).json; assert(proj.id, 'projet créé');
  await rq('POST', '/api/settings', { provider: 'local', url: 'http://127.0.0.1:' + MOCK_PORT + '/v1' });

  console.log('Swarm réel + Communication Graph');
  let missionId;
  await T('une mission Swarm se lance et se termine sans planter le serveur (régression S.dataDir)', async () => {
    const r = await rq('POST', '/api/swarm/run', { project: proj.id, message: 'Créer a.txt et b.txt', agents: [{ name: 'Dev', role: 'Code', provider: 'local', model: 'mock-small' }, { name: 'QA', role: 'Tests', provider: 'local', model: 'mock-small' }], coordinator: { provider: 'local', model: 'mock-large' } });
    assert.strictEqual(r.status, 200, r.text.slice(0, 200));
    const events = r.text.split('\n\n').filter(l => l.startsWith('data: ')).map(l => JSON.parse(l.slice(6)));
    const types = events.map(e => e.type);
    assert(types.includes('plan') && types.includes('complete'), 'plan + complete : ' + types.join(','));
    missionId = events.find(e => e.type === 'mission').mission.id;
    assert(!/Error|TypeError/.test(srvLog), 'le serveur ne doit pas avoir levé d’exception : ' + srvLog.slice(-300));
  });
  await T('/api/comm-graph reconstruit les échanges réellement enregistrés', async () => {
    const r = await rq('GET', '/api/comm-graph?project=' + proj.id + '&id=' + missionId);
    assert.strictEqual(r.status, 200); const g = r.json.graph, types = g.messages.map(m => m.type);
    assert.strictEqual(types.filter(t => t === 'TASK_ASSIGNMENT').length, 2);
    assert.strictEqual(types.filter(t => t === 'TASK_RESULT').length, 2);
    assert(types.includes('RESPONSE') && !types.includes('QUESTION'));
    assert.deepStrictEqual(g.nodes.map(n => n.id), ['coordinator', 'a1', 'a2', 'reviewer']);
    assert(g.messages.filter(m => m.type === 'TASK_ASSIGNMENT').every(m => m.status === 'delivered'));
    assert(/terminée/i.test(g.diagnosis), g.diagnosis);
  });
  await T('/api/comm-graph : mission absente = 404', async () => assert.strictEqual((await rq('GET', '/api/comm-graph?project=zzz')).status, 404));
  await T('Astra Council : avis indépendants puis synthèse', async () => {
    const r = await rq('POST', '/api/council', { project: proj.id, message: 'Comparer deux architectures', agents: [{ name: 'Analyste A', provider: 'local', model: 'mock-small' }, { name: 'Analyste B', provider: 'local', model: 'mock-large' }] });
    assert.strictEqual(r.status, 200, r.text); assert.strictEqual(r.json.result.members.length, 2); assert(r.json.result.final); assert(r.json.result.members.every(m => m.answer));
    const h = await rq('GET', '/api/council-history?project=' + proj.id); assert.strictEqual(h.json.length, 1); assert(h.json[0].members[1].answer);
  });
  await T('Astra Time Machine : snapshot et restauration protégée', async () => {
    fs.writeFileSync(path.join(PROJ, 'restore-me.txt'), 'version 1');
    const a = await rq('POST', '/api/time-machine', { project: proj.id, action: 'snapshot', label: 'avant test' }); assert.strictEqual(a.status, 200, a.text);
    fs.writeFileSync(path.join(PROJ, 'restore-me.txt'), 'version 2'); fs.writeFileSync(path.join(PROJ, 'added-after.txt'), 'extra');
    const no = await rq('POST', '/api/time-machine', { project: proj.id, action: 'restore', id: a.json.snapshot.id }); assert.strictEqual(no.status, 409);
    const yes = await rq('POST', '/api/time-machine', { project: proj.id, action: 'restore', id: a.json.snapshot.id, confirm: true }); assert.strictEqual(yes.status, 200, yes.text);
    assert.strictEqual(fs.readFileSync(path.join(PROJ, 'restore-me.txt'), 'utf8'), 'version 1'); assert(!fs.existsSync(path.join(PROJ, 'added-after.txt'))); assert(yes.json.quarantine);
  });

  console.log('Command Center');
  await T('vue d’ensemble : compteurs réels', async () => {
    const o = (await rq('GET', '/api/cc/overview')).json;
    assert.strictEqual(o.version, require('../package.json').version); assert.strictEqual(o.missions.total, 1); assert.strictEqual(o.missions.active, 0); assert.strictEqual(o.agents.active, 0);
    assert(o.models.providers.some(p => p.id === 'local'));
  });
  await T('gestionnaire de missions : statut, progression, agents', async () => {
    const m = (await rq('GET', '/api/cc/missions')).json.missions[0];
    assert.strictEqual(m.id, missionId); assert.strictEqual(m.status, 'completed'); assert.strictEqual(m.progress, 100); assert.strictEqual(m.agents.length, 2); assert.strictEqual(m.projectName, 'demo');
  });
  await T('rapport de mission Markdown et JSON', async () => {
    const md = (await rq('GET', '/api/cc/mission-report?id=' + missionId)).json;
    assert(md.filename.endsWith('.md') && /# Rapport de mission/.test(md.text) && /Chronologie des échanges/.test(md.text) && /Revue : tout est cohérent/.test(md.text));
    const js = (await rq('GET', '/api/cc/mission-report?id=' + missionId + '&format=json')).json;
    assert.strictEqual(JSON.parse(js.text).graph.format, 'astra-communication-graph');
    assert.strictEqual((await rq('GET', '/api/cc/mission-report?id=nope')).status, 404);
  });
  await T('annulation : mission inactive = 404 ; action inconnue refusée', async () => {
    assert.strictEqual((await rq('POST', '/api/cc/mission-control', { id: missionId, action: 'cancel', confirm: true })).status, 404);
    assert.strictEqual((await rq('POST', '/api/cc/mission-control', { id: missionId, action: 'format-c' })).status, 404);
    assert.strictEqual((await rq('GET', '/api/cc/mission-control')).status, 405);
  });
  await T('activité en direct : événements réels filtrables', async () => {
    const a = (await rq('GET', '/api/cc/activity')).json; assert(a.events.length > 3 && a.last > 0);
    assert(a.events.some(e => e.source === 'system') && a.events.some(e => e.source === 'swarm' && /Mission terminée/.test(e.message)));
    assert(a.events.every(e => e.at && e.id));
    const f = (await rq('GET', '/api/cc/activity?source=swarm&mission=' + missionId)).json; assert(f.events.length && f.events.every(e => e.mission === missionId));
    assert.strictEqual((await rq('GET', '/api/cc/activity?since=' + a.last)).json.events.length, 0, 'since ne renvoie que le nouveau');
  });
  await T('ressources : valeurs mesurées, GPU/réseau honnêtes', async () => {
    const r = (await rq('GET', '/api/cc/resources?force=1')).json;
    assert(r.cpu.cores > 0 && r.ram.totalBytes > 0 && r.ram.percent >= 0 && r.astra.pid > 0 && r.astra.rssBytes > 0);
    assert(typeof r.gpu.available === 'boolean'); assert(/non mesurable/.test(r.network.note)); assert(/CE PC/.test(r.scope));
  });
  await T('diagnostic : liste de contrôles avec statut', async () => {
    const d = (await rq('GET', '/api/cc/diagnostics')).json;
    assert(['ok', 'warn', 'fail'].includes(d.status) && d.checks.length >= 6 && d.checks.every(c => c.id && c.status));
    assert.strictEqual(d.checks.find(c => c.id === 'node').status, 'ok'); assert.strictEqual(d.checks.find(c => c.id === 'data').status, 'ok');
  });
  await T('espaces de travail : projets, missions, dernière activité', async () => {
    const w = (await rq('GET', '/api/cc/workspaces')).json.workspaces[0];
    assert.strictEqual(w.name, 'demo'); assert.strictEqual(w.missions, 1); assert.strictEqual(w.exists, true); assert.strictEqual(w.last.id, missionId);
  });

  console.log('Error Center');
  await T('une erreur fournisseur réelle est enregistrée, dédoublonnée et résolvable', async () => {
    failMode = true;
    for (let i = 0; i < 2; i++) await rq('POST', '/api/intelligence/ask', { message: 'Bonjour', choose: 'local/mock-small' });
    failMode = false;
    const e = (await rq('GET', '/api/cc/errors')).json; const it = e.errors.find(x => /local\/mock-small/.test(x.origin));
    assert(it, JSON.stringify(e.errors.map(x => x.origin))); assert(it.count >= 2, 'doublons regroupés : ' + it.count); assert(it.solution && it.status === 'open' && it.id && it.at && it.severity);
    assert(e.open >= 1);
    assert.strictEqual((await rq('POST', '/api/cc/errors', { id: it.id, status: 'resolved' })).status, 200);
    assert.strictEqual((await rq('GET', '/api/cc/errors?status=open')).json.errors.some(x => x.id === it.id), false);
    assert.strictEqual((await rq('POST', '/api/cc/errors', { id: it.id, status: 'nimporte' })).status, 404);
  });

  console.log('Model Intelligence');
  await T('registre : modèles réels du fournisseur, rien d’inventé', async () => {
    const s = (await rq('GET', '/api/intelligence?refresh=1')).json;
    const ids = s.registry.entries.map(e => e.id); assert(ids.includes('local/mock-small') && ids.includes('local/mock-large'));
    const e = s.registry.entries.find(x => x.id === 'local/mock-small');
    assert.strictEqual(e.capabilities.coding.score, null); assert.strictEqual(e.capabilities.coding.source, 'unknown'); assert.strictEqual(e.cost.source, 'local');
    assert(s.registry.problems.length >= 1, 'les fournisseurs sans clé sont signalés');
    assert.strictEqual(s.tasks.length, 5); assert.strictEqual(s.config.mode, 'hybrid');
  });
  await T('analyse de tâche + recommandation en mode hybride (aucune décision à ta place)', async () => {
    const a = (await rq('POST', '/api/intelligence/analyze', { message: 'Corrige ce bug dans mon script Python' })).json.task; assert.strictEqual(a.task, 'debugging');
    const r = (await rq('POST', '/api/intelligence/route', { message: 'Écris une fonction JavaScript' })).json;
    assert.strictEqual(r.mode, 'hybrid'); assert(r.recommended && r.needsUserChoice && r.chosen === null); assert(r.explanation && r.ranking.length >= 2);
  });
  await T('réglages validés ; mode manuel : choix de l’utilisateur', async () => {
    const bad = (await rq('POST', '/api/intelligence/settings', { mode: 'chaos', weights: { cost: 1e9 }, overrides: { '../x': { context: 1 } } })).json.config;
    assert.strictEqual(bad.mode, 'hybrid'); assert.strictEqual(bad.weights.cost, 100); assert(!bad.overrides['../x']);
    await rq('POST', '/api/intelligence/settings', { mode: 'manual' });
    const r = (await rq('POST', '/api/intelligence/route', { message: 'Bonjour', provider: 'local', model: 'mock-large' })).json;
    assert.strictEqual(r.chosen.id, 'local/mock-large'); assert.strictEqual(r.chosen.by, 'user');
    assert.strictEqual((await rq('GET', '/api/intelligence/settings')).status, 405);
  });
  await T('ask : mode auto choisit seul, mode hybride exige un choix', async () => {
    await rq('POST', '/api/intelligence/settings', { mode: 'hybrid' });
    const h = await rq('POST', '/api/intelligence/ask', { message: 'Bonjour' }); assert.strictEqual(h.status, 409); assert(h.json.needsUserChoice);
    await rq('POST', '/api/intelligence/settings', { mode: 'auto' });
    const a = await rq('POST', '/api/intelligence/ask', { message: 'Bonjour' }); assert.strictEqual(a.status, 200, a.text.slice(0, 200)); assert(a.json.answer && a.json.used.id.startsWith('local/'));
    await rq('POST', '/api/intelligence/settings', { mode: 'hybrid' });
  });
  await T('benchmark : confirmation obligatoire puis notes enregistrées comme « testées »', async () => {
    const before = mockCalls;
    const c = await rq('POST', '/api/intelligence/benchmark', { models: ['local/mock-small'] }); assert.strictEqual(c.status, 409); assert.strictEqual(c.json.requests, 5); assert.strictEqual(mockCalls, before, 'aucun appel sans confirmation');
    assert.strictEqual((await rq('POST', '/api/intelligence/benchmark', { models: [] })).status, 400);
    const r = await rq('POST', '/api/intelligence/benchmark', { models: ['local/mock-small'], confirm: true });
    const evs = r.text.split('\n\n').filter(l => l.startsWith('data: ')).map(l => JSON.parse(l.slice(6)));
    assert.strictEqual(evs.filter(e => e.type === 'progress').length, 5); const done = evs.find(e => e.type === 'done');
    const res = done.results['local/mock-small']; assert.strictEqual(res.byCategory.reasoning.score, 100); assert.strictEqual(res.byCategory.structured.score, 100);
    const s = (await rq('GET', '/api/intelligence')).json, e = s.registry.entries.find(x => x.id === 'local/mock-small');
    assert.strictEqual(e.capabilities.reasoning.source, 'tested'); assert(s.benchmarks['local/mock-small']);
    assert(s.perModel.find(x => x.id === 'local/mock-small').requests >= 5, 'latence/volume mesurés par le moniteur');
  });
  await T('mode auto : le chat annonce le modèle choisi par le routeur', async () => {
    await rq('POST', '/api/intelligence/settings', { mode: 'auto' });
    const r = await rq('POST', '/api/chat', { mode: 'chat', project: proj.id, provider: 'local', model: 'mock-small', message: 'Bonjour' });
    const evs = r.text.split('\n\n').filter(l => l.startsWith('data: ')).map(l => JSON.parse(l.slice(6)));
    const route = evs.find(e => e.t === 'route'); assert(route && route.id && route.explanation, JSON.stringify(evs.slice(0, 3)));
    await rq('POST', '/api/intelligence/settings', { mode: 'hybrid' });
  });
  await T('les prompts ne sont jamais écrits sur disque par le moniteur', async () => {
    await rq('POST', '/api/intelligence/ask', { message: 'PROMPT-SECRET-12345', choose: 'local/mock-small' }); await sleep(1800);
    const txt = fs.readdirSync(DATA).filter(f => f.startsWith('intel-')).map(f => fs.readFileSync(path.join(DATA, f), 'utf8')).join('');
    assert(txt.length > 10 && !txt.includes('PROMPT-SECRET-12345'));
  });
  await T('toutes les nouvelles routes exigent le jeton', async () => {
    for (const u of ['/api/comm-graph', '/api/cc/overview', '/api/cc/resources', '/api/cc/errors', '/api/intelligence']) {
      const st = await new Promise(ok => http.get({ host: '127.0.0.1', port: PORT, path: u, headers: { host: 'localhost:' + PORT } }, r => { r.resume(); ok(r.statusCode); }));
      assert.strictEqual(st, 403, u);
    }
  });
  console.log('\n' + okN + ' réussis, ' + koN + ' échoués');
})().catch(e => { console.error(e); koN++; }).finally(() => { srv.kill(); mock.close(); setTimeout(() => { fs.rmSync(TMP, { recursive: true, force: true }); process.exit(koN ? 1 : 0); }, 300); });
