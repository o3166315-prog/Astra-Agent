// Tests des outils V5.1 (node tests/newtools.test.js) : vrais fichiers, vraies permissions, aucun modèle.
const assert=require('node:assert/strict'),fs=require('fs'),os=require('os'),path=require('path'),http=require('http');
const {tools}=require('../server/tools'),perms=require('../server/perms'),{calc}=require('../server/moretools');
const root=fs.mkdtempSync(path.join(os.tmpdir(),'kairo-nt-')),ctx={root,emit(){},created:new Set()};
const run=(n,a)=>tools[n].run(a,ctx),txt=r=>String(r&&r.text!==undefined?r.text:r),rd=f=>fs.readFileSync(path.join(root,f),'utf8');
const rejects=async(p,re)=>{try{await p}catch(e){assert.match(e.message,re);return}assert.fail('aurait dû échouer')};
const lvl=(n,a)=>perms.classifyTool(n,a,{root,created:new Set()}).level;
let ok=0;const T=async(n,f)=>{await f();ok++;console.log('  ✓',n)};

(async()=>{
 await run('write_file',{path:'src/app.js',content:'const a=1;\nconst b=2;\nconst a2=1;\n'});

 await T('edit_file : remplacement exact + diff + sauvegarde',async()=>{
  const r=await run('edit_file',{path:'src/app.js',old:'const b=2;',new:'const b=3;'});
  assert.match(r.text,/1 remplacement/);assert.ok(r.diff&&r.changeId);assert.match(rd('src/app.js'),/b=3/)});
 await T('edit_file : introuvable, ambigu, all',async()=>{
  await rejects(run('edit_file',{path:'src/app.js',old:'xyz',new:'q'}),/introuvable/);
  await rejects(run('edit_file',{path:'src/app.js',old:'const a',new:'let a'}),/2 occurrences/);
  assert.match(txt(await run('edit_file',{path:'src/app.js',old:'const a',new:'let a',all:true})),/2 remplacements/);assert.match(rd('src/app.js'),/let a=1/)});
 await T('edit_file / append_file refusent la zone interne .kairo',async()=>{
  await rejects(run('append_file',{path:'.kairo/x.txt',content:'a'}),/interne/);
  await rejects(run('make_dir',{path:'.git/x'}),/interne/)});
 await T('append_file : crée puis ajoute avec saut de ligne',async()=>{
  await run('append_file',{path:'notes.txt',content:'un'});await run('append_file',{path:'notes.txt',content:'deux'});assert.equal(rd('notes.txt'),'un\ndeux')});
 await T('read_lines : plage numérotée',async()=>{
  const r=txt(await run('read_lines',{path:'src/app.js',start:2,end:2}));assert.match(r,/lignes 2-2 sur/);assert.match(r,/ 2│ const b=3;/)});
 await T('find_files : glob avec et sans dossier',async()=>{
  assert.match(txt(await run('find_files',{pattern:'*.js'})),/src[\\/]app\.js/);
  assert.match(txt(await run('find_files',{pattern:'src/**/*.js'})),/app\.js/);
  assert.equal(txt(await run('find_files',{pattern:'*.rs'})),'Aucun fichier')});
 await T('file_info : taille, lignes, sha256',async()=>{const r=txt(await run('file_info',{path:'notes.txt'}));assert.match(r,/taille : 7 octets/);assert.match(r,/lignes : 2/);assert.match(r,/sha256 : [0-9a-f]{64}/)});
 await T('move_file / copy_file / make_dir',async()=>{
  await run('make_dir',{path:'a/b'});await run('copy_file',{from:'notes.txt',to:'a/b/copie.txt'});await run('move_file',{from:'a/b/copie.txt',to:'a/deplace.txt'});
  assert.ok(fs.existsSync(path.join(root,'a/deplace.txt'))&&!fs.existsSync(path.join(root,'a/b/copie.txt')));
  await rejects(run('move_file',{from:'notes.txt',to:'a/deplace.txt'}),/déjà existante/);
  await rejects(run('move_file',{from:'absent.txt',to:'z.txt'}),/Inexistant/)});
 await T('diff_files',async()=>{assert.match(txt(await run('diff_files',{a:'notes.txt',b:'a/deplace.txt'})),/identiques/);
  await run('write_file',{path:'c.txt',content:'un\ntrois'});assert.match(txt(await run('diff_files',{a:'notes.txt',b:'c.txt'})),/- deux[\s\S]*\+ trois/)});
 await T('replace_in_files : aperçu par défaut puis apply',async()=>{
  const a=txt(await run('replace_in_files',{query:'un',replacement:'UN',glob:'*.txt'}));assert.match(a,/Aperçu/);assert.equal(rd('notes.txt'),'un\ndeux');
  const b=txt(await run('replace_in_files',{query:'un',replacement:'UN',glob:'*.txt',apply:true}));assert.match(b,/Remplacé/);assert.equal(rd('notes.txt'),'UN\ndeux');
  await rejects(run('replace_in_files',{query:'x',replacement:'y',path:'..'}),/hors du projet/)});
 await T('check_syntax : js valide/invalide, json',async()=>{
  assert.match(txt(await run('check_syntax',{path:'src/app.js'})),/valide/);
  await run('write_file',{path:'bad.js',content:'function ('});await rejects(run('check_syntax',{path:'bad.js'}),/syntaxe/i);
  await run('write_file',{path:'d.json',content:'{"a":1'});await rejects(run('check_syntax',{path:'d.json'}),/JSON invalide/)});
 await T('json_query : chemins imbriqués',async()=>{
  await run('write_file',{path:'p.json',content:JSON.stringify({scripts:{test:'x'},items:[{name:'n0'}]})});
  assert.equal(JSON.parse(txt(await run('json_query',{path:'p.json',query:'items[0].name'}))),'n0');
  assert.match(txt(await run('json_query',{path:'p.json'})),/clés : scripts, items/);await rejects(run('json_query',{path:'p.json',query:'nope'}),/introuvable/)});
 await T('calculate : valeurs correctes et injections refusées',async()=>{
  assert.equal(calc('(12+8)*3'),60);assert.equal(calc('2^10'),1024);assert.equal(calc('sqrt(16)+max(1,5)'),9);assert.equal(calc('1e3+1'),1001);
  for(const bad of['process.exit()','constructor','this','require("fs")','1/0','a+1','alert(1)','Math.PI'])assert.throws(()=>calc(bad),bad)});
 await T('get_time / system_info / project_summary',async()=>{
  assert.match(txt(await run('get_time',{tz:'Asia/Tokyo'})),/ISO :/);await rejects(run('get_time',{tz:'Mars/Olympus'}),/Fuseau/);
  assert.match(txt(await run('system_info',{})),/Node : v/);assert.match(txt(await run('project_summary',{})),/fichiers : \d+/)});
 await T('todo : ajouter, terminer, supprimer, vider',async()=>{
  await run('todo',{action:'add',text:'écrire les tests'});await run('todo',{action:'add',text:'publier'});
  assert.match(txt(await run('todo',{action:'done',id:1})),/\[x\] #1 écrire les tests[\s\S]*\[ \] #2 publier/);
  assert.doesNotMatch(txt(await run('todo',{action:'remove',id:1})),/#1/);assert.equal(txt(await run('todo',{action:'clear'})),'Liste vidée');await rejects(run('todo',{action:'done',id:9}),/introuvable/)});
 await T('http_request : serveur local, POST JSON, schémas refusés',async()=>{
  const srv=http.createServer((q,s)=>{let b='';q.on('data',d=>b+=d);q.on('end',()=>{s.setHeader('content-type','application/json');s.end(JSON.stringify({m:q.method,body:b}))})}).listen(0);
  await new Promise(r=>srv.once('listening',r));const u='http://127.0.0.1:'+srv.address().port;
  try{const r=txt(await run('http_request',{url:u,method:'POST',body:{x:1}}));assert.match(r,/HTTP 200/);assert.match(r,/"m": "POST"/);assert.match(r,/\{\\"x\\":1\}/);
   await rejects(run('http_request',{url:'file:///etc/passwd'}),/http et https/);await rejects(run('http_request',{url:u,method:'TRACE'}),/méthode/)}finally{srv.close()}});
 await T('run_tests : détecte npm test et signale l’absence de tests',async()=>{
  await rejects(run('run_tests',{}),/Aucun test détecté/);
  await run('write_file',{path:'package.json',content:JSON.stringify({scripts:{test:'node -e "console.log(42)"'}})});
  const r=txt(await run('run_tests',{}));assert.match(r,/exit 0/);assert.match(r,/42/)});

 console.log('\nPermissions');
 await T('lecture / écriture dans le projet = SAFE',()=>{
  for(const[n,a]of[['edit_file',{path:'a.js'}],['append_file',{path:'a.js'}],['make_dir',{path:'x'}],['read_lines',{path:'a.js'}],['file_info',{path:'a.js'}],['find_files',{pattern:'*'}],['json_query',{path:'p.json'}],['check_syntax',{path:'a.js'}],
   ['diff_files',{a:'a',b:'b'}],['move_file',{from:'a',to:'b'}],['copy_file',{from:'a',to:'b'}],['replace_in_files',{query:'a',replacement:'b'}],['calculate',{expression:'1+1'}],['get_time',{}],['system_info',{}],['project_summary',{}],['todo',{action:'list'}]])
   assert.equal(lvl(n,a),'SAFE',n)});
 await T('hors du projet = CONFIRM ou DANGER',()=>{
  assert.equal(lvl('edit_file',{path:'../hors.js'}),'CONFIRM');assert.equal(lvl('move_file',{from:'a',to:'../hors.js'}),'CONFIRM');assert.equal(lvl('copy_file',{from:'/etc/passwd',to:'a'}),'CONFIRM');
  assert.equal(lvl('read_lines',{path:'/etc/passwd'}),'CONFIRM');assert.equal(lvl('append_file',{path:'/etc/passwd'}),'DANGER');assert.equal(lvl('diff_files',{a:'a',b:'/etc/hosts'}),'CONFIRM')});
 await T('http_request : local = SAFE, externe = CONFIRM réseau',()=>{
  assert.equal(lvl('http_request',{url:'http://localhost:3000/x'}),'SAFE');const c=perms.classifyTool('http_request',{url:'https://exemple.com',method:'post'},{root,created:new Set()});assert.equal(c.level,'CONFIRM');assert.equal(c.cat,'NETWORK')});
 await T('run_tests exige une confirmation car le script appartient au projet',()=>assert.equal(lvl('run_tests',{}),'CONFIRM'));
 await T('outils inconnus restent CONFIRM',()=>assert.equal(lvl('outil_inventé',{}),'CONFIRM'));

 console.log(`\n${ok} tests OK`);fs.rmSync(root,{recursive:true,force:true});
})().catch(e=>{console.error('\n✗',e.message);process.exitCode=1});
