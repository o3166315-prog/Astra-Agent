const fs = require('fs'), os = require('os'), path = require('path'), assert = require('assert');
const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'astra-intel-'));
process.env.ASTRA_DATA = TMP;
const Intel = require('../server/intelligence');
const { analyze } = require('../server/intelligence/task-analyzer');
const { evaluate, weightsFor } = require('../server/intelligence/model-evaluator');
const { route } = require('../server/intelligence/intelligent-router');
const { runWithFallback, classifyError } = require('../server/intelligence/fallback-manager');
const B = require('../server/intelligence/benchmark-engine');
const { createMonitor } = require('../server/intelligence/performance-monitor');
const Reg = require('../server/intelligence/model-registry');

(async () => {
  // ── Task Analyzer
  const t1 = analyze('Analyse ce projet Python, trouve les bugs et corrige-les dans plusieurs fichiers');
  assert.strictEqual(t1.task, 'debugging'); assert(t1.requiresTools); assert(t1.heuristic);
  assert.strictEqual(analyze('Écris une fonction Python qui trie une liste').task, 'coding');
  assert.strictEqual(analyze('Résume ce document').task, 'document');
  assert.strictEqual(analyze({ text: 'Décris ceci', images: 1 }).requiresVision, true);
  assert.strictEqual(analyze({ text: 'Décris ceci', files: [{ path: 'a.png' }] }).task, 'vision');
  assert.strictEqual(analyze('Explique cette architecture').task, 'reasoning');
  assert.strictEqual(analyze('salut').complexity, 'low');
  assert.strictEqual(analyze('Donne-moi une réponse rapide à une question simple').priority, 'speed');
  assert(analyze({ text: 'x'.repeat(100), files: [{ chars: 64000 }] }).contextRequired > 20000);

  // ── Registre avec faux fournisseurs : rien d'inventé, sources distinguées
  const mk = (label, models, vision) => ({ label, models: async () => models, vision: async (s, m) => vision(m), chat: async () => 'ok' });
  const providers = {
    openai: mk('OpenAI', ['big', 'small'], () => true),
    meta: mk('Meta', ['muse-a'], m => /vision/.test(m)),
    ollama: mk('Ollama', ['llama3'], () => false),
    gemini: mk('Gemini', ['g1'], () => true),
    broken: { label: 'Broken', models: async () => { throw new Error('Clé API invalide (401)'); }, vision: async () => false, chat: async () => '' }
  };
  const settings = { openai: { key: 'k' }, meta: { key: 'k' }, ollama: { ctx: 4096 }, broken: { key: 'k' } }; // gemini sans clé
  const monitor = createMonitor({ read: (n, d) => d, write: () => {} });
  const cfg = { overrides: { 'openai/big': { context: 128000, costIn: 5, costOut: 15 }, 'openai/small': { costIn: 0.5, costOut: 1.5 } } };
  const reg = await Reg.list({ providers, settings, benchmarks: { 'openai/big': { at: 'T', byCategory: { coding: { score: 90 }, debugging: { score: 80 } } } }, monitor, cfg, force: true });
  const byId = Object.fromEntries(reg.entries.map(e => [e.id, e]));
  assert(!byId['gemini/g1'], 'fournisseur sans clé non listé');
  assert(reg.problems.some(p => p.provider === 'gemini'), 'clé manquante signalée');
  assert(reg.problems.some(p => p.provider === 'broken' && /401/.test(p.error)), 'erreur fournisseur signalée');
  assert.strictEqual(byId['openai/big'].capabilities.coding.source, 'tested');
  assert.strictEqual(byId['openai/small'].capabilities.coding.source, 'unknown');
  assert.strictEqual(byId['openai/small'].capabilities.coding.score, null, 'jamais de score inventé');
  assert.strictEqual(byId['openai/small'].context.source, 'unknown');
  assert.strictEqual(byId['openai/big'].context.source, 'user');
  assert.strictEqual(byId['ollama/llama3'].type, 'local'); assert.strictEqual(byId['ollama/llama3'].cost.source, 'local');
  assert.strictEqual(byId['openai/big'].vision.source, 'declared'); assert.strictEqual(byId['meta/muse-a'].vision.source, 'heuristic');
  assert.strictEqual(Reg.estimateCost(byId['openai/small'], 3200, 3200), (1000 * 0.5 + 1000 * 1.5) / 1e6);
  assert.strictEqual(Reg.estimateCost(byId['meta/muse-a'], 3200, 3200), null, 'pas de prix saisi => pas d’estimation');

  // ── Évaluateur : contraintes obligatoires avant notation
  const task = analyze('Analyse ce projet Python, trouve les bugs et corrige-les');
  let ev = evaluate(reg.entries, task, cfg, settings);
  assert.strictEqual(ev.ranked[0].entry.id, 'openai/big', 'le seul modèle testé en debugging domine');
  const vis = evaluate(reg.entries, { ...task, requiresVision: true }, cfg, settings);
  assert(vis.eliminated.some(x => x.entry.id === 'ollama/llama3' && x.reasons.includes('pas de vision')));
  assert(vis.eliminated.some(x => x.entry.id === 'meta/muse-a' && /vision/.test(x.reasons[0])), 'vision heuristique non confirmée => exclu');
  assert(!vis.ranked.some(r => r.entry.id === 'ollama/llama3'));
  const big = evaluate(reg.entries, { ...task, contextRequired: 20000 }, cfg, settings);
  assert(big.eliminated.some(x => x.entry.id === 'ollama/llama3' && /contexte insuffisant/.test(x.reasons.join())));
  const budget = evaluate(reg.entries, task, { ...cfg, maxCostPer1M: 2 }, settings);
  assert(budget.eliminated.some(x => x.entry.id === 'openai/big' && /budget/.test(x.reasons.join())));
  const local = evaluate(reg.entries, task, { ...cfg, localOnly: true }, settings);
  assert(local.ranked.every(r => r.entry.type === 'local'));
  const nokey = evaluate(reg.entries, task, cfg, { ...settings, openai: {} });
  assert(nokey.eliminated.some(x => x.entry.id === 'openai/small' && x.reasons.includes('clé API manquante')));
  assert(ev.ranked[0].parts.reduce((a, p) => a + p.weight, 0) > 99.5, 'poids normalisés');
  assert(ev.ranked.find(r => r.entry.id === 'openai/small').warnings.some(w => /non testée/.test(w)));
  const w = weightsFor({ weights: { capability: 70, quality: 0, cost: 0, latency: 0, context: 0, reliability: 0 } }, { priority: 'balanced' });
  assert(Math.abs(w.capability - 1) < 1e-9);
  const cheap = evaluate(reg.entries.filter(e => e.provider === 'openai'), { ...task, priority: 'cost' }, cfg, settings);
  assert(cheap.ranked[0].parts.find(p => p.criterion === 'cost').weight > 30, 'priorité coût renforce le poids du coût');

  // ── Routeur : qui décide dépend du mode
  const rA = await route(task, { registry: reg, cfg: { ...cfg, mode: 'auto' }, settings, monitor });
  assert.strictEqual(rA.chosen.by, 'astra'); assert(/score/.test(rA.explanation)); assert(rA.eliminated.length >= 0);
  const rH = await route(task, { registry: reg, cfg: { ...cfg, mode: 'hybrid' }, settings, monitor });
  assert.strictEqual(rH.chosen, null); assert(rH.needsUserChoice); assert(rH.recommended.id);
  const rM = await route(task, { registry: reg, cfg: { ...cfg, mode: 'manual' }, settings, monitor, manual: { provider: 'ollama', model: 'llama3' } });
  assert.strictEqual(rM.chosen.id, 'ollama/llama3'); assert.strictEqual(rM.chosen.by, 'user');
  assert(monitor.selections().length >= 3, 'historique des sélections');
  const none = await route(task, { registry: { entries: [], problems: [] }, cfg, settings, monitor });
  assert.strictEqual(none.recommended, null); assert(/Aucun modèle/.test(none.explanation));

  // ── Fallback : idempotent => bascule ; non idempotent => jamais relancé à l'aveugle
  const cands = [{ provider: 'a', model: 'm1', id: 'a/m1' }, { provider: 'b', model: 'm2', id: 'b/m2' }];
  let calls = [];
  const noDelay = { delay: async () => {} };
  let r = await runWithFallback(cands, async c => { calls.push(c.id); if (c.id === 'a/m1') throw new Error('Provider timeout'); return 'OK'; }, { idempotent: true, ...noDelay });
  assert.strictEqual(r.result, 'OK'); assert(r.fellBack); assert.deepStrictEqual(calls, ['a/m1', 'a/m1', 'b/m2'], 'un seul nouvel essai sur timeout puis bascule');
  calls = [];
  r = await runWithFallback(cands, async c => { calls.push(c.id); if (c.id === 'a/m1') throw new Error('Clé API invalide (401)'); return 'OK'; }, { idempotent: true, ...noDelay });
  assert.deepStrictEqual(calls, ['a/m1', 'b/m2'], 'erreur d’authentification : pas de nouvel essai du même modèle');
  calls = [];
  await assert.rejects(() => runWithFallback(cands, async c => { calls.push(c.id); throw new Error('Provider timeout'); }, { idempotent: false, ...noDelay }), e => e.noRetry && /non idempotente/.test(e.message));
  assert.deepStrictEqual(calls, ['a/m1'], 'opération non idempotente : aucune reprise');
  await assert.rejects(() => runWithFallback(cands, async () => { throw new Error('ECONNRESET'); }, { idempotent: false, wasExecuted: async () => true, ...noDelay }), e => /déjà été exécutée/.test(e.message));
  await assert.rejects(() => runWithFallback(cands, async () => { throw new Error('Interrompu'); }, { idempotent: true, ...noDelay }), e => e.attempts[0].kind === 'aborted');
  await assert.rejects(() => runWithFallback(cands, async () => { throw new Error('boom'); }, { idempotent: true, ...noDelay }), e => e.exhausted && e.attempts.length === 2);
  assert.strictEqual(classifyError(new Error('HTTP 429 rate limit')).kind, 'rate_limit');
  assert.strictEqual(classifyError(new Error('Ollama ne répond pas (localhost:11434)')).kind, 'network');

  // ── Benchmark : notation déterministe, le code n'est jamais exécuté
  const T = Object.fromEntries(B.TASKS.map(t => [t.id, t]));
  globalThis.__astra_pwned = false;
  const evil = '```js\nglobalThis.__astra_pwned = true;\nfunction isPalindrome(s){ const t=s.toLowerCase().replace(/[^a-z0-9]/g,""); return t===[...t].reverse().join(""); }\n```';
  assert.strictEqual(T.coding.score(evil).score, 100);
  assert.strictEqual(globalThis.__astra_pwned, false, 'le code du modèle ne doit jamais être exécuté');
  assert(T.coding.score('function isPalindrome(s {').score < 60, 'syntaxe invalide pénalisée');
  assert.strictEqual(T.reasoning.score('36').score, 100); assert.strictEqual(T.reasoning.score('Alice en a 36 et Bob en a 12').score, 60); assert.strictEqual(T.reasoning.score('42').score, 0);
  assert.strictEqual(T.structured.score('{"name":"Fix login","tags":["bug","auth","urgent"],"priority":2}').score, 100);
  assert.strictEqual(T.structured.score('Voici : pas du json').score, 0);
  assert(T.debugging.score('La boucle utilise <= donc arr[arr.length] est undefined. Utilise i < arr.length.').score >= 80);
  assert.strictEqual(T.document.score('Le projet Lune réunit 3 agents pour 12 jours avec 4 500 euros.').score, 100);
  const res = await B.runBenchmark({ entries: [byId['openai/big'], byId['openai/small']], timeoutMs: 500, chat: async (e, msgs) => { if (e.id === 'openai/small' && /palindrome/i.test(msgs[1].content)) throw new Error('HTTP 500'); return '36'; } });
  assert.strictEqual(res['openai/big'].byCategory.reasoning.score, 100);
  assert.strictEqual(res['openai/small'].failed, 1); assert(!res['openai/small'].byCategory.coding, 'une tâche échouée n’est pas notée 0 « testé »');
  assert.strictEqual(res['openai/small'].results.find(x => x.taskId === 'coding').ok, false);

  // ── Moniteur : enveloppe réelle, jamais de contenu stocké
  const mon2 = createMonitor({ read: (n, d) => d, write: () => {} });
  const P = { x: { label: 'X', chat: async (s, m, msgs) => { if (m === 'bad') throw new Error('HTTP 500'); return 'réponse'; } } };
  mon2.instrument(P); mon2.instrument(P);
  await P.x.chat({}, 'good', [{ role: 'user', content: 'SECRET-PROMPT' }]); await P.x.chat({}, 'good', [{ role: 'user', content: 'abc' }]);
  await assert.rejects(() => P.x.chat({}, 'bad', [{ role: 'user', content: 'abc' }]));
  const st = mon2.stats('x', 'good'), sb = mon2.stats('x', 'bad');
  assert.strictEqual(st.requests, 2); assert.strictEqual(st.failures, 0); assert(st.avgMs >= 0); assert.strictEqual(sb.failureRate, 1);
  assert(!JSON.stringify(mon2._raw()).includes('SECRET-PROMPT'), 'les prompts ne sont jamais conservés');
  assert.strictEqual(mon2.perModel().length, 2);

  // ── Paramètres : validation
  const s1 = Intel.sanitize({ mode: 'auto', weights: { cost: 999, latency: -5, bogus: 3 }, maxCostPer1M: '4', overrides: { 'openai/x': { context: '8000', costIn: '1', costOut: 'abc' }, '../evil': { context: 1 } } }, null);
  assert.strictEqual(s1.mode, 'auto'); assert.strictEqual(s1.weights.cost, 100); assert.strictEqual(s1.weights.latency, 0, 'valeur négative ramenée à 0'); assert(!('bogus' in s1.weights));
  assert.strictEqual(s1.maxCostPer1M, 4); assert.strictEqual(s1.overrides['openai/x'].context, 8000); assert.strictEqual(s1.overrides['openai/x'].costOut, undefined); assert(!s1.overrides['../evil']);
  assert.strictEqual(Intel.sanitize({ mode: 'nimporte' }, s1).mode, 'auto', 'mode inconnu ignoré');

  console.log('✓ Astra Model Intelligence : analyse, registre honnête, évaluateur, routeur (3 modes), fallback sûr, benchmark déterministe, monitoring');
})().catch(e => { console.error(e); process.exit(1); }).finally(() => fs.rmSync(TMP, { recursive: true, force: true }));
