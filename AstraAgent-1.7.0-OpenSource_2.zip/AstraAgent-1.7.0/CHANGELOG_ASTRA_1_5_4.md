# Astra Agent 1.5.4 — Swarm + Demo Mode

## Intégration
- Réintégration d’Astra Swarm : 2 à 4 agents, copies de travail isolées, suivi SSE, reviewer et fusion manuelle protégée.
- Réintégration d’Astra Live Monitor : statuts agents, dernières actions, événements en direct, commandes pause/reprise/arrêt.
- Astra Mission Replay : parcours chronologique des événements d’une mission.
- Astra Demo Mode : prépare une vraie mission de mini-jeu 2D avec Meta Model API comme coordinateur et fournisseur des trois agents. En mode Démo, la mission s’arrête si Meta ne renvoie pas de plan exploitable ou si la revue Meta échoue : aucun plan de secours n’est présenté comme un résultat Meta.

## Sécurité conservée depuis 1.5.3
- Écoute locale limitée à 127.0.0.1.
- Contrôle Host/Origin et jeton aléatoire pour les routes API.
- `/api/exec` reste contrôlé par `perms.js`.
- Les protections des routes fichiers et paramètres sont conservées.

## Correctifs complémentaires
- Les exécutions de code inline (`node -e`, `python -c`, `deno eval`) sont classées CONFIRM.
- La pause Swarm est appliquée aux points de contrôle de la boucle agent ; une action déjà en cours doit se terminer avant la prise en compte de la pause.
- Les tests couvrent la copie de travail, la fusion protégée, la chronologie Mission Replay, les routes Swarm et le mode Démo.

## Limites connues
- Demo Mode nécessite une clé Meta Model API et un modèle accessible.
- Les missions Swarm exécutent de vrais appels fournisseurs et peuvent entraîner des coûts.
- Les agents travaillent dans des copies isolées applicatives, pas dans une sandbox OS.
- La fusion des changements reste une action explicite de l’utilisateur.
- La QA peut examiner les fichiers et proposer des tests ; ne pas annoncer une exécution réelle sans résultat observé.
