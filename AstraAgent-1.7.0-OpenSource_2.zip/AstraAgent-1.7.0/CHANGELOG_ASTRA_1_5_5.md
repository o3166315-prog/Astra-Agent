# Astra Agent 1.5.5 — Control Plane

## Correctif important
- **Lancer une mission Swarm faisait planter le serveur** en 1.5.4 : `store.js` n'exportait pas `dataDir`. Corrigé, avec un test de bout en bout (vrai serveur + faux fournisseur) pour éviter la régression.
- Si une erreur survient après le début d'un flux (SSE), le serveur termine proprement la réponse au lieu de s'arrêter.

## Astra Communication Graph (N° 2)
- Graphe interactif (déplacer, zoomer), panneau agent, Message Inspector (filtre par type), Event Timeline, Replay (lecture, pas à pas), détection des échanges échoués et des goulots d'étranglement, diagnostic « pourquoi la mission est bloquée », export JSON et SVG.
- Source unique : événements réels de Swarm (`public/comm-core.js`, partagé navigateur/Node).

## Astra Model Intelligence (N° 6)
- `server/intelligence/` : task-analyzer, model-registry, model-evaluator, intelligent-router, benchmark-engine, fallback-manager, performance-monitor.
- Modes Auto / Hybrid / Manual, pondérations configurables, contraintes obligatoires avant notation, explication du choix, historique des sélections.
- Benchmark sur demande (confirmation obligatoire). Fallback sûr (jamais de relance aveugle d'une opération non idempotente), désactivé par défaut.
- Le moniteur enregistre latence, échecs et volumes ; il ne conserve jamais les prompts ni les réponses.

## Astra Command Center (N° 11)
- Overview, Mission Manager (pause, reprise, annulation avec confirmation, logs, rapport Markdown), Agent Control, Live Activity filtrable, Error Center (regroupement, solution proposée, statut), Notification Center, Resource Monitor, Diagnostics, Workspace Manager, Quick Actions, commandes dans la palette.

## Limites connues
- Pas encore de pages **Automations** et **Plugins** (ils n'existent pas dans Astra : prévus au lot F du plan).
- Notifications dans l'application seulement (pas de notification système).
- Live Activity actualisée toutes les 2 s (interrogation), pas en push.
- Le Task Analyzer est heuristique. Les benchmarks sont volontairement simples.
- GPU : uniquement via `nvidia-smi` ; débit réseau non mesuré.
